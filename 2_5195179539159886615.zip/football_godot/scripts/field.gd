extends Node2D

const GRASS_A := Color(0.16, 0.5, 0.2)
const GRASS_B := Color(0.19, 0.56, 0.23)
const LINE := Color(1, 1, 1, 0.9)

var grass_tex: Texture2D = null

func _ready() -> void:
    texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
    if not G.headless:
        grass_tex = load("res://assets/grass.png") as Texture2D
        G.settings_changed.connect(queue_redraw)
        var crowd := Node2D.new()
        crowd.set_script(load("res://scripts/crowd.gd"))
        add_child(crowd)

func _draw() -> void:
    var hw: float = G.HALF_W
    var hh: float = G.HALF_H
    var gh: float = G.GOAL_HALF

    var use_tex: bool = grass_tex != null and G.gfx >= 1
    if use_tex:
        draw_texture_rect(grass_tex, Rect2(-1500, -900, 3000, 1800), true, Color(0.42, 0.55, 0.45))
    else:
        draw_rect(Rect2(-1500, -900, 3000, 1800), Color(0.06, 0.2, 0.1), true)

    var n: int = 18
    var sw: float = hw * 2.0 / n
    for i in n:
        var tint: Color = Color(1.0, 1.0, 1.0) if i % 2 == 0 else Color(0.84, 0.95, 0.84)
        var r := Rect2(-hw + i * sw, -hh, sw, hh * 2.0)
        if use_tex:
            draw_texture_rect(grass_tex, r, true, tint)
        else:
            draw_rect(r, GRASS_A if i % 2 == 0 else GRASS_B, true)

    for k in (6 if G.gfx >= 2 else 0):
        var a: float = 0.05 * float(6 - k)
        var m: float = float(k) * 14.0
        draw_rect(Rect2(-hw + m, -hh + m, hw * 2.0 - m * 2.0, hh * 2.0 - m * 2.0), Color(0, 0, 0, a), false, 14.0)

    if G.gfx >= 1:
        for k in 9:
            var ka: float = 0.2 * (1.0 - float(k) / 9.0)
            draw_rect(Rect2(-hw, -hh + float(k) * 7.0, hw * 2.0, 7.0), Color(0, 0, 0, ka), true)
            draw_rect(Rect2(-hw, hh - float(k + 1) * 7.0, hw * 2.0, 7.0), Color(0, 0, 0, ka * 0.45), true)
        if G.gfx >= 2:
            for k in 6:
                var kb: float = 0.12 * (1.0 - float(k) / 6.0)
                draw_rect(Rect2(-hw + float(k) * 7.0, -hh, 7.0, hh * 2.0), Color(0, 0, 0, kb), true)
                draw_rect(Rect2(hw - float(k + 1) * 7.0, -hh, 7.0, hh * 2.0), Color(0, 0, 0, kb * 0.6), true)

    for s in [-1.0, 1.0]:
        var sf: float = s
        var gx: float = sf * hw
        var depth: float = G.GOAL_DEPTH
        var r := Rect2(minf(gx, gx + sf * depth), -gh, depth, gh * 2.0)
        draw_rect(r, Color(0, 0, 0, 0.3), true)
        var x: float = 0.0
        while x <= depth:
            draw_line(Vector2(gx + sf * x, -gh), Vector2(gx + sf * x, gh), Color(1, 1, 1, 0.25), 1.0)
            x += 10.0
        var y: float = -gh
        while y <= gh:
            draw_line(Vector2(gx, y), Vector2(gx + sf * depth, y), Color(1, 1, 1, 0.25), 1.0)
            y += 10.0
        draw_rect(r, Color(1, 1, 1, 0.75), false, 2.0)

    if G.gfx >= 1:
        _stands(hw, hh)

    var bw: float = 12.0
    var bc := Color(0.1, 0.12, 0.2)
    draw_line(Vector2(-hw - bw, -hh - bw / 2.0), Vector2(hw + bw, -hh - bw / 2.0), bc, bw)
    draw_line(Vector2(-hw - bw, hh + bw / 2.0), Vector2(hw + bw, hh + bw / 2.0), bc, bw)
    for s in [-1.0, 1.0]:
        var sf2: float = s
        var bx: float = sf2 * (hw + bw / 2.0)
        draw_line(Vector2(bx, -hh - bw), Vector2(bx, -gh), bc, bw)
        draw_line(Vector2(bx, gh), Vector2(bx, hh + bw), bc, bw)

    draw_rect(Rect2(-hw, -hh, hw * 2.0, hh * 2.0), LINE, false, 3.0)
    draw_line(Vector2(0, -hh), Vector2(0, hh), LINE, 3.0)
    draw_arc(Vector2.ZERO, 120.0, 0.0, TAU, 64, LINE, 3.0)
    draw_circle(Vector2.ZERO, 4.0, LINE)

    for s in [-1.0, 1.0]:
        var sf3: float = s
        _box(sf3, G.PEN_DEPTH, G.PEN_HALF)
        _box(sf3, G.AREA_DEPTH, G.AREA_HALF)
        var spot := Vector2(sf3 * (hw - 160.0), 0.0)
        draw_circle(spot, 4.0, LINE)
        var a0: float = -0.6155 if sf3 < 0.0 else PI - 0.6155
        draw_arc(spot, 110.0, a0, a0 + 1.231, 24, LINE, 3.0)

    draw_arc(Vector2(-hw, -hh), 22.0, 0.0, PI / 2.0, 12, LINE, 3.0)
    draw_arc(Vector2(hw, -hh), 22.0, PI / 2.0, PI, 12, LINE, 3.0)
    draw_arc(Vector2(hw, hh), 22.0, PI, PI * 1.5, 12, LINE, 3.0)
    draw_arc(Vector2(-hw, hh), 22.0, PI * 1.5, TAU, 12, LINE, 3.0)

    for cx in [-1.0, 1.0]:
        for cy in [-1.0, 1.0]:
            var cp := Vector2(cx * hw, cy * hh)
            draw_line(cp, cp + Vector2(-cx * 2.0, -cy * 22.0), Color(0.95, 0.95, 0.95), 2.0)
            draw_colored_polygon(PackedVector2Array([cp + Vector2(-cx * 2.0, -cy * 22.0), cp + Vector2(-cx * 2.0, -cy * 14.0), cp + Vector2(-cx * 14.0, -cy * 18.0)]), Color(1.0, 0.85, 0.1))

    for post in G.POSTS:
        draw_circle(post, G.POST_R + 1.5, Color(0, 0, 0, 0.35))
        draw_circle(post, G.POST_R, Color.WHITE)
        draw_arc(post, G.POST_R, 0.0, TAU, 12, Color(0.2, 0.2, 0.2), 1.5)
    for s2 in [-1.0, 1.0]:
        var gxx: float = s2 * hw
        draw_line(Vector2(gxx, -gh), Vector2(gxx, gh), Color(1, 1, 1, 0.95), 3.5)

    if G.gfx >= 2:
        var lights: Array = [Vector2(-hw * 0.55, 0), Vector2(hw * 0.55, 0)]
        for lp in lights:
            for k in 5:
                var rr: float = 700.0 - float(k) * 120.0
                draw_circle(lp, rr, Color(1, 1, 0.9, 0.012))

func _box(sf: float, depth: float, half: float) -> void:
    var x0: float = sf * G.HALF_W
    var x1: float = sf * (G.HALF_W - depth)
    draw_rect(Rect2(minf(x0, x1), -half, absf(x1 - x0), half * 2.0), LINE, false, 3.0)

func _stands(hw: float, hh: float) -> void:
    var rows: int = 5 if G.gfx >= 2 else 3
    for side in [-1.0, 1.0]:
        var y0: float = side * (hh + 34.0)
        draw_rect(Rect2(-hw - 70.0, minf(y0, y0 + side * (float(rows) * 17.0 + 6.0)), hw * 2.0 + 140.0, float(rows) * 17.0 + 6.0), Color(0.12, 0.13, 0.17), true)
    for side in [-1.0, 1.0]:
        var x0: float = side * (hw + 80.0)
        draw_rect(Rect2(minf(x0, x0 + side * 60.0), -hh - 10.0, 60.0, hh * 2.0 + 20.0), Color(0.12, 0.13, 0.17), true)
    var ad: Array = [Color(0.9, 0.2, 0.2), Color(0.2, 0.5, 0.9), Color(0.95, 0.8, 0.2), Color(0.2, 0.75, 0.4)]
    var i: int = 0
    var ax: float = -hw
    while ax < hw:
        var w: float = 120.0
        for side in [-1.0, 1.0]:
            draw_rect(Rect2(ax + 4.0, side * (hh + 14.0) - 7.0, w - 8.0, 14.0), ad[i % ad.size()], true)
        ax += w
        i += 1
