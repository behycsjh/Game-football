extends Node

signal connected
signal disconnected(reason: String)
signal info(msg: String)
signal login_ok
signal login_failed(msg: String)
signal room_updated
signal started
signal snapshot(data: PackedFloat32Array)
signal match_event(code: int, text: String, nums: PackedFloat32Array)
signal ended(res: Dictionary)
signal stats_received(me: Dictionary, board: Array)
signal error_msg(msg: String)

const MatchScript = preload("res://scripts/match_sim.gd")
const CODE_CHARS := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

var is_server: bool = false

var logged_in: bool = false
var profile: Dictionary = {}
var room_info: Dictionary = {}
var searching: bool = false
var in_match: bool = false
var match_info: Dictionary = {}
var last_n: int = 2
var last_private: bool = false
var my_token: String = ""
var my_nick: String = ""
var last_error: String = ""
var host_ips: String = ""
var _connecting: bool = false
var _conn_t: float = 0.0
var _retry_left: int = 0
var _addr: String = ""
var _local_pid: int = -1

var profiles: Dictionary = {}
var nick_idx: Dictionary = {}
var peer_tok: Dictionary = {}
var tok_peer: Dictionary = {}
var rooms: Dictionary = {}
var peer_room: Dictionary = {}
var next_room: int = 1
var rooms_node: Node = null
var dirty: bool = false
var save_t: float = 0.0
var store_url: String = ""
var data_path: String = "user://profiles.json"

func _ready() -> void:
    var args := OS.get_cmdline_user_args()
    if "--server" in args:
        _start_server(args)
    else:
        multiplayer.connected_to_server.connect(_on_connected)
        multiplayer.connection_failed.connect(_on_conn_failed)
        multiplayer.server_disconnected.connect(_on_server_gone)

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST and _local_pid > 0:
        OS.kill(_local_pid)

func norm_url(s: String) -> String:
    s = s.strip_edges()
    if s.begins_with("ws://") or s.begins_with("wss://"):
        return s
    if s.is_valid_ip_address() or s == "localhost":
        return "ws://%s:%d" % [s, G.PORT]
    if ":" in s:
        return "ws://" + s
    return "wss://" + s

func connect_to(addr: String) -> void:
    _addr = addr
    _retry_left = 8
    _do_connect()

func _do_connect() -> void:
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer.close()
        multiplayer.multiplayer_peer = null
    var peer := WebSocketMultiplayerPeer.new()
    var err := peer.create_client(norm_url(_addr))
    if err != OK:
        last_error = "Неверный адрес сервера"
        disconnected.emit(last_error)
        return
    multiplayer.multiplayer_peer = peer
    _connecting = true
    _conn_t = 0.0

func disconnect_now() -> void:
    _connecting = false
    _retry_left = 0
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer.close()
        multiplayer.multiplayer_peer = null
    _reset_client()

func _reset_client() -> void:
    logged_in = false
    room_info = {}
    searching = false
    in_match = false

func _on_connected() -> void:
    _connecting = false
    connected.emit()
    rpc_id(1, "s_login", my_token, my_nick, G.PROTO)

func _on_conn_failed() -> void:
    _connecting = false
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer.close()
        multiplayer.multiplayer_peer = null
    if _retry_left > 0:
        _retry_left -= 1
        info.emit("Сервер просыпается… пробуем ещё раз (%d)" % _retry_left)
        await get_tree().create_timer(4.0).timeout
        if _retry_left >= 0 and multiplayer.multiplayer_peer == null:
            _do_connect()
        return
    last_error = "Не удалось подключиться к серверу"
    disconnected.emit(last_error)

func _on_server_gone() -> void:
    _reset_client()
    last_error = "Соединение с сервером потеряно"
    disconnected.emit(last_error)

func host_local_server() -> bool:
    var args: PackedStringArray = []
    if OS.has_feature("editor"):
        args.append("--path")
        args.append(ProjectSettings.globalize_path("res://"))
    args.append("--headless")
    args.append("--")
    args.append("--server")
    _local_pid = OS.create_process(OS.get_executable_path(), args)
    var ips: Array = []
    for ip in IP.get_local_addresses():
        if ip.begins_with("192.168.") or ip.begins_with("10.") or ip.begins_with("172."):
            ips.append(ip)
    host_ips = "Сервер на этом ПК. Друзья в вашей сети вводят адрес: " + ", ".join(ips)
    return _local_pid > 0

func quick_match(n: int) -> void:
    last_n = n
    last_private = false
    searching = true
    room_info = {}
    rpc_id(1, "s_quick", n)

func create_room(n: int) -> void:
    last_n = n
    last_private = true
    searching = true
    room_info = {}
    rpc_id(1, "s_create_room", n)

func join_code(code: String) -> void:
    last_private = true
    rpc_id(1, "s_join_code", code)

func start_room() -> void:
    rpc_id(1, "s_start_room")

func switch_team() -> void:
    rpc_id(1, "s_switch_team")

func leave_room() -> void:
    searching = false
    room_info = {}
    rpc_id(1, "s_leave_room")

func leave_match() -> void:
    in_match = false
    rpc_id(1, "s_leave_room")

func send_input(mx: int, my: int, btn: int) -> void:
    rpc_id(1, "s_input", mx, my, btn)

func get_stats() -> void:
    rpc_id(1, "s_get_stats")

func rename(nick: String) -> void:
    rpc_id(1, "s_rename", nick)

@rpc("authority", "call_remote", "reliable")
func c_login_ok(p: Dictionary) -> void:
    logged_in = true
    profile = p
    login_ok.emit()

@rpc("authority", "call_remote", "reliable")
func c_login_fail(msg: String) -> void:
    disconnect_now()
    last_error = msg
    login_failed.emit(msg)

@rpc("authority", "call_remote", "reliable")
func c_room(info_d: Dictionary) -> void:
    room_info = info_d
    searching = true
    room_updated.emit()

@rpc("authority", "call_remote", "reliable")
func c_start(info_d: Dictionary) -> void:
    match_info = info_d
    in_match = true
    searching = false
    room_info = {}
    started.emit()

@rpc("authority", "call_remote", "reliable")
func c_snap(a: PackedFloat32Array) -> void:
    snapshot.emit(a)

@rpc("authority", "call_remote", "reliable")
func c_event(code: int, text: String, nums: PackedFloat32Array) -> void:
    match_event.emit(code, text, nums)

@rpc("authority", "call_remote", "reliable")
func c_end(res: Dictionary) -> void:
    in_match = false
    profile["rating"] = res.get("rating", profile.get("rating", 1000))
    ended.emit(res)

@rpc("authority", "call_remote", "reliable")
func c_stats(me: Dictionary, board: Array) -> void:
    profile = me
    stats_received.emit(me, board)

@rpc("authority", "call_remote", "reliable")
func c_error(msg: String) -> void:
    searching = false
    error_msg.emit(msg)

func _start_server(args: PackedStringArray) -> void:
    is_server = true
    Engine.max_fps = 60
    store_url = OS.get_environment("STORE_URL")
    var dd := OS.get_environment("DATA_DIR")
    if dd != "":
        data_path = dd.path_join("profiles.json")
    var port: int = G.PORT
    var env := OS.get_environment("PORT")
    if env != "":
        port = int(env)
    for a in args:
        if a.begins_with("--port="):
            port = int(a.substr(7))
    await _load_profiles()
    rooms_node = Node.new()
    rooms_node.name = "Rooms"
    add_child(rooms_node)
    var peer := WebSocketMultiplayerPeer.new()
    var err := peer.create_server(port)
    if err != OK:
        push_error("Не удалось открыть порт %d (ошибка %d)" % [port, err])
        get_tree().quit(1)
        return
    multiplayer.multiplayer_peer = peer
    multiplayer.peer_disconnected.connect(_on_peer_gone)
    print("Football server: порт %d, профилей: %d" % [port, profiles.size()])

func _process(delta: float) -> void:
    if not is_server:
        if _connecting:
            _conn_t += delta
            if _conn_t > 80.0:
                _connecting = false
                if multiplayer.multiplayer_peer != null:
                    multiplayer.multiplayer_peer.close()
                    multiplayer.multiplayer_peer = null
                last_error = "Сервер не отвечает"
                disconnected.emit(last_error)
        return
    if rooms_node == null:
        return
    var now: float = Time.get_ticks_msec() / 1000.0
    save_t += delta
    if dirty and save_t > 20.0:
        save_t = 0.0
        _save_profiles()
    for r in rooms.values():
        if r["state"] != "lobby" or not r["pub"]:
            continue
        var full: bool = r["members"].size() >= 2 * int(r["n"])
        if full or (now - float(r["t0"]) >= G.MM_WAIT and not r["members"].is_empty()):
            _start_room(r)
        else:
            r["tick"] += delta
            if r["tick"] >= 1.0:
                r["tick"] = 0.0
                _broadcast_room(r)

func _sender() -> int:
    return multiplayer.get_remote_sender_id()

func _on_peer_gone(id: int) -> void:
    _drop_peer(id)

func _drop_peer(id: int) -> void:
    _leave_any(id)
    var tok = peer_tok.get(id, "")
    peer_tok.erase(id)
    if tok != "" and tok_peer.get(tok, 0) == id:
        tok_peer.erase(tok)

func _leave_any(id: int) -> void:
    if not peer_room.has(id):
        return
    var r = rooms.get(peer_room[id])
    peer_room.erase(id)
    if r == null:
        return
    r["members"].erase(id)
    r["team"].erase(id)
    if r["state"] == "lobby":
        if r["members"].is_empty():
            rooms.erase(r["id"])
        else:
            if r["host"] == id:
                r["host"] = r["members"][0]
            _broadcast_room(r)
    else:
        if r["match"] != null:
            r["match"].player_left(id)
        if r["members"].is_empty():
            _close_room(r)

func _close_room(r: Dictionary) -> void:
    for p in r["members"]:
        peer_room.erase(p)
    if r["match"] != null:
        r["match"].queue_free()
        r["match"] = null
    rooms.erase(r["id"])

func _valid_nick(nick: String) -> bool:
    if nick.length() < 3 or nick.length() > 14:
        return false
    for i in nick.length():
        var c: int = nick.unicode_at(i)
        var ok: bool = (c >= 48 and c <= 57) or (c >= 65 and c <= 90) or (c >= 97 and c <= 122) \
            or c == 95 or c == 45 or c == 32 or (c >= 0x400 and c <= 0x4FF)
        if not ok:
            return false
    return true

func _check_nick(nick: String, token: String) -> String:
    if not _valid_nick(nick):
        return "Ник: 3–14 символов (буквы, цифры, _ - пробел)"
    var t = nick_idx.get(nick.to_lower(), "")
    if t != "" and t != token:
        return "Этот ник уже занят"
    return ""

func _new_profile(nick: String) -> Dictionary:
    return {"nick": nick, "rating": 1000, "games": 0, "wins": 0, "losses": 0, "draws": 0,
        "goals": 0, "assists": 0, "fouls": 0, "yellows": 0, "reds": 0, "modes": {}}

func _norm_profile(d: Dictionary) -> Dictionary:
    var p: Dictionary = _new_profile(str(d.get("nick", "?")))
    for k in ["rating", "games", "wins", "losses", "draws", "goals", "assists", "fouls", "yellows", "reds"]:
        p[k] = int(d.get(k, p[k]))
    var m = d.get("modes", {})
    if typeof(m) == TYPE_DICTIONARY:
        p["modes"] = m
    return p

@rpc("any_peer", "call_remote", "reliable")
func s_login(token: String, nick: String, proto: int) -> void:
    if not is_server:
        return
    var id: int = _sender()
    if proto != G.PROTO:
        rpc_id(id, "c_login_fail", "Версия игры устарела — обновите клиент")
        return
    token = token.strip_edges()
    nick = nick.strip_edges()
    if token.length() < 8 or token.length() > 64:
        rpc_id(id, "c_login_fail", "Неверный токен профиля")
        return
    if not profiles.has(token):
        var err: String = _check_nick(nick, token)
        if err != "":
            rpc_id(id, "c_login_fail", err)
            return
        profiles[token] = _new_profile(nick)
        nick_idx[nick.to_lower()] = token
        dirty = true
    var old: int = tok_peer.get(token, 0)
    if old != 0 and old != id:
        _drop_peer(old)
        multiplayer.multiplayer_peer.disconnect_peer(old)
    peer_tok[id] = token
    tok_peer[token] = id
    rpc_id(id, "c_login_ok", profiles[token])

@rpc("any_peer", "call_remote", "reliable")
func s_rename(nick: String) -> void:
    if not is_server:
        return
    var id: int = _sender()
    if not peer_tok.has(id):
        return
    var token: String = peer_tok[id]
    nick = nick.strip_edges()
    var err: String = _check_nick(nick, token)
    if err != "":
        rpc_id(id, "c_error", err)
        return
    nick_idx.erase(String(profiles[token]["nick"]).to_lower())
    profiles[token]["nick"] = nick
    nick_idx[nick.to_lower()] = token
    dirty = true
    rpc_id(id, "c_login_ok", profiles[token])

@rpc("any_peer", "call_remote", "reliable")
func s_get_stats() -> void:
    if not is_server:
        return
    var id: int = _sender()
    if not peer_tok.has(id):
        return
    var arr: Array = []
    for tok in profiles:
        if int(profiles[tok]["games"]) > 0:
            arr.append(profiles[tok])
    arr.sort_custom(func(a, b): return a["rating"] > b["rating"])
    var board: Array = []
    for i in mini(arr.size(), 15):
        var p: Dictionary = arr[i]
        board.append({"nick": p["nick"], "rating": p["rating"], "wins": p["wins"], "games": p["games"], "goals": p["goals"],
            "fouls": p["fouls"], "yellows": p["yellows"], "reds": p["reds"]})
    rpc_id(id, "c_stats", profiles[peer_tok[id]], board)

func _gen_code() -> String:
    for attempt in 50:
        var s := ""
        for i in 4:
            s += CODE_CHARS[randi() % CODE_CHARS.length()]
        var taken: bool = false
        for r in rooms.values():
            if r["code"] == s:
                taken = true
        if not taken:
            return s
    return "ZZZZ"

func _new_room(n: int, pub: bool, host: int) -> Dictionary:
    var r: Dictionary = {"id": next_room, "code": _gen_code(), "n": n, "pub": pub, "host": host,
        "members": [], "team": {}, "state": "lobby", "t0": Time.get_ticks_msec() / 1000.0,
        "match": null, "tick": 0.0}
    next_room += 1
    rooms[r["id"]] = r
    return r

func _join_room(id: int, r: Dictionary) -> bool:
    var c: Array = [0, 0]
    for p in r["members"]:
        c[r["team"][p]] += 1
    var t: int = 0 if c[0] <= c[1] else 1
    if c[t] >= r["n"]:
        t = 1 - t
    if c[t] >= r["n"]:
        return false
    if r["members"].is_empty():
        r["t0"] = Time.get_ticks_msec() / 1000.0
    r["members"].append(id)
    r["team"][id] = t
    peer_room[id] = r["id"]
    return true

func _room_of(id: int):
    return rooms.get(peer_room.get(id, -1))

func _broadcast_room(r: Dictionary) -> void:
    var now: float = Time.get_ticks_msec() / 1000.0
    var ms: Array = []
    for p in r["members"]:
        var pr: Dictionary = profiles.get(peer_tok.get(p, ""), {})
        ms.append({"nick": pr.get("nick", "?"), "team": r["team"][p], "rating": pr.get("rating", 1000)})
    var start_in: int = -1
    if r["pub"]:
        start_in = maxi(0, int(ceil(G.MM_WAIT - (now - float(r["t0"])))))
    for p in r["members"]:
        rpc_id(p, "c_room", {"code": r["code"], "n": r["n"], "pub": r["pub"], "members": ms,
            "start_in": start_in, "is_host": p == r["host"]})

@rpc("any_peer", "call_remote", "reliable")
func s_quick(n: int) -> void:
    if not is_server:
        return
    var id: int = _sender()
    if not peer_tok.has(id) or peer_room.has(id) or n < 1 or n > 4:
        return
    var r = null
    for x in rooms.values():
        if x["pub"] and x["state"] == "lobby" and x["n"] == n and x["members"].size() < 2 * n:
            r = x
            break
    if r == null:
        r = _new_room(n, true, 0)
    _join_room(id, r)
    _broadcast_room(r)

@rpc("any_peer", "call_remote", "reliable")
func s_create_room(n: int) -> void:
    if not is_server:
        return
    var id: int = _sender()
    if not peer_tok.has(id) or peer_room.has(id) or n < 1 or n > 4:
        return
    var r: Dictionary = _new_room(n, false, id)
    _join_room(id, r)
    _broadcast_room(r)

@rpc("any_peer", "call_remote", "reliable")
func s_join_code(code: String) -> void:
    if not is_server:
        return
    var id: int = _sender()
    if not peer_tok.has(id) or peer_room.has(id):
        return
    code = code.strip_edges().to_upper()
    for r in rooms.values():
        if r["code"] == code and not r["pub"] and r["state"] == "lobby":
            if _join_room(id, r):
                _broadcast_room(r)
            else:
                rpc_id(id, "c_error", "Комната заполнена")
            return
    rpc_id(id, "c_error", "Комната с таким кодом не найдена")

@rpc("any_peer", "call_remote", "reliable")
func s_switch_team() -> void:
    if not is_server:
        return
    var id: int = _sender()
    var r = _room_of(id)
    if r == null or r["state"] != "lobby":
        return
    var cnt: int = 0
    var other: int = 1 - int(r["team"][id])
    for p in r["members"]:
        if r["team"][p] == other:
            cnt += 1
    if cnt < r["n"]:
        r["team"][id] = other
        _broadcast_room(r)

@rpc("any_peer", "call_remote", "reliable")
func s_start_room() -> void:
    if not is_server:
        return
    var id: int = _sender()
    var r = _room_of(id)
    if r == null or r["state"] != "lobby":
        return
    if r["pub"] or r["host"] == id:
        _start_room(r)

@rpc("any_peer", "call_remote", "reliable")
func s_leave_room() -> void:
    if not is_server:
        return
    _leave_any(_sender())

@rpc("any_peer", "call_remote", "reliable")
func s_input(mx: int, my: int, btn: int) -> void:
    if not is_server:
        return
    var id: int = _sender()
    var r = _room_of(id)
    if r == null or r["match"] == null:
        return
    r["match"].set_input(id, mx, my, btn)

func _start_room(r: Dictionary) -> void:
    if r["state"] != "lobby" or r["members"].is_empty():
        return
    r["state"] = "play"
    var list: Array = []
    for p in r["members"]:
        var tok: String = peer_tok.get(p, "")
        list.append({"peer": p, "token": tok, "nick": profiles[tok]["nick"], "team": r["team"][p]})
    var m = MatchScript.new()
    rooms_node.add_child(m)
    m.init_match(r["id"], r["n"], list)
    r["match"] = m
    for p in r["members"]:
        rpc_id(p, "c_start", m.describe(p))

func match_finished(room_id: int, n: int, score: Array, pl: Array) -> void:
    var r = rooms.get(room_id)
    for e in pl:
        var pr = profiles.get(e["token"])
        if pr == null:
            continue
        var res: int = 0
        if e["left"] or score[e["team"]] < score[1 - e["team"]]:
            res = -1
        elif score[e["team"]] > score[1 - e["team"]]:
            res = 1
        var delta: int = 3
        if res == 1:
            delta = 25
        elif res == -1:
            delta = -20
        e["delta"] = delta
        pr["games"] = int(pr["games"]) + 1
        pr["goals"] = int(pr["goals"]) + int(e["goals"])
        pr["assists"] = int(pr["assists"]) + int(e["assists"])
        pr["fouls"] = int(pr.get("fouls", 0)) + int(e.get("fouls", 0))
        pr["yellows"] = int(pr.get("yellows", 0)) + int(e.get("yellows", 0))
        pr["reds"] = int(pr.get("reds", 0)) + int(e.get("reds", 0))
        if res == 1:
            pr["wins"] = int(pr["wins"]) + 1
        elif res == -1:
            pr["losses"] = int(pr["losses"]) + 1
        else:
            pr["draws"] = int(pr["draws"]) + 1
        pr["rating"] = maxi(0, int(pr["rating"]) + delta)
        var mk: String = "m%d" % n
        var md: Dictionary = pr["modes"].get(mk, {"games": 0, "wins": 0})
        md["games"] = int(md["games"]) + 1
        if res == 1:
            md["wins"] = int(md["wins"]) + 1
        pr["modes"][mk] = md
    dirty = true
    save_t = 100.0
    var table: Array = []
    for e in pl:
        table.append({"nick": e["nick"], "team": e["team"], "goals": e["goals"], "assists": e["assists"],
            "fouls": int(e.get("fouls", 0)), "yellows": int(e.get("yellows", 0)), "reds": int(e.get("reds", 0))})
    var peers: PackedInt32Array = multiplayer.get_peers()
    for e in pl:
        if e["left"] or not peers.has(e["peer"]) or not e.has("delta"):
            continue
        rpc_id(e["peer"], "c_end", {"score": [score[0], score[1]], "n": n, "players": table,
            "delta": e["delta"], "rating": profiles[e["token"]]["rating"]})
    if r != null:
        _close_room(r)

func _load_profiles() -> void:
    var txt: String = ""
    if store_url != "":
        var http := HTTPRequest.new()
        add_child(http)
        if http.request(store_url) == OK:
            var res = await http.request_completed
            if res[1] == 200:
                txt = (res[3] as PackedByteArray).get_string_from_utf8()
        http.queue_free()
    elif FileAccess.file_exists(data_path):
        txt = FileAccess.get_file_as_string(data_path)
    if txt == "":
        return
    var d = JSON.parse_string(txt)
    if typeof(d) != TYPE_DICTIONARY:
        return
    for tok in d:
        if typeof(d[tok]) != TYPE_DICTIONARY:
            continue
        var pr: Dictionary = _norm_profile(d[tok])
        profiles[tok] = pr
        nick_idx[String(pr["nick"]).to_lower()] = tok

func _save_profiles() -> void:
    dirty = false
    var body: String = JSON.stringify(profiles)
    if store_url != "":
        var http := HTTPRequest.new()
        add_child(http)
        if http.request(store_url, ["Content-Type: application/json"], HTTPClient.METHOD_PUT, body) == OK:
            await http.request_completed
        http.queue_free()
    else:
        var f := FileAccess.open(data_path, FileAccess.WRITE)
        if f != null:
            f.store_string(body)
