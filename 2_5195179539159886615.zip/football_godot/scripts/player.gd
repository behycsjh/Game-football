extends CharacterBody2D

enum St { IDLE, CHASE, CARRY, SUPPORT, PRESS, COVER, TACKLE, RECOVER, DIVE, GETUP, HOLD, SKILL, DASH }

const RADIUS: float = 16.0
const SPEED: float = 255.0
const SPEED_BALL: float = 232.0
const SPEED_GK: float = 240.0

var main = null
var ball = null
var team: int = 0
var role: int = 2
var num: int = 1
var home: Vector2 = Vector2.ZERO
var dir_x: float = 1.0
var is_human: bool = false
var move_input: Vector2 = Vector2.ZERO
var facing: Vector2 = Vector2.RIGHT
var state: int = St.IDLE
var mark_target = null
var is_pass_target: bool = false

var charging: bool = false
var charge: float = 0.0
var tackle_t: float = 0.0
var tackle_hit: bool = false
var tackle_cd: float = 0.0
var recover_t: float = 0.0
var skill_t: float = 0.0
var skill_cd: float = 0.0
var skill_vec: Vector2 = Vector2.ZERO
var skill_kind: int = 0
var skill_spin: float = 0.0
var feint_idx: int = 0
var kick_lock: float = 0.0
var deflect_lock: float = 0.0
var pass_cd: float = 0.0
var think_t: float = 0.0
var dive_t: float = 0.0
var dive_cd: float = 0.0
var dive_vec: Vector2 = Vector2.ZERO
var dive_rolled: bool = false
var getup_t: float = 0.0
var hold_t: float = 0.0
var rush_t: float = 0.0
var rush_cd: float = 0.0
var steal_cd: float = 0.0
var nick: String = ""
var kick_kind: int = 0
var kick_t: float = 0.0
var run_phase: float = 0.0
var is_net_puppet: bool = false
var shield_t: float = 0.0
var dash_t: float = 0.0
var dash_cd: float = 0.0
var dash_rolled: bool = false
var stats: Dictionary = {"shots": 0, "tackles": 0, "feints": 0, "goals": 0, "assists": 0, "saves": 0, "fouls": 0, "yellows": 0, "reds": 0, "offsides": 0}
var yellow: int = 0
var sent_off: bool = false
var hands_up: bool = false
var warned: int = 0
var bot_k: float = 0.85
var hop: float = 0.0

const FEINT_NAMES := ["ПОДМАНКА", "РУЛЕТКА", "РЫВОК", "РАЗВОРОТ"]
const FEINT_DUR: float = 0.45
const KICK_ANIM: float = 0.32
const HIGH_CHARGE: float = 0.35

func setup(m, b, t: int, r: int, n: int, h: Vector2) -> void:
    main = m
    ball = b
    team = t
    role = r
    num = n
    home = h
    dir_x = 1.0 if t == 0 else -1.0
    facing = Vector2(dir_x, 0.0)

func reset_state() -> void:
    velocity = Vector2.ZERO
    charging = false
    charge = 0.0
    tackle_t = 0.0
    tackle_cd = 0.0
    recover_t = 0.0
    skill_t = 0.0
    skill_cd = 0.0
    skill_kind = 0
    skill_spin = 0.0
    kick_lock = 0.0
    deflect_lock = 0.0
    pass_cd = 0.0
    dive_t = 0.0
    dive_cd = 0.0
    getup_t = 0.0
    hold_t = 0.0
    rush_t = 0.0
    rush_cd = 0.0
    steal_cd = 0.0
    kick_t = 0.0
    kick_kind = 0
    shield_t = 0.0
    hop = 0.0
    dash_t = 0.0
    dash_cd = 0.0
    dash_rolled = false
    state = St.IDLE
    facing = Vector2(dir_x, 0.0)
    is_pass_target = false
    hands_up = false

func _say(text: String, col: Color = Color.WHITE) -> void:
    if main != null and main.has_method("popup"):
        main.popup(global_position + Vector2(0, -44), text, col)

func _stat(k: String) -> void:
    stats[k] = int(stats[k]) + 1

func _foul_on(h) -> bool:
    if main != null and main.has_method("call_foul"):
        return main.call_foul(self, h)
    return false

func _note_tackle(victim) -> void:
    if main != null and main.has_method("note_tackle"):
        main.note_tackle(self, victim)

func has_ball() -> bool:
    return ball != null and ball.holder == self

func _tick(delta: float) -> void:
    kick_lock = maxf(0.0, kick_lock - delta)
    deflect_lock = maxf(0.0, deflect_lock - delta)
    skill_cd = maxf(0.0, skill_cd - delta)
    skill_t = maxf(0.0, skill_t - delta)
    tackle_cd = maxf(0.0, tackle_cd - delta)
    recover_t = maxf(0.0, recover_t - delta)
    dive_cd = maxf(0.0, dive_cd - delta)
    rush_t = maxf(0.0, rush_t - delta)
    rush_cd = maxf(0.0, rush_cd - delta)
    steal_cd = maxf(0.0, steal_cd - delta)
    pass_cd = maxf(0.0, pass_cd - delta)
    kick_t = maxf(0.0, kick_t - delta)
    shield_t = maxf(0.0, shield_t - delta)
    dash_cd = maxf(0.0, dash_cd - delta)

func on_kick(high: bool) -> void:
    kick_kind = 2 if high else 1
    kick_t = KICK_ANIM
    if main != null:
        G.sfx("kick_high" if high else "kick_low")
        if main.has_method("burst"):
            main.burst(global_position + facing * 20.0, Color(0.75, 0.9, 0.55, 0.8), 6, 140.0, 0.4)

func _physics_process(delta: float) -> void:
    if main == null or ball == null:
        return
    _tick(delta)
    if main.phase != "play":
        velocity = Vector2.ZERO
        return
    if role == 0:
        _gk_step(delta)
    else:
        _field_step(delta)

func _field_step(delta: float) -> void:
    if recover_t > 0.0:
        state = St.RECOVER
        velocity = velocity.move_toward(Vector2.ZERO, 1400.0 * delta)
    elif tackle_t > 0.0:
        state = St.TACKLE
        tackle_t -= delta
        velocity = facing * 560.0
        _tackle_check()
        if tackle_t <= 0.0 and not tackle_hit:
            recover_t = 0.6
    elif skill_t > 0.0:
        state = St.SKILL
        var kf: float = clampf(skill_t / FEINT_DUR, 0.0, 1.0)
        if skill_kind == 0:
            velocity = Vector2.ZERO
            hop = sin(PI * (1.0 - kf)) * 22.0
        else:
            velocity = skill_vec * kf
            hop = sin(PI * (1.0 - kf)) * 8.0
    else:
        var desired: Vector2 = Vector2.ZERO
        if is_human:
            desired = move_input
            if charging:
                charge = minf(charge + delta, 1.0)
            state = St.CARRY if has_ball() else St.IDLE
        else:
            desired = _ai_field(delta)
        var sp: float = SPEED
        if has_ball():
            sp = SPEED_BALL
        if not is_human:
            sp *= bot_k
        if charging:
            sp *= 0.75
        desired = desired.limit_length(1.0)
        velocity = velocity.move_toward(desired * sp, 1700.0 * delta)
        if desired.length() > 0.2:
            var a: float = facing.angle_to(desired)
            facing = facing.rotated(clampf(a, -14.0 * delta, 14.0 * delta))
    if skill_t <= 0.0:
        hop = 0.0
    move_and_slide()
    _clamp_position()
    _ball_contact()

func _ball_contact() -> void:
    if ball.holder != null:
        return
    if kick_lock > 0.0 or recover_t > 0.0 or tackle_t > 0.0:
        return
    if ball.z > 30.0:
        return
    var d: float = global_position.distance_to(ball.global_position)
    if d < RADIUS + 9.0 + 4.0:
        var sp: float = ball.vel.length()
        if sp < 360.0 and ball.z < 18.0:
            ball.give_to(self)
        elif deflect_lock <= 0.0:

            var n: Vector2 = (ball.global_position - global_position).normalized()
            if n == Vector2.ZERO:
                n = -ball.vel.normalized()
            ball.global_position = global_position + n * (RADIUS + 9.0 + 1.0)
            if ball.vel.dot(n) < 0.0:
                ball.vel = ball.vel.bounce(n) * 0.55 + velocity * 0.35
                ball.spin = randf_range(-0.3, 0.3)
                if ball.z > 10.0:
                    ball.vz = maxf(ball.vz, 120.0)
                G.sfx("block", -4.0)
            else:
                ball.vel *= 0.95
            ball.touch(self)
            ball.last_team = team
            deflect_lock = 0.15

func _tackle_check() -> void:
    if tackle_hit:
        return
    var hc: Vector2 = global_position + facing * 24.0
    var h = ball.holder
    if h != null:
        if h.team != team and h.role != 0 and hc.distance_to(h.global_position) < 32.0:
            if h.shield_t > 0.0:
                tackle_hit = true
                tackle_t = 0.0
                recover_t = 0.5
                _say("НЕ СМОГ ОТОБРАТЬ", Color(1.0, 0.8, 0.3))
                return
            tackle_hit = true
            if randf() < 0.34 and _foul_on(h):
                tackle_t = 0.0
                recover_t = 0.3
                return
            h.kick_lock = 0.7
            if randf() < 0.55:
                ball.give_to(self)
                _stat("tackles")
                _say("ОТБОР!", Color(0.5, 1.0, 0.6))
                G.sfx("tackle")
                _note_tackle(h)
            else:
                var kd: Vector2 = facing.rotated(randf_range(-0.9, 0.9))
                ball.holder = null
                ball.vel = kd * 330.0
                ball.touch(self)
                G.sfx("tackle", -3.0)
            tackle_t = 0.0
            recover_t = 0.2
    elif ball.z < 14.0 and hc.distance_to(ball.global_position) < 30.0 and ball.vel.length() < 520.0:
        tackle_hit = true
        ball.give_to(self)
        tackle_t = 0.0
        recover_t = 0.15

func begin_charge() -> void:
    if recover_t > 0.0 or tackle_t > 0.0 or role == 0:
        return
    charging = true
    charge = 0.0

func press_kick() -> void:
    if role == 0:
        gk_exit()
        return
    var h = ball.holder
    if h != null and h.team != team and h.role != 0 and h != self:
        var dv: Vector2 = h.global_position - global_position
        var dd: float = dv.length()

        if dd < 62.0 and (dd < 34.0 or facing.dot(dv / dd) > 0.15):
            _try_steal(h)
            return
        if dd < 95.0:
            do_tackle()
            return
    begin_charge()

func _try_steal(h) -> void:
    if steal_cd > 0.0 or recover_t > 0.0 or tackle_t > 0.0 or kick_lock > 0.0:
        return
    steal_cd = 0.8
    if h.shield_t > 0.0:
        recover_t = 0.25
        _say("НЕ СМОГ ОТОБРАТЬ", Color(1.0, 0.8, 0.3))
        return
    if randf() < 0.1 and _foul_on(h):
        return
    h.kick_lock = 0.7
    ball.give_to(self)
    _stat("tackles")
    _say("ОТБОР!", Color(0.5, 1.0, 0.6))
    G.sfx("tackle")
    _note_tackle(h)

func release_shoot() -> void:
    if not charging:
        return
    charging = false
    var c: float = charge
    charge = 0.0
    var can: bool = has_ball() or (ball.holder == null and ball.z < 18.0 and global_position.distance_to(ball.global_position) < 32.0 and kick_lock <= 0.0)
    if not can:
        return
    var d: Vector2 = facing
    if move_input.length() > 0.3:
        d = move_input.normalized()
    d = _aim_assist(d)
    if c < HIGH_CHARGE:

        var t: float = clampf(c / HIGH_CHARGE, 0.0, 1.0)
        var pw: float = lerpf(560.0, 980.0, t)

        if global_position.distance_to(Vector2(G.HALF_W * dir_x, 0.0)) > 650.0:
            var mate = main.find_pass_target(self, d)
            if mate != null:
                var to: Vector2 = mate.global_position - ball.global_position
                if absf(d.angle_to(to)) < 0.4:
                    var lead: Vector2 = mate.velocity * (to.length() / 800.0) * 0.8
                    d = (to + lead).normalized()
                    pw = clampf(to.length() * 1.3 + 170.0, 320.0, pw)
        d = d.rotated(randf_range(-1.0, 1.0) * lerpf(0.07, 0.03, t))
        ball.kick(d, pw, randf_range(-0.4, 0.4) * (0.3 + t), self, 0.0)
        _mark_shot(d)
    else:

        var t2: float = clampf((c - HIGH_CHARGE) / (1.0 - HIGH_CHARGE), 0.0, 1.0)
        d = d.rotated(randf_range(-1.0, 1.0) * lerpf(0.10, 0.05, t2))
        ball.kick(d, lerpf(520.0, 900.0, t2), randf_range(-0.3, 0.3), self, lerpf(250.0, 430.0, t2))
        _mark_shot(d)

func _mark_shot(d: Vector2) -> void:
    var goal: Vector2 = Vector2(G.HALF_W * dir_x, 0.0)
    var to: Vector2 = goal - global_position
    if to.length() < 760.0 and absf(d.angle_to(to)) < 0.65:
        _stat("shots")
        ball.shooter = self

func _aim_assist(d: Vector2) -> Vector2:
    var goal: Vector2 = Vector2(G.HALF_W * dir_x, 0.0)
    var to: Vector2 = goal - global_position
    if to.length() > 850.0:
        return d
    var ang: float = d.angle_to(to)
    if absf(ang) < 0.3:
        return d.rotated(ang * 0.6)
    return d

func do_pass(aim: Vector2) -> void:
    if not has_ball():
        return
    var d: Vector2 = Vector2.ZERO
    if aim.length() > 0.3:
        d = aim.normalized()
    var t = main.find_pass_target(self, d)
    if t == null:
        var fd: Vector2 = facing
        if d != Vector2.ZERO:
            fd = d
        ball.kick(fd, 520.0, 0.0, self)
        return
    var start: Vector2 = ball.global_position
    var dist: float = start.distance_to(t.global_position)
    var spd: float = clampf(dist * 1.3 + 170.0, 300.0, 1150.0)
    var lead_t: float = dist / maxf((spd + 150.0) * 0.5, 1.0)
    var aim_pos: Vector2 = t.global_position + t.velocity * lead_t * 0.8
    aim_pos.x = clampf(aim_pos.x, -G.HALF_W + 20.0, G.HALF_W - 20.0)
    aim_pos.y = clampf(aim_pos.y, -G.HALF_H + 20.0, G.HALF_H - 20.0)
    ball.kick(aim_pos - start, spd, 0.0, self)

func do_tackle() -> void:
    if role == 0 or has_ball():
        return
    if tackle_t > 0.0 or recover_t > 0.0 or tackle_cd > 0.0 or skill_t > 0.0:
        return
    if move_input.length() > 0.3:
        facing = move_input.normalized()
    tackle_t = 0.28
    tackle_hit = false
    tackle_cd = 1.0

func _pick_feint() -> int:
    if not is_human:
        return randi() % 4
    if move_input.length() > 0.35:
        var fw: float = facing.dot(move_input.normalized())
        if fw > 0.6:
            return 2
        if fw < -0.4:
            return 3
        return 1
    feint_idx = (feint_idx + 1) % 4
    return feint_idx

func do_skill() -> void:
    if role == 0 or not has_ball():
        return
    if skill_cd > 0.0 or recover_t > 0.0 or tackle_t > 0.0 or skill_t > 0.0:
        return
    skill_kind = _pick_feint()
    skill_vec = Vector2.ZERO
    skill_spin = 0.0
    var side: float = 1.0
    if move_input.length() > 0.35:
        side = 1.0 if facing.cross(move_input) >= 0.0 else -1.0
    elif randf() < 0.5:
        side = -1.0
    match skill_kind:
        1:
            skill_vec = facing.orthogonal() * side * 330.0
            skill_spin = side
        2:
            skill_vec = facing * 430.0
        3:
            skill_vec = -facing * 170.0
            facing = -facing
    skill_t = FEINT_DUR
    shield_t = 1.0 if skill_kind == 0 else 0.9
    skill_cd = 2.0
    _stat("feints")
    G.sfx("feint")
    _say(String(FEINT_NAMES[skill_kind]), Color(0.65, 0.92, 1.0))
    if main != null and main.has_method("burst"):
        main.burst(global_position, Color(1, 1, 1), 14, 160.0, 0.5)

func _goto(target: Vector2, stop: float = 6.0) -> Vector2:
    var d: Vector2 = target - global_position
    var l: float = d.length()
    if l < stop:
        return Vector2.ZERO
    return d / l * clampf(l / 60.0, 0.15, 1.0)

func _separation() -> Vector2:
    var s: Vector2 = Vector2.ZERO
    for p in main.teams[team]:
        if p == self or p.role == 0:
            continue
        var d: Vector2 = global_position - p.global_position
        var l: float = d.length()
        if l < 90.0 and l > 0.01:
            s += d / l * (90.0 - l) / 90.0
    return s

func _slot_pos(attacking: bool) -> Vector2:
    var bpos: Vector2 = ball.global_position
    var bx: float = bpos.x * dir_x
    var push: float = 150.0 if attacking else -100.0
    if role == 1:
        push *= 0.4
    var lx: float = home.x + clampf(bx * 0.45, -240.0, 330.0) + push
    var ly: float = home.y + (bpos.y - home.y) * 0.22
    lx = clampf(lx, -G.HALF_W + 80.0, G.HALF_W - 120.0)
    if role == 1:
        lx = minf(lx, 225.0)
    return Vector2(lx * dir_x, clampf(ly, -(G.HALF_H - 50.0), G.HALF_H - 50.0))

func _cover_pos() -> Vector2:
    if mark_target == null:
        return _slot_pos(false)
    var lane: Vector2 = ball.global_position.lerp(mark_target.global_position, 0.6)
    return lane.lerp(_slot_pos(false), 0.4)

func _ai_field(delta: float) -> Vector2:
    var h = ball.holder
    var move: Vector2 = Vector2.ZERO
    if h == self:
        state = St.CARRY
        return _ai_carry(delta)
    if h != null and h.team == team:
        state = St.SUPPORT
        move = _goto(_slot_pos(true))
    elif h != null:
        if main.presser[team] == self:
            state = St.PRESS
            var tgt: Vector2 = h.global_position + h.velocity * 0.18
            move = _goto(tgt, 4.0)
            var dd: float = global_position.distance_to(h.global_position)
            if dd < 52.0 and tackle_cd <= 0.0 and recover_t <= 0.0 and randf() < 0.03 * bot_k:
                facing = (h.global_position - global_position).normalized()
                do_tackle()
        else:
            state = St.COVER
            move = _goto(_cover_pos())
    else:
        if main.chaser[team] == self:
            state = St.CHASE
            move = _goto(ball.global_position + ball.vel * 0.25, 2.0)
        else:
            state = St.SUPPORT
            move = _goto(_slot_pos(ball.last_team == team))
    move += _separation() * 0.8
    return move

func _lane_clear(target: Vector2) -> bool:
    var a: Vector2 = global_position
    for o in main.teams[1 - team]:
        if o.role == 0:
            continue
        var op: Vector2 = o.global_position
        var cp: Vector2 = Geometry2D.get_closest_point_to_segment(op, a, target)
        if cp.distance_to(op) < 26.0:
            return false
    return true

func _ai_shoot() -> void:
    var gk = main.gk_of(1 - team)
    var ty: float = randf_range(-60.0, 60.0)
    if gk != null:
        var gy: float = gk.global_position.y
        if absf(gy) > 5.0:
            ty = -signf(gy) * randf_range(35.0, 70.0)
        else:
            ty = (55.0 if randf() < 0.5 else -55.0)
    var aim: Vector2 = Vector2(G.HALF_W * dir_x, ty) - ball.global_position
    var d: Vector2 = aim.normalized().rotated(randf_range(-0.15, 0.15) / bot_k)
    if randf() < 0.25:
        ball.kick(d, randf_range(600.0, 780.0), randf_range(-0.3, 0.3), self, randf_range(260.0, 380.0))
    else:
        ball.kick(d, randf_range(700.0, 920.0), randf_range(-0.3, 0.3), self)
    stats["shots"] = int(stats["shots"]) + 1
    ball.shooter = self

func _ai_carry(delta: float) -> Vector2:
    var goal: Vector2 = Vector2(G.HALF_W * dir_x, 0.0)
    var to_goal: Vector2 = goal - global_position
    var dist: float = to_goal.length()
    var desired: Vector2 = to_goal.normalized()
    var nd: float = 9999.0
    var nearest = null
    for o in main.teams[1 - team]:
        if o.role == 0:
            continue
        var od: Vector2 = global_position - o.global_position
        var d: float = od.length()
        if d < nd:
            nd = d
            nearest = o
        if d < 140.0 and d > 0.01:
            desired += od / d * (140.0 - d) / 140.0 * 1.6
    desired.y -= signf(global_position.y) * maxf(0.0, absf(global_position.y) - (G.HALF_H - 90.0)) / 90.0
    desired = desired.normalized()

    think_t -= delta
    if think_t <= 0.0:
        think_t = randf_range(0.18, 0.36) / bot_k

        if dist < 480.0 and _lane_clear(goal):
            if dist < 320.0 or randf() < 0.45:
                _ai_shoot()
                return desired

        if nearest != null and nd < 75.0 and skill_cd <= 0.0 and randf() < 0.4:
            do_skill()
            return desired

        if (nd < 80.0 or randf() < 0.08) and pass_cd <= 0.0:
            var t = main.find_pass_target(self, Vector2.ZERO)
            if t != null:
                var adv: float = (t.global_position.x - global_position.x) * dir_x
                if adv > -40.0 or nd < 60.0:
                    pass_cd = 1.0
                    do_pass(Vector2.ZERO)
                    return desired
    return desired

func _gk_step(delta: float) -> void:
    facing = Vector2(dir_x, 0.0)
    if getup_t > 0.0:
        state = St.GETUP
        getup_t -= delta
        velocity = velocity.move_toward(Vector2.ZERO, 1500.0 * delta)
    elif dash_t > 0.0:

        state = St.DASH
        dash_t -= delta
        var k: float = clampf((dash_t - 0.45) / 0.25, 0.0, 1.0)
        velocity = dive_vec * 520.0 * k
        if dash_t <= 0.0:
            getup_t = 0.5
            dash_cd = 1.6
            dive_cd = 1.0
    elif dive_t > 0.0:
        state = St.DIVE
        dive_t -= delta
        velocity = dive_vec * 700.0 * clampf(dive_t / 0.5, 0.0, 1.0)
        if dive_t <= 0.0:
            getup_t = 0.5
            dive_cd = 1.1
    else:
        var desired: Vector2 = Vector2.ZERO
        var sp: float = SPEED_GK
        if ball.holder == self:
            state = St.HOLD
            hold_t += delta
            if is_human:
                desired = move_input
                if hold_t > 5.0:
                    _gk_release(Vector2.ZERO)
            elif hold_t > 1.0:
                _gk_release(Vector2.ZERO)
        else:
            hold_t = 0.0
            if is_human:
                desired = move_input
                if rush_t > 0.0:
                    var tp: Vector2 = ball.global_position + ball.vel * 0.15
                    desired = (tp - global_position).limit_length(1.0)
                    sp = 380.0
            else:
                desired = _gk_ai()
        velocity = velocity.move_toward(desired.limit_length(1.0) * sp, 2000.0 * delta)
    move_and_slide()
    _clamp_position()
    _gk_contact()

func _in_box(p: Vector2) -> bool:
    var gx: float = -G.HALF_W * dir_x
    var depth: float = (p.x - gx) * dir_x
    return depth > 0.0 and depth < G.PEN_DEPTH and absf(p.y) < G.PEN_HALF

func _gk_ai() -> Vector2:
    var goal_x: float = -G.HALF_W * dir_x
    var gc: Vector2 = Vector2(goal_x, 0.0)
    var b: Vector2 = ball.global_position
    var v: Vector2 = ball.vel
    var h = ball.holder
    if v.length() < 150.0:
        dive_rolled = false
    if h == null or h.team == team:
        dash_rolled = false

    if h != null and h.team != team and h.role != 0:
        var hp: Vector2 = h.global_position
        if hp.distance_to(gc) < 340.0:
            var dh: float = hp.distance_to(global_position)

            if dh < 125.0 and dh > 45.0 and dash_cd <= 0.0 and dive_cd <= 0.0 and not dash_rolled and h.shield_t <= 0.0:
                dash_rolled = true
                if randf() < 0.6:
                    gk_dash()
                    return Vector2.ZERO
            state = St.CHASE
            return (hp + h.velocity * 0.15 - global_position).limit_length(1.0)

    if h == null and v.x * (-dir_x) > 100.0:
        var t: float = (goal_x - b.x) / v.x
        if t > 0.0 and t < 1.0:
            var y_at: float = b.y + v.y * t * 0.9
            if absf(y_at) < G.GOAL_HALF + 45.0:
                var target: Vector2 = Vector2(goal_x + dir_x * 28.0, clampf(y_at, -(G.GOAL_HALF - 10.0), G.GOAL_HALF - 10.0))
                var dy: float = y_at - global_position.y
                if t < 0.4 and dive_cd <= 0.0 and absf(dy) > 26.0 and absf(dy) < 260.0 and not dive_rolled:
                    dive_rolled = true
                    if randf() < 0.82 * bot_k * bot_k:
                        if b.distance_to(global_position) < 140.0 and dash_cd <= 0.0 and randf() < 0.4:
                            gk_dash()
                        else:
                            _start_dive(Vector2(0.0, signf(dy)))
                elif t < 0.3 and absf(dy) <= 26.0 and b.distance_to(global_position) < 110.0 and dash_cd <= 0.0 and dive_cd <= 0.0 and not dive_rolled:
                    dive_rolled = true
                    if randf() < 0.35:
                        gk_dash()
                return _goto(target, 4.0)

    if h == null and v.length() < 200.0 and _in_box(b) and b.distance_to(global_position) < 220.0:
        return _goto(b, 2.0)

    var to_b: Vector2 = b - gc
    var dist: float = maxf(to_b.length(), 1.0)
    var depth: float = lerpf(30.0, 100.0, clampf(1.0 - dist / 700.0, 0.0, 1.0))
    var pos: Vector2 = gc + to_b / dist * depth
    pos.y = clampf(pos.y, -(G.GOAL_HALF - 15.0), G.GOAL_HALF - 15.0)
    state = St.IDLE
    return _goto(pos, 4.0)

func _start_dive(vec: Vector2) -> void:
    if state == St.DIVE or getup_t > 0.0 or dive_cd > 0.0 or dive_t > 0.0 or dash_t > 0.0:
        return
    if has_ball():
        return
    dive_vec = vec.normalized()
    dive_t = 0.5
    state = St.DIVE

func gk_jump(side: int) -> void:
    if role != 0:
        return
    _start_dive(facing.rotated(PI / 2.0 * float(side)))

func gk_dash() -> void:
    if role != 0 or getup_t > 0.0 or dive_t > 0.0 or dash_t > 0.0 or dash_cd > 0.0:
        return
    if has_ball():
        return
    var tgt: Vector2 = ball.global_position
    var h = ball.holder
    if h != null and h != self:
        tgt = h.global_position + h.velocity * 0.12
    var dv: Vector2 = tgt - global_position
    if dv.length() < 8.0:
        dv = facing
    dive_vec = dv.normalized()
    dash_t = 0.7
    state = St.DASH

func gk_exit() -> void:
    if role != 0 or getup_t > 0.0 or dive_t > 0.0 or dash_t > 0.0:
        return
    if ball.holder == self:
        _gk_release(move_input)
    elif ball.holder == null and global_position.distance_to(ball.global_position) < 55.0 and kick_lock <= 0.0:
        var d: Vector2 = facing.rotated(randf_range(-0.3, 0.3))
        if move_input.length() > 0.3:
            d = move_input.normalized()
        ball.kick(d, 820.0, randf_range(-0.3, 0.3), self, 300.0)
    elif ball.holder != null and ball.holder.team != team and global_position.distance_to(ball.holder.global_position) < 115.0 and dash_cd <= 0.0:
        gk_dash()
    elif rush_cd <= 0.0:
        rush_t = 1.0
        rush_cd = 2.5

func _gk_release(aim: Vector2) -> void:
    if ball.holder != self:
        return
    hold_t = 0.0
    if aim.length() > 0.3 or not is_human:
        var ad: Vector2 = Vector2.ZERO
        if aim.length() > 0.3:
            ad = aim.normalized()
        var t = main.find_pass_target(self, ad)
        if t != null:
            do_pass(aim)
            return
    var d: Vector2 = Vector2(dir_x, 0.0).rotated(randf_range(-0.25, 0.25))
    if aim.length() > 0.3:
        d = aim.normalized()
    ball.kick(d, 760.0, randf_range(-0.2, 0.2), self, 330.0)

func _gk_contact() -> void:
    var h = ball.holder
    var bp: Vector2 = ball.global_position
    var d: float = global_position.distance_to(bp)
    if h != null:

        if h != self and h.team != team and h.role != 0 and h.shield_t <= 0.0 and d < (60.0 if state == St.DASH else 36.0) and steal_cd <= 0.0 and getup_t <= 0.0:
            steal_cd = 1.0
            if state == St.DASH:

                if randf() < 0.8:
                    h.kick_lock = 0.6
                    ball.holder = null
                    ball.vel = (Vector2(dir_x, 0.0) * 0.8 + Vector2(0.0, signf(bp.y - global_position.y)) * 0.6).normalized() * 340.0
                    ball.touch(self)
                    ball.last_team = team
                    kick_lock = 0.4
            elif randf() < 0.5:
                h.kick_lock = 0.6
                ball.give_to(self)
                hold_t = 0.0
        return
    if kick_lock > 0.0 or getup_t > 0.0:
        return
    var reach: float = 27.0
    var zmax: float = 48.0
    if state == St.DIVE:
        reach = 56.0
        zmax = 75.0
    elif state == St.DASH:
        reach = 62.0
        zmax = 40.0
    if d > reach:
        return
    if ball.z > zmax:
        return
    var sp: float = ball.vel.length()
    if ball.shooter != null and is_instance_valid(ball.shooter) and ball.shooter.team != team and sp > 250.0:
        _stat("saves")
        ball.shooter = null
        _say("СЕЙВ!", Color(0.4, 0.9, 1.0))
        G.sfx("save")
    if state == St.DASH and sp > 220.0:

        if randf() < 0.88:
            var away: Vector2 = (bp - global_position).normalized() * 0.6 + Vector2(dir_x, 0.0) * 0.7
            ball.vel = away.normalized() * maxf(sp * 0.45, 300.0)
            ball.vz = 70.0
            ball.z = maxf(ball.z, 1.0)
            ball.touch(self)
            ball.last_team = team
            kick_lock = 0.45
            G.sfx("block")
            return
    var chance: float = 0.92
    if sp > 750.0:
        chance = 0.35
    elif sp > 480.0:
        chance = 0.6
    elif sp > 200.0:
        chance = 0.82
    if state == St.DIVE:
        chance += 0.2
    if not is_human:
        chance *= (0.6 + 0.4 * bot_k)
    if sp < 120.0 or randf() < chance:
        ball.give_to(self)
        hold_t = 0.0
    else:
        var out: Vector2 = (bp - global_position).normalized()
        var nv: Vector2 = out * 0.7 + Vector2(dir_x, 0.0) * 0.5 + Vector2(0.0, randf_range(-0.6, 0.6))
        ball.vel = nv.normalized() * maxf(sp * 0.55, 260.0)
        ball.touch(self)
        ball.last_team = team
        kick_lock = 0.4

func _clamp_position() -> void:
    var p: Vector2 = global_position
    if role == 0:
        var gx: float = -G.HALF_W * dir_x
        var x0: float = gx + dir_x * 16.0
        var x1: float = gx + dir_x * G.PEN_DEPTH
        p.x = clampf(p.x, minf(x0, x1), maxf(x0, x1))
        p.y = clampf(p.y, -(G.PEN_HALF - 16.0), G.PEN_HALF - 16.0)
    else:
        p.x = clampf(p.x, -G.HALF_W + 16.0, G.HALF_W - 16.0)
        p.y = clampf(p.y, -G.HALF_H + 16.0, G.HALF_H - 16.0)
    global_position = p

var _last_pos: Vector2 = Vector2.ZERO
var _spd: float = 0.0
var _prev_kick_t: float = 0.0

func _process(delta: float) -> void:
    if G.headless:
        return
    if main == null:
        if kick_t > _prev_kick_t + 0.05:
            G.sfx("kick_high" if kick_kind == 2 else "kick_low")
        kick_t = maxf(0.0, kick_t - delta)
    _prev_kick_t = kick_t
    if delta > 0.0:
        var v: float = global_position.distance_to(_last_pos) / delta
        _spd = lerpf(_spd, minf(v, 400.0), clampf(12.0 * delta, 0.0, 1.0))
    _last_pos = global_position
    run_phase += _spd * delta * 0.07
    if main != null and _spd > 210.0 and G.gfx >= 1 and randf() < 0.12 and main.has_method("burst"):
        main.burst(global_position + Vector2(0, 8), Color(0.7, 0.85, 0.5, 0.5), 1, 30.0, 0.35)
    queue_redraw()

func _limb(a: Vector2, b: Vector2, w: float, col: Color) -> void:
    draw_line(a, b, col, w)
    draw_circle(a, w * 0.5, col)
    draw_circle(b, w * 0.5, col)

func _kit() -> Array:

    if role == 0:
        if team == 0:
            return [Color(0.1, 0.78, 0.6), Color(0.05, 0.5, 0.4), Color(0.1, 0.12, 0.16), Color(0.1, 0.78, 0.6), Color(1, 0.95, 0.3)]
        return [Color(1.0, 0.75, 0.15), Color(0.8, 0.5, 0.05), Color(0.12, 0.1, 0.1), Color(1.0, 0.75, 0.15), Color(0.2, 0.9, 1.0)]
    var sc: Color = G.team_col(team)
    return [sc, G.team_trim(team), G.team_shorts(team), sc, Color(0.08, 0.08, 0.1)]

func _draw() -> void:
    var kit: Array = _kit()
    var shirt: Color = kit[0]
    var trim: Color = kit[1]
    var shorts: Color = kit[2]
    var socks: Color = kit[3]
    var boots: Color = kit[4]
    var skin: Color = Color(0.96, 0.78, 0.62)
    var hair: Color = Color(0.2, 0.13, 0.08) if num % 2 == 0 else Color(0.55, 0.38, 0.15)
    if recover_t > 0.0:
        shirt = shirt.darkened(0.3)
        trim = trim.darkened(0.3)
    var f: Font = ThemeDB.fallback_font

    if G.gfx >= 1:
        var lift: float = hop * 0.4
        var layers: int = 3 if G.gfx >= 2 else 2
        for k in layers:
            var kk: float = float(k) / float(layers)
            draw_set_transform(Vector2(8.0 + lift, 10.0 + lift * 0.6) * (1.0 - 0.3 * kk), 0.7, Vector2(1.95 - 0.5 * kk, 0.9 - 0.25 * kk))
            draw_circle(Vector2.ZERO, RADIUS, Color(0, 0, 0, (0.09 + 0.07 * kk) * (1.0 - clampf(lift / 20.0, 0.0, 0.4))))
        if G.gfx >= 2:
            draw_set_transform(Vector2(-6.0, 7.0), -0.8, Vector2(1.5, 0.7))
            draw_circle(Vector2.ZERO, RADIUS, Color(0, 0, 0, 0.06))
        draw_set_transform(Vector2(1.0, 3.0), 0.0, Vector2(1.0, 0.7))
        draw_circle(Vector2.ZERO, RADIUS * 0.8, Color(0, 0, 0, 0.24))
        draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    if is_human:
        var pulse: float = 0.5 + 0.5 * sin(Time.get_ticks_msec() / 150.0)
        draw_arc(Vector2.ZERO, 25.0 + pulse * 2.0, 0.0, TAU, 40, Color(1.0, 0.95, 0.2, 0.95), 3.0)
    if is_pass_target:
        draw_arc(Vector2.ZERO, 27.0, 0.0, TAU, 40, Color(0.3, 1.0, 1.0, 0.95), 3.0)
        draw_colored_polygon(PackedVector2Array([Vector2(0, -32), Vector2(-8, -46), Vector2(8, -46)]), Color(0.3, 1.0, 1.0))

    if hop > 0.0:
        draw_set_transform(Vector2(0, -hop), 0.0, Vector2.ONE * (1.0 + hop / 90.0))
        draw_arc(Vector2(0, hop), 18.0, 0.0, TAU, 24, Color(1, 1, 1, 0.5), 2.0)
    var run: float = clampf(_spd / 230.0, 0.0, 1.2)
    var sw: float = sin(run_phase)
    var airborne: bool = state == St.DIVE or state == St.GETUP
    var dashing: bool = state == St.DASH
    var ang: float = dive_vec.angle() if (airborne or dashing) else facing.angle()
    if skill_t > 0.0 and skill_kind == 1:
        ang += skill_spin * TAU * (1.0 - skill_t / FEINT_DUR)
    draw_set_transform(Vector2(0, -hop), ang, Vector2.ONE * (1.0 + hop / 90.0))

    if dashing:

        var sl: float = clampf((dash_t - 0.45) / 0.25, 0.0, 1.0)
        var spread: float = 22.0 - 6.0 * sl
        var reachx: float = 26.0 - 8.0 * sl
        _limb(Vector2(-3, -3), Vector2(reachx, -spread), 6.0, socks)
        _limb(Vector2(-3, 3), Vector2(reachx, spread), 6.0, socks)
        draw_circle(Vector2(reachx + 2, -spread), 4.2, boots)
        draw_circle(Vector2(reachx + 2, spread), 4.2, boots)
        draw_circle(Vector2(-3, 0), 8.0, shorts)
        draw_circle(Vector2(-7, 0), 8.6, shirt)
        draw_circle(Vector2(-7, 0), 8.6, trim, false, 2.0)
        _limb(Vector2(-5, -9), Vector2(5, -23), 4.6, trim)
        _limb(Vector2(-5, 9), Vector2(5, 23), 4.6, trim)
        draw_circle(Vector2(6, -24), 5.0, boots)
        draw_circle(Vector2(6, 24), 5.0, boots)
        draw_circle(Vector2(-5, 0), 6.0, hair)
        draw_circle(Vector2(-2, 0), 3.0, skin)
        if G.gfx >= 1:

            for q in 4:
                var qq: float = float(q)
                draw_circle(Vector2(-18.0 - qq * 7.0, sin(qq * 2.3 + run_phase) * 10.0), 2.5 - qq * 0.4, Color(0.75, 0.9, 0.6, 0.45))
    elif airborne:

        var gl: Color = boots
        var st: float = 1.0 if state == St.DIVE else 0.5
        _limb(Vector2(-6, -3), Vector2(-20 * st - 4, -4), 5.0, socks)
        _limb(Vector2(-6, 3), Vector2(-20 * st - 4, 4), 5.0, socks)
        _limb(Vector2(-3, 0), Vector2(-14 * st, 0), 9.0, shorts)
        draw_circle(Vector2(0, 0), 9.5, shirt)
        draw_circle(Vector2(0, 0), 9.5, trim, false, 2.0)
        _limb(Vector2(5, -6), Vector2(14 + 12 * st, -6), 4.5, trim)
        _limb(Vector2(5, 6), Vector2(14 + 12 * st, 6), 4.5, trim)
        draw_circle(Vector2(16 + 12 * st, -6), 4.6, gl)
        draw_circle(Vector2(16 + 12 * st, 6), 4.6, gl)
        draw_circle(Vector2(6, 0), 6.0, hair)
        draw_circle(Vector2(9, 0), 3.0, skin)
    elif state == St.TACKLE:

        _limb(Vector2(-4, 5), Vector2(-14, 8), 5.0, socks)
        _limb(Vector2(2, -4), Vector2(26, -3), 5.5, socks)
        draw_circle(Vector2(27, -3), 4.0, boots)
        _limb(Vector2(-2, 0), Vector2(8, 0), 9.0, shorts)
        draw_circle(Vector2(-3, 0), 9.0, shirt)
        _limb(Vector2(0, -9), Vector2(-6, -15), 4.0, trim)
        _limb(Vector2(0, 9), Vector2(8, 14), 4.0, trim)
        draw_circle(Vector2(4, 0), 6.3, hair)
        draw_circle(Vector2(7, 0), 3.0, skin)
    else:
        var kp: float = 0.0
        if kick_t > 0.0:
            kp = 1.0 - kick_t / KICK_ANIM
        var lean: float = 0.0

        var lx: float = sw * 8.0 * run
        var rx: float = -sw * 8.0 * run
        var rfoot_scale: float = 1.0
        var rfoot_y: float = 5.0
        if kick_t > 0.0:
            var swing: float = 0.0
            if kp < 0.35:
                swing = lerpf(-9.0, -13.0, kp / 0.35)
            elif kp < 0.6:
                swing = lerpf(-13.0, 21.0 if kick_kind == 1 else 17.0, (kp - 0.35) / 0.25)
            else:
                swing = lerpf(21.0 if kick_kind == 1 else 17.0, 4.0, (kp - 0.6) / 0.4)
            rx = swing
            if kick_kind == 2:

                var up: float = sin(clampf((kp - 0.3) / 0.45, 0.0, 1.0) * PI)
                rfoot_scale = 1.0 + 0.7 * up
                rfoot_y = 5.0 - 2.0 * up
                lean = -2.5 * up
            else:
                lean = 1.5 * sin(clampf((kp - 0.3) / 0.4, 0.0, 1.0) * PI)

        _limb(Vector2(0, -4), Vector2(lx, -5), 5.0, socks)
        draw_circle(Vector2(lx + 2, -5), 3.6, boots)

        _limb(Vector2(0, 4), Vector2(rx, rfoot_y), 5.0, socks)
        draw_circle(Vector2(rx + 2, rfoot_y), 3.6 * rfoot_scale, boots)
        if kick_t > 0.0 and kp > 0.3 and kp < 0.8:

            var a0: float = clampf((kp - 0.3) / 0.5, 0.0, 1.0)
            var col: Color = Color(1, 1, 1, 0.55 * (1.0 - a0))
            if kick_kind == 2:
                draw_arc(Vector2(2, 6), 17.0, -1.4, 0.2, 14, Color(1.0, 0.95, 0.5, 0.7 * (1.0 - a0)), 3.0)
            else:
                draw_line(Vector2(6, 5), Vector2(28, 5), col, 3.0)

        draw_circle(Vector2(lean * 0.3, 0), 8.0, shorts)
        var sh_pts := PackedVector2Array()
        for k in 20:
            var t: float = float(k) / 20.0 * TAU
            sh_pts.append(Vector2(cos(t) * 7.5 + lean, sin(t) * 11.5))
        draw_colored_polygon(sh_pts, shirt)
        draw_polyline(sh_pts, trim, 1.8)
        draw_line(Vector2(lean - 1, -9), Vector2(lean - 1, 9), trim, 2.0)

        var ax: float = -sw * 6.0 * run
        if kick_t > 0.0:
            ax = -4.0 if kick_kind == 1 else -7.0
        _limb(Vector2(lean, -10), Vector2(lean + ax, -14), 4.0, trim)
        _limb(Vector2(lean, 10), Vector2(lean - ax + 1.0, 14), 4.0, trim)
        draw_circle(Vector2(lean + ax, -14), 2.6, boots if role == 0 else skin)
        draw_circle(Vector2(lean - ax + 1.0, 14), 2.6, boots if role == 0 else skin)

        if hands_up:
            _limb(Vector2(lean, -9), Vector2(lean + 12, -6), 4.2, trim)
            _limb(Vector2(lean, 9), Vector2(lean + 12, 6), 4.2, trim)
            draw_circle(Vector2(lean + 13, -6), 3.2, skin)
            draw_circle(Vector2(lean + 13, 6), 3.2, skin)
        draw_circle(Vector2(1.5 + lean, 0), 6.4, hair)
        draw_circle(Vector2(4.5 + lean, 0), 3.2, skin)
        draw_circle(Vector2(1.0 + lean, -6.2), 1.7, skin)
        draw_circle(Vector2(1.0 + lean, 6.2), 1.7, skin)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

    if not airborne and not dashing and state != St.TACKLE:
        draw_string(f, Vector2(-8, -20), str(num), HORIZONTAL_ALIGNMENT_CENTER, 16, 11, Color(1, 1, 1, 0.9), 0)
    if yellow > 0:
        draw_rect(Rect2(10, -32, 7, 10), Color(1.0, 0.9, 0.1))
        draw_rect(Rect2(10, -32, 7, 10), Color(0, 0, 0, 0.7), false, 1.0)
    if nick != "":
        var nc: Color = Color(1, 0.95, 0.4) if is_human else Color(1, 1, 1, 0.85)
        draw_string(f, Vector2(-60, -44), nick, HORIZONTAL_ALIGNMENT_CENTER, 120, 13, nc)

    if shield_t > 0.0:

        var pt: float = Time.get_ticks_msec() / 1000.0
        draw_circle(Vector2.ZERO, 22.0, Color(1, 1, 1, 0.30))
        draw_arc(Vector2.ZERO, 24.0 + 4.0 * sin(pt * 16.0), 0.0, TAU, 32, Color(1, 1, 1, 0.95), 3.0)
        for q in 6:
            var aa: float = pt * 7.0 + float(q) * TAU / 6.0
            draw_line(Vector2(cos(aa), sin(aa)) * 20.0, Vector2(cos(aa), sin(aa)) * 31.0, Color(1, 1, 1, 0.85), 2.0)

    if is_human:
        if charging:
            var t3: float = clampf(charge, 0.0, 1.0)
            var hi: bool = charge >= HIGH_CHARGE
            draw_rect(Rect2(-22, -38, 44, 7), Color(0, 0, 0, 0.65))
            draw_rect(Rect2(-22, -38, 44.0 * t3, 7), Color(0.3, 0.8, 1.0) if hi else Color(1.0, 0.85, 0.2))
            draw_line(Vector2(-22.0 + 44.0 * HIGH_CHARGE, -39), Vector2(-22.0 + 44.0 * HIGH_CHARGE, -30), Color.WHITE, 1.5)
            draw_string(f, Vector2(-40, -42), "ВЕРХОМ" if hi else "НИЗОМ", HORIZONTAL_ALIGNMENT_CENTER, 80, 10, Color(1, 1, 1, 0.9))
        var by: float = 24.0
        if role != 0:
            if tackle_cd > 0.0 or recover_t > 0.0:
                var frac: float = 1.0 - clampf(tackle_cd / 1.0, 0.0, 1.0)
                draw_rect(Rect2(-18, by, 36, 3), Color(0, 0, 0, 0.6))
                draw_rect(Rect2(-18, by, 36.0 * frac, 3), Color(1.0, 0.6, 0.2))
        else:
            if dive_cd > 0.0:
                draw_rect(Rect2(-18, by, 36, 3), Color(0, 0, 0, 0.6))
                draw_rect(Rect2(-18, by, 36.0 * (1.0 - dive_cd / 1.2), 3), Color(0.3, 0.7, 1.0))
