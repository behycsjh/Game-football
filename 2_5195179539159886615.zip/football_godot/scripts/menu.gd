extends Control

const CFG_PATH := "user://profile.cfg"
const BLUE := Color(0.45, 0.7, 1.0)
const RED := Color(1.0, 0.45, 0.45)
const YEL := Color(1.0, 0.92, 0.45)

var cfg := ConfigFile.new()
var content: Control
var screen: String = ""
var status: Label = null
var nick_edit: LineEdit
var addr_edit: LineEdit
var code_edit: LineEdit
var rename_edit: LineEdit
var lb_title: Label
var lb_timer: Label
var lb_blue: Label
var lb_red: Label
var btn_start: Button
var st_me: Label
var st_board: Label

func _ready() -> void:
    cfg.load(CFG_PATH)
    var bg := ColorRect.new()
    bg.color = Color(0.05, 0.22, 0.1)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    content = Control.new()
    content.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(content)
    Net.login_ok.connect(_on_login_ok)
    Net.login_failed.connect(_on_login_failed)
    Net.disconnected.connect(_on_disc)
    Net.info.connect(_on_info)
    Net.room_updated.connect(_on_room)
    Net.started.connect(_on_started)
    Net.stats_received.connect(_on_stats)
    Net.error_msg.connect(_on_info)
    if Net.in_match:
        _on_started.call_deferred()
    elif Net.logged_in:
        if Net.searching:
            _show_lobby()
        else:
            _show_home()
    else:
        _show_connect(Net.last_error)

var _tw: Tween = null
var _su_mode: int = 0
var _su_train: String = ""

func _clear(anim: bool = true) -> VBoxContainer:
    for c in content.get_children():
        c.queue_free()
    status = null
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    content.add_child(cc)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 12)
    v.custom_minimum_size = Vector2(800, 0)
    cc.add_child(v)
    if _tw != null and _tw.is_valid():
        _tw.kill()
    if anim:
        content.modulate.a = 0.0
        content.position = Vector2(0, 18)
        _tw = create_tween().set_parallel(true)
        _tw.tween_property(content, "modulate:a", 1.0, 0.25)
        _tw.tween_property(content, "position:y", 0.0, 0.25).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    else:
        content.modulate.a = 1.0
        content.position = Vector2.ZERO
    return v

func _lbl(parent: Control, text: String, size: int = 24, col: Color = Color.WHITE, align: int = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", col)
    l.horizontal_alignment = align
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    parent.add_child(l)
    return l

func _btn(parent: Control, text: String, cb: Callable, h: float = 64.0, size: int = 26) -> Button:
    var b := Button.new()
    b.text = text
    b.add_theme_font_size_override("font_size", size)
    b.custom_minimum_size = Vector2(0, h)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.pressed.connect(cb)
    parent.add_child(b)
    return b

func _row(parent: Control) -> HBoxContainer:
    var r := HBoxContainer.new()
    r.add_theme_constant_override("separation", 10)
    parent.add_child(r)
    return r

func _edit(parent: Control, hint: String, text: String) -> LineEdit:
    var e := LineEdit.new()
    e.placeholder_text = hint
    e.text = text
    e.add_theme_font_size_override("font_size", 24)
    e.custom_minimum_size = Vector2(0, 56)
    e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    parent.add_child(e)
    return e

func _say(msg: String) -> void:
    if status != null and is_instance_valid(status):
        status.text = msg

func _show_connect(msg: String = "") -> void:
    screen = "connect"
    var v := _clear()
    _lbl(v, "ФУТБОЛ ОНЛАЙН", 60)
    status = _lbl(v, msg, 20, YEL)
    nick_edit = _edit(v, "Ваш ник (3–14 символов)", str(cfg.get_value("p", "nick", "")))
    addr_edit = _edit(v, "Адрес сервера", str(cfg.get_value("p", "server", G.DEFAULT_SERVER)))
    _btn(v, "ИГРАТЬ ОНЛАЙН", _on_connect_pressed, 72, 30)
    _btn(v, "ТРЕНИРОВКА (без интернета)", _show_training, 56, 24)
    _btn(v, "НАСТРОЙКИ (музыка, звук, графика)", _show_settings, 48, 20)
    if OS.has_feature("pc"):
        _btn(v, "Создать сервер на этом ПК (для игры по LAN)", _on_host_pressed, 52, 20)
    _lbl(v, "Ник и статистика привязаны к этому устройству. Друзьям дай адрес сервера.", 16, Color(1, 1, 1, 0.6))

func _on_connect_pressed() -> void:
    var nick: String = nick_edit.text.strip_edges()
    if nick.length() < 3:
        _say("Введите ник (минимум 3 символа)")
        return
    var token: String = str(cfg.get_value("p", "token", ""))
    if token == "":
        token = Crypto.new().generate_random_bytes(12).hex_encode()
    cfg.set_value("p", "token", token)
    cfg.set_value("p", "nick", nick)
    cfg.set_value("p", "server", addr_edit.text.strip_edges())
    cfg.save(CFG_PATH)
    Net.my_nick = nick
    Net.my_token = token
    _say("Подключение… (бесплатный сервер может просыпаться до минуты)")
    Net.connect_to(addr_edit.text)

func _on_host_pressed() -> void:
    if Net.host_local_server():
        addr_edit.text = "127.0.0.1"
        _say("Запускаю сервер…")
        await get_tree().create_timer(2.0).timeout
        if screen == "connect":
            _on_connect_pressed()
    else:
        _say("Не удалось запустить сервер")

func _show_training() -> void:
    screen = "train"
    var v := _clear()
    _lbl(v, "ТРЕНИРОВКА (офлайн)", 44)
    _btn(v, "Соло: удары по воротам (ты с мячом против вратаря)", _show_setup.bind(0, "solo"), 60, 22)
    _btn(v, "1 на 1 с ботом", _show_setup.bind(0, "1v1"), 60, 22)
    _btn(v, "Матч против ботов (команда, формации, настройки)", _show_setup.bind(0, ""), 60, 22)
    _btn(v, "Серия пенальти", _show_setup.bind(0, "shootout"), 60, 22)
    _btn(v, "Играть только за вратаря", _show_setup.bind(1, ""), 60, 22)
    _btn(v, "Назад", _train_back, 52, 24)

func _train_back() -> void:
    if Net.logged_in:
        _show_home()
    else:
        _show_connect("")

# ---------------------------------------------------------------- экран выбора команды, формации и настроек матча
func _mini(parent: Control, text: String, cb: Callable) -> Button:
    var b := Button.new()
    b.text = text
    b.add_theme_font_size_override("font_size", 22)
    b.custom_minimum_size = Vector2(80, 46)
    b.pressed.connect(cb)
    parent.add_child(b)
    return b

func _stepper(parent: Control, text: String, col: Color, on_prev: Callable, on_next: Callable, swatch: int = -1) -> void:
    var r := _row(parent)
    _mini(r, "◀", on_prev)
    if swatch >= 0:
        var sw := ColorRect.new()
        sw.color = G.TEAMS[swatch]["c"]
        sw.custom_minimum_size = Vector2(34, 34)
        sw.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        r.add_child(sw)
        var sw2 := ColorRect.new()
        sw2.color = G.TEAMS[swatch]["t"]
        sw2.custom_minimum_size = Vector2(14, 34)
        sw2.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        r.add_child(sw2)
    _lbl(r, text, 22, col)
    _mini(r, "▶", on_next)

func _show_setup(mode: int, train: String, anim: bool = true) -> void:
    screen = "setup"
    _su_mode = mode
    _su_train = train
    var v := _clear(anim)
    v.add_theme_constant_override("separation", 7)
    var title: String = "МАТЧ ПРОТИВ БОТОВ"
    if mode == 1:
        title = "ИГРА ЗА ВРАТАРЯ"
    elif train == "1v1":
        title = "1 НА 1 С БОТОМ"
    elif train == "solo":
        title = "СОЛО: УДАРЫ ПО ВОРОТАМ"
    elif train == "shootout":
        title = "СЕРИЯ ПЕНАЛЬТИ"
    _lbl(v, title, 38)
    if int(G.pick[0]) == int(G.pick[1]):
        G.pick[1] = (int(G.pick[1]) + 1) % G.TEAMS.size()
    var t0: int = int(G.pick[0])
    var t1: int = int(G.pick[1])
    _stepper(v, "ВАША КОМАНДА: " + String(G.TEAMS[t0]["name"]), Color(1, 0.95, 0.5), _chg_team.bind(0, -1), _chg_team.bind(0, 1), t0)
    if train != "solo":
        _stepper(v, "СОПЕРНИК: " + String(G.TEAMS[t1]["name"]), Color(1, 0.75, 0.75), _chg_team.bind(1, -1), _chg_team.bind(1, 1), t1)
    if train == "":
        var f0: int = int(G.form_pick[0])
        var f1: int = int(G.form_pick[1])
        _stepper(v, "ВАША ФОРМАЦИЯ: %s (%s)" % [G.FORM_NAMES[f0], G.formation_label(G.team_size, f0)], Color.WHITE, _chg_form.bind(0, -1), _chg_form.bind(0, 1))
        _stepper(v, "ФОРМАЦИЯ СОПЕРНИКА: %s (%s)" % [G.FORM_NAMES[f1], G.formation_label(G.team_size, f1)], Color.WHITE, _chg_form.bind(1, -1), _chg_form.bind(1, 1))
        _stepper(v, "ИГРОКОВ В КОМАНДЕ: %d (с вратарём)" % G.team_size, Color.WHITE, _chg_size.bind(-1), _chg_size.bind(1))
    if train == "" or train == "1v1":
        var secs: int = int(G.half_time)
        _stepper(v, "ДЛИТЕЛЬНОСТЬ ТАЙМА: %d:%02d" % [floori(float(secs) / 60.0), secs % 60], Color.WHITE, _chg_half.bind(-1), _chg_half.bind(1))
        var rr := _row(v)
        _btn(rr, "ОФСАЙД: " + ("ВКЛ" if G.offside_on else "ВЫКЛ"), _tog.bind("offside"), 46, 20)
        _btn(rr, "ПЕНАЛЬТИ ПРИ НИЧЬЕЙ: " + ("ВКЛ" if G.shootout_on else "ВЫКЛ"), _tog.bind("shootout"), 46, 20)
    var mr := _row(v)
    _btn(mr, "МУЗЫКА: " + ("ВКЛ" if G.music_on else "ВЫКЛ"), _tog.bind("music"), 46, 20)
    _btn(mr, "ТРЕК: " + String(G.TRACKS[G.music_track]["name"]), _tog.bind("track"), 46, 20)
    var br := _row(v)
    _btn(br, "СТАРТ", _su_start, 60, 28)
    _btn(br, "Назад", _show_training, 60, 24)

func _chg_team(side: int, d: int) -> void:
    var n: int = G.TEAMS.size()
    var other: int = int(G.pick[1 - side])
    var v: int = posmod(int(G.pick[side]) + d, n)
    if v == other:
        v = posmod(v + d, n)
    G.pick[side] = v
    _show_setup(_su_mode, _su_train, false)

func _chg_form(side: int, d: int) -> void:
    G.form_pick[side] = posmod(int(G.form_pick[side]) + d, 3)
    _show_setup(_su_mode, _su_train, false)

func _chg_size(d: int) -> void:
    G.team_size = clampi(G.team_size + d, 3, 7)
    _show_setup(_su_mode, _su_train, false)

func _chg_half(d: int) -> void:
    var idx: int = G.HALF_OPTS.find(G.half_time)
    if idx < 0:
        idx = 2
    idx = posmod(idx + d, G.HALF_OPTS.size())
    G.half_time = float(G.HALF_OPTS[idx])
    _show_setup(_su_mode, _su_train, false)

func _tog(what: String) -> void:
    match what:
        "offside":
            G.offside_on = not G.offside_on
        "shootout":
            G.shootout_on = not G.shootout_on
        "music":
            G.music_on = not G.music_on
            G.apply_settings()
        "track":
            G.music_track = (G.music_track + 1) % G.TRACKS.size()
            G.music_on = true
            G.apply_settings()
        "sound":
            G.sound_on = not G.sound_on
            G.apply_settings()
        "comm":
            G.comm_on = not G.comm_on
        "gfx":
            G.gfx = (G.gfx + 1) % 3
            G.apply_settings()
        "vd":
            G.volume = clampf(G.volume - 0.1, 0.0, 1.0)
            G.apply_settings()
        "vu":
            G.volume = clampf(G.volume + 0.1, 0.0, 1.0)
            G.sound_on = true
            G.apply_settings()
    if screen == "settings":
        _show_settings(false)
    else:
        _show_setup(_su_mode, _su_train, false)

func _su_start() -> void:
    if int(G.pick[0]) == int(G.pick[1]):
        G.pick[1] = (int(G.pick[1]) + 1) % G.TEAMS.size()
    G.save_settings()
    G.mode = _su_mode
    G.train = _su_train
    G.goto("res://scenes/Main.tscn")

func _show_settings(anim: bool = true) -> void:
    screen = "settings"
    var v := _clear(anim)
    _lbl(v, "НАСТРОЙКИ", 44)
    _btn(v, "ГРАФИКА: " + String(G.GFX_NAMES[G.gfx]), _tog.bind("gfx"), 56, 24)
    _btn(v, "ЗВУК: " + ("ВКЛ" if G.sound_on else "ВЫКЛ"), _tog.bind("sound"), 56, 24)
    var r := _row(v)
    _btn(r, "−", _tog.bind("vd"), 56, 28)
    _lbl(r, "Громкость %d%%" % int(round(G.volume * 100.0)), 24)
    _btn(r, "+", _tog.bind("vu"), 56, 28)
    var mr := _row(v)
    _btn(mr, "МУЗЫКА: " + ("ВКЛ" if G.music_on else "ВЫКЛ"), _tog.bind("music"), 56, 22)
    _btn(mr, "ТРЕК: " + String(G.TRACKS[G.music_track]["name"]), _tog.bind("track"), 56, 22)
    _btn(v, "КОММЕНТАТОР: " + ("ВКЛ" if G.comm_on else "ВЫКЛ"), _tog.bind("comm"), 56, 24)
    _btn(v, "Назад", _settings_back, 56, 24)

func _settings_back() -> void:
    G.save_settings()
    _train_back()

func _on_login_ok() -> void:
    cfg.set_value("p", "nick", str(Net.profile.get("nick", "")))
    cfg.save(CFG_PATH)
    _show_home()

func _on_login_failed(msg: String) -> void:
    _show_connect(msg)

func _on_disc(reason: String) -> void:
    _show_connect(reason)

func _on_info(msg: String) -> void:
    _say(msg)

func _on_started() -> void:
    G.goto("res://scenes/NetGame.tscn")

func _show_home() -> void:
    screen = "home"
    var v := _clear()
    _lbl(v, "%s   •   рейтинг %d" % [Net.profile.get("nick", "?"), int(Net.profile.get("rating", 1000))], 34, YEL)
    status = _lbl(v, Net.host_ips, 18, Color(0.8, 1, 0.8))
    _lbl(v, "БЫСТРАЯ ИГРА (пустые места займут боты через %d с)" % int(G.MM_WAIT), 22)
    var r := _row(v)
    for n in range(1, 5):
        _btn(r, "%d на %d" % [n, n], _quick.bind(n), 76, 28)
    _lbl(v, "ИГРА С ДРУЗЬЯМИ — создать комнату с кодом", 22)
    var r2 := _row(v)
    for n in range(1, 5):
        _btn(r2, "%dx%d" % [n, n], _create.bind(n), 56, 24)
    var r3 := _row(v)
    code_edit = _edit(r3, "Код комнаты", "")
    _btn(r3, "Войти по коду", _join_code, 56, 22)
    var r4 := _row(v)
    _btn(r4, "Статистика", _show_stats, 56, 22)
    _btn(r4, "Тренировка", _show_training, 56, 22)
    _btn(r4, "Настройки", _show_settings, 56, 22)
    _btn(r4, "Выйти", _logout, 56, 22)

func _quick(n: int) -> void:
    Net.quick_match(n)
    _show_lobby()

func _create(n: int) -> void:
    Net.create_room(n)
    _show_lobby()

func _join_code() -> void:
    var c: String = code_edit.text.strip_edges()
    if c.length() < 3:
        _say("Введите код комнаты")
        return
    Net.join_code(c)

func _logout() -> void:
    Net.disconnect_now()
    _show_connect("")

func _show_lobby() -> void:
    screen = "lobby"
    var v := _clear()
    lb_title = _lbl(v, "Поиск игроков…", 38)
    lb_timer = _lbl(v, "", 24, YEL)
    var r := _row(v)
    lb_blue = _lbl(r, "", 26, BLUE, HORIZONTAL_ALIGNMENT_LEFT)
    lb_red = _lbl(r, "", 26, RED, HORIZONTAL_ALIGNMENT_LEFT)
    status = _lbl(v, "", 20, YEL)
    var br := _row(v)
    _btn(br, "Сменить команду", Net.switch_team, 60, 22)
    btn_start = _btn(br, "Старт (боты займут места)", Net.start_room, 60, 22)
    _btn(br, "Выйти", _leave_lobby, 60, 22)
    _update_lobby()

func _on_room() -> void:
    if screen != "lobby":
        _show_lobby()
    else:
        _update_lobby()

func _update_lobby() -> void:
    if lb_title == null or not is_instance_valid(lb_title):
        return
    var info: Dictionary = Net.room_info
    if info.is_empty():
        lb_title.text = "Поиск игроков…"
        lb_blue.text = ""
        lb_red.text = ""
        btn_start.visible = false
        return
    var n: int = int(info["n"])
    lb_title.text = "%d на %d" % [n, n]
    if info["pub"]:
        lb_timer.text = "Старт через %d с — пустые места займут боты" % int(info["start_in"])
    else:
        lb_timer.text = "Код комнаты: %s  (скажи друзьям)" % str(info["code"])
    var b := "СИНИЕ\n"
    var rr := "КРАСНЫЕ\n"
    for m in info["members"]:
        var line: String = "• %s (%d)\n" % [m["nick"], int(m["rating"])]
        if int(m["team"]) == 0:
            b += line
        else:
            rr += line
    lb_blue.text = b
    lb_red.text = rr
    btn_start.visible = bool(info["pub"]) or bool(info["is_host"])

func _leave_lobby() -> void:
    Net.leave_room()
    _show_home()

func _show_stats() -> void:
    screen = "stats"
    var v := _clear()
    _lbl(v, "СТАТИСТИКА", 44)
    st_me = _lbl(v, "Загрузка…", 22, YEL)
    _lbl(v, "ТОП ИГРОКОВ", 26)
    st_board = _lbl(v, "", 20, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    var r := _row(v)
    rename_edit = _edit(r, "Новый ник", "")
    _btn(r, "Сменить ник", _do_rename, 56, 22)
    status = _lbl(v, "", 18, YEL)
    _btn(v, "Назад", _show_home, 56, 24)
    Net.get_stats()

func _do_rename() -> void:
    Net.rename(rename_edit.text)

func _on_stats(me: Dictionary, board: Array) -> void:
    if screen != "stats" or st_me == null or not is_instance_valid(st_me):
        return
    var md: Dictionary = me.get("modes", {})
    var modes := ""
    for n in range(1, 5):
        var d: Dictionary = md.get("m%d" % n, {})
        if not d.is_empty():
            modes += "   %dx%d: %d/%d" % [n, n, int(d.get("wins", 0)), int(d.get("games", 0))]
    st_me.text = "%s — рейтинг %d\nИгр: %d   Побед: %d   Ничьих: %d   Поражений: %d\nГолы: %d   Передачи: %d\nФолы: %d   Жёлтые: %d   Красные: %d\nПобед/игр по режимам:%s" % [
        me.get("nick", "?"), int(me.get("rating", 0)), int(me.get("games", 0)), int(me.get("wins", 0)),
        int(me.get("draws", 0)), int(me.get("losses", 0)), int(me.get("goals", 0)), int(me.get("assists", 0)),
        int(me.get("fouls", 0)), int(me.get("yellows", 0)), int(me.get("reds", 0)),
        modes if modes != "" else " —"]
    var t := ""
    for i in board.size():
        var e: Dictionary = board[i]
        t += "%d. %s — %d  (побед %d из %d, голов %d, фолов %d, ЖК %d, КК %d)\n" % [i + 1, e["nick"], int(e["rating"]), int(e["wins"]), int(e["games"]), int(e["goals"]), int(e.get("fouls", 0)), int(e.get("yellows", 0)), int(e.get("reds", 0))]
    st_board.text = t if t != "" else "Пока никто не сыграл"
