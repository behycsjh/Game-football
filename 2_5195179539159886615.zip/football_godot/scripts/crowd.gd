extends Node2D
# Болельщики на трибунах: «волна» по периметру стадиона и подпрыгивание после гола.

const WAVE_SPEED := 520.0
const WAVE_WIDTH := 260.0
const WAVE_EVERY := 32.0
const WAVE_LEN := 11.0

var fans: Array = []
var perim: float = 1.0
var t: float = 0.0
var wave_t: float = -1.0
var next_wave: float = 14.0
var _acc: float = 0.0
var _was_active: bool = true

func _ready() -> void:
    if G.headless:
        set_process(false)
        return
    _build()
    G.settings_changed.connect(_rebuild)

func _rebuild() -> void:
    fans.clear()
    _build()
    queue_redraw()

func _build() -> void:
    if G.gfx < 1:
        return
    var hw: float = G.HALF_W
    var hh: float = G.HALF_H
    var rng := RandomNumberGenerator.new()
    rng.seed = 12345
    var cols: Array = [Color(0.9, 0.25, 0.25), Color(0.25, 0.5, 0.95), Color(0.95, 0.85, 0.3), Color(0.9, 0.9, 0.95), Color(0.3, 0.8, 0.45), Color(0.8, 0.5, 0.9)]
    var step: float = 14.0 if G.gfx >= 2 else 22.0
    var rows: int = 5 if G.gfx >= 2 else 3
    var w_top: float = hw * 2.0 + 120.0
    var side_len: float = hh * 2.0
    perim = 2.0 * w_top + 2.0 * side_len
    for side in [-1.0, 1.0]:
        var y0: float = side * (hh + 34.0)
        for r in rows:
            var yy: float = y0 + side * (10.0 + float(r) * 17.0)
            var x: float = -hw - 60.0
            while x < hw + 60.0:
                var c: Color = cols[rng.randi() % cols.size()]
                var b: float = rng.randf_range(0.55, 1.0)
                var u: float = (x + hw + 60.0) if side < 0.0 else (w_top + side_len + (hw + 60.0 - x))
                fans.append({"p": Vector2(x, yy), "c": c, "b": b, "u": u, "d": side, "side": false})
                x += step + rng.randf_range(-2.0, 2.0)
    for side in [-1.0, 1.0]:
        var x0: float = side * (hw + 80.0)
        var y: float = -hh
        while y < hh:
            var c2: Color = cols[rng.randi() % cols.size()]
            var px: float = x0 + side * rng.randf_range(10.0, 50.0)
            var u2: float = (w_top + (y + hh)) if side > 0.0 else (2.0 * w_top + side_len + (hh - y))
            fans.append({"p": Vector2(px, y), "c": c2, "b": rng.randf_range(0.55, 1.0), "u": u2, "d": side, "side": true})
            y += step * 0.7

func _wave_lift(u: float) -> float:
    if wave_t < 0.0:
        return 0.0
    var front: float = wave_t * WAVE_SPEED
    var d: float = absf(u - fmod(front, perim))
    d = minf(d, perim - d)
    return exp(-pow(d / (WAVE_WIDTH * 0.5), 2.0))

func _process(delta: float) -> void:
    if G.gfx < 1:
        return
    t += delta
    next_wave -= delta
    if next_wave <= 0.0 and wave_t < 0.0:
        wave_t = 0.0
        next_wave = WAVE_EVERY
    if wave_t >= 0.0:
        wave_t += delta
        if wave_t > WAVE_LEN:
            wave_t = -1.0
    var active: bool = wave_t >= 0.0 or G.cheer_t > 0.0
    _acc += delta
    if active and _acc >= 0.033:
        _acc = 0.0
        _was_active = true
        queue_redraw()
    elif not active and _was_active:
        _was_active = false
        queue_redraw()

func _draw() -> void:
    if G.gfx < 1:
        return
    var cheer: float = clampf(G.cheer_t, 0.0, 1.0)
    for fan in fans:
        var p: Vector2 = fan["p"]
        var c: Color = fan["c"]
        var b: float = fan["b"]
        var lift: float = _wave_lift(float(fan["u"]))
        if cheer > 0.0:
            lift = maxf(lift, cheer * (0.5 + 0.5 * sin(t * 14.0 + p.x * 0.05)))
        var dsg: float = float(fan["d"])
        var off: Vector2 = Vector2(0.0, dsg * -1.0 * lift * 9.0) if not bool(fan["side"]) else Vector2(-dsg * lift * 9.0, 0.0)
        var grow: float = 1.0 + 0.35 * lift
        var body: Color = Color(c.r * b, c.g * b, c.b * b).lerp(Color.WHITE, 0.25 * lift)
        draw_circle(p + off * 0.4 + Vector2(0, 3), 4.4 * grow, body)
        var head_off: Vector2 = Vector2(0.0, -2.0 * dsg) if not bool(fan["side"]) else Vector2(-2.0 * dsg, 0.0)
        draw_circle(p + off + head_off, 3.0 * grow, Color(0.95, 0.78, 0.62) * b)
        if lift > 0.35:
            var arm: Vector2 = off * 1.6
            draw_line(p + off * 0.4, p + arm, body, 2.0)
