extends Node

const HALF_W := 900.0
const HALF_H := 525.0
const GOAL_HALF := 105.0
const GOAL_DEPTH := 65.0
const POST_R := 5.0
const PEN_DEPTH := 250.0
const PEN_HALF := 285.0
const AREA_DEPTH := 95.0
const AREA_HALF := 150.0
const HALF_TIME := 150.0
const GOAL_PAUSE := 2.0
const POSTS = [Vector2(900, -105), Vector2(900, 105), Vector2(-900, -105), Vector2(-900, 105)]

const PROTO := 2
const PORT := 9080

const DEFAULT_SERVER := "ws://127.0.0.1:9080"
const MM_WAIT := 20.0
const MATCH_HALF := 150.0

# ---------------------------------------------------------------- команды / формации / треки
const TEAMS := [
    {"name": "СИНИЕ", "c": Color(0.18, 0.42, 0.98), "t": Color(0.1, 0.25, 0.7), "s": Color(1, 1, 1)},
    {"name": "КРАСНЫЕ", "c": Color(0.92, 0.2, 0.22), "t": Color(0.65, 0.1, 0.12), "s": Color(1, 1, 1)},
    {"name": "ОРАНЖЕВЫЕ", "c": Color(1.0, 0.55, 0.1), "t": Color(0.75, 0.35, 0.05), "s": Color(0.15, 0.15, 0.2)},
    {"name": "ФИОЛЕТОВЫЕ", "c": Color(0.62, 0.3, 0.9), "t": Color(0.4, 0.18, 0.65), "s": Color(1, 1, 1)},
    {"name": "БЕЛЫЕ", "c": Color(0.95, 0.95, 0.97), "t": Color(0.6, 0.62, 0.7), "s": Color(0.2, 0.25, 0.5)},
    {"name": "ЧЁРНЫЕ", "c": Color(0.2, 0.2, 0.24), "t": Color(0.05, 0.05, 0.08), "s": Color(0.9, 0.9, 0.9)},
    {"name": "ГОЛУБЫЕ", "c": Color(0.35, 0.8, 0.95), "t": Color(0.15, 0.55, 0.75), "s": Color(1, 1, 1)},
]
const FORM_NAMES := ["ЗАЩИТНАЯ", "СБАЛАНСИРОВАННАЯ", "АТАКУЮЩАЯ"]
const FORM_W := [[0.5, 0.3, 0.2], [0.25, 0.5, 0.25], [0.2, 0.3, 0.5]]
const HALF_OPTS := [60.0, 90.0, 150.0, 240.0, 300.0]
const TRACKS := [
    {"name": "СТАДИОН", "path": "res://assets/music/stadium.wav"},
    {"name": "РИТМ", "path": "res://assets/music/rhythm.wav"},
    {"name": "ДРАЙВ", "path": "res://assets/music/drive.wav"},
]
const COMM := {
    "start": ["Добро пожаловать на стадион! Начинаем матч!", "Судья даёт свисток — игра началась!"],
    "goal": ["ГОООЛ! Какой удар!", "Мяч в сетке! Трибуны взрываются!", "Гол! Вратарь был бессилен!"],
    "save": ["Вратарь спасает команду!", "Невероятный сейв!"],
    "foul": ["Нарушение правил, свисток судьи.", "Фол! Игра остановлена."],
    "yellow": ["Жёлтая карточка — судья строг.", "Предупреждение игроку, жёлтая карточка."],
    "red": ["Красная карточка! Команда остаётся без игрока.", "Удаление! Это серьёзный удар по команде."],
    "offside": ["Офсайд! Атака остановлена.", "Флажок поднят — игрок в положении вне игры."],
    "penalty": ["Пенальти! Решающий момент.", "Одиннадцатиметровый — нервы на пределе."],
    "corner": ["Угловой. Опасный момент у ворот!"],
    "throw": ["Мяч ушёл за боковую, будет аут."],
    "goalkick": ["Удар от ворот."],
    "var": ["Судья смотрит повтор. Ждём решение VAR."],
    "half": ["Перерыв. Команды уходят на отдых.", "Первый тайм позади."],
    "end": ["Финальный свисток! Матч окончен."],
    "shootout": ["Серия пенальти! Кто выдержит напряжение?", "Ничья — решать будут пенальти."],
    "so_goal": ["Забивает! Хладнокровно!", "Гол с точки!"],
    "so_miss": ["Не забил! Вратарь или штанга!", "Промах! Напряжение растёт."],
    "feint": ["Красивый финт!"],
}

const GFX_NAMES := ["НИЗКАЯ", "СРЕДНЯЯ", "ВЫСОКАЯ"]

var mode: int = 0
var headless: bool = false
var train: String = ""

var pick: Array = [0, 1]
var form_pick: Array = [1, 1]
var team_size: int = 5
var half_time: float = HALF_TIME
var offside_on: bool = true
var shootout_on: bool = true

signal settings_changed
var gfx: int = 2
var sound_on: bool = true
var volume: float = 0.8
var music_on: bool = true
var music_track: int = 0
var comm_on: bool = true

var comm_text: String = ""
var comm_t: float = 0.0
var cheer_t: float = 0.0

var _sfx_players: Array = []
var _sfx_last: Dictionary = {}
var _sfx_streams: Dictionary = {}
var _sfx_next: int = 0
var _amb: AudioStreamPlayer = null
var _music: AudioStreamPlayer = null
var _music_streams: Array = []
var _duck: bool = false
var _fade: ColorRect = null
var _fading: bool = false
var _tts_ok: bool = false
var _tts_voice: String = ""
var _comm_last_ms: int = 0

func _ready() -> void:
    headless = DisplayServer.get_name() == "headless"
    if headless:
        return
    process_mode = Node.PROCESS_MODE_ALWAYS
    load_settings()
    for i in 10:
        var ap := AudioStreamPlayer.new()
        add_child(ap)
        _sfx_players.append(ap)
    for n in ["kick_low", "kick_high", "block", "whistle", "goal", "tackle", "feint", "save", "post", "net", "card", "foul", "crowd", "var"]:
        var path: String = "res://assets/sfx/%s.wav" % n
        if ResourceLoader.exists(path):
            _sfx_streams[n] = load(path)
    _amb = AudioStreamPlayer.new()
    add_child(_amb)
    if _sfx_streams.has("crowd"):
        var st: AudioStreamWAV = _sfx_streams["crowd"].duplicate()
        st.loop_mode = AudioStreamWAV.LOOP_FORWARD
        st.loop_begin = 0
        st.loop_end = int(st.data.size() / 2)
        _amb.stream = st
        _amb.volume_db = -14.0
    _music = AudioStreamPlayer.new()
    add_child(_music)
    _music.volume_db = -10.0
    for trk in TRACKS:
        var s = null
        var mp: String = String(trk["path"])
        if ResourceLoader.exists(mp):
            var ms: AudioStreamWAV = load(mp).duplicate()
            ms.loop_mode = AudioStreamWAV.LOOP_FORWARD
            ms.loop_begin = 0
            ms.loop_end = int(ms.data.size() / 2)
            s = ms
        _music_streams.append(s)
    var layer := CanvasLayer.new()
    layer.layer = 100
    add_child(layer)
    _fade = ColorRect.new()
    _fade.color = Color(0, 0, 0, 0)
    _fade.set_anchors_preset(Control.PRESET_FULL_RECT)
    _fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(_fade)
    if DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
        var vs: PackedStringArray = DisplayServer.tts_get_voices_for_language("ru")
        if not vs.is_empty():
            _tts_voice = vs[0]
            _tts_ok = true
    apply_settings()
    update_music()

func _process(delta: float) -> void:
    if headless:
        return
    comm_t = maxf(0.0, comm_t - delta)
    cheer_t = maxf(0.0, cheer_t - delta)
    if _music != null:
        var target: float = -17.0 if _duck else -8.0
        _music.volume_db = lerpf(_music.volume_db, target, clampf(3.0 * delta, 0.0, 1.0))

# ---------------------------------------------------------------- команды и формации
func _ti(t: int) -> int:
    if mode == 2 or headless:
        return clampi(t, 0, 1)
    var a: int = clampi(int(pick[0]), 0, TEAMS.size() - 1)
    var b: int = clampi(int(pick[1]), 0, TEAMS.size() - 1)
    if t == 0:
        return a
    if b == a:
        return (b + 1) % TEAMS.size()
    return b

func team_name(t: int) -> String:
    return String(TEAMS[_ti(t)]["name"])

func team_col(t: int) -> Color:
    return TEAMS[_ti(t)]["c"]

func team_trim(t: int) -> Color:
    return TEAMS[_ti(t)]["t"]

func team_shorts(t: int) -> Color:
    return TEAMS[_ti(t)]["s"]

func formation_slots(size: int, form: int) -> Array:
    var n: int = maxi(1, size - 1)
    var w: Array = FORM_W[clampi(form, 0, 2)]
    var c: Array = [0, 0, 0]
    var rem: Array = [0.0, 0.0, 0.0]
    var used: int = 0
    for i in 3:
        var v: float = float(w[i]) * float(n)
        c[i] = int(floor(v))
        used += int(c[i])
        rem[i] = v - float(int(c[i]))
    while used < n:
        var bi: int = 0
        for i in 3:
            if float(rem[i]) > float(rem[bi]):
                bi = i
        c[bi] = int(c[bi]) + 1
        rem[bi] = -1.0
        used += 1
    if int(c[2]) == 0:
        var from_i: int = 0 if int(c[0]) >= int(c[1]) else 1
        c[from_i] = int(c[from_i]) - 1
        c[2] = 1
    var res: Array = [[Vector2(-855, 0), 0]]
    var xs: Array = [-450.0, -135.0, 165.0]
    for line in 3:
        var k: int = int(c[line])
        for j in k:
            var y: float = 0.0
            if k > 1:
                y = (float(j) - float(k - 1) * 0.5) * (960.0 / float(k))
            res.append([Vector2(float(xs[line]), y), line + 1])
    return res

func formation_label(size: int, form: int) -> String:
    var s: Array = formation_slots(size, form)
    var c: Array = [0, 0, 0]
    for e in s:
        var r: int = int(e[1])
        if r > 0:
            c[r - 1] = int(c[r - 1]) + 1
    return "%d-%d-%d" % [c[0], c[1], c[2]]

# ---------------------------------------------------------------- настройки
func load_settings() -> void:
    var cf := ConfigFile.new()
    if cf.load("user://settings.cfg") == OK:
        gfx = clampi(int(cf.get_value("s", "gfx", 2)), 0, 2)
        sound_on = bool(cf.get_value("s", "sound", true))
        volume = clampf(float(cf.get_value("s", "volume", 0.8)), 0.0, 1.0)
        music_on = bool(cf.get_value("s", "music", true))
        music_track = clampi(int(cf.get_value("s", "track", 0)), 0, TRACKS.size() - 1)
        comm_on = bool(cf.get_value("s", "comm", true))
        pick = [clampi(int(cf.get_value("m", "t0", 0)), 0, TEAMS.size() - 1), clampi(int(cf.get_value("m", "t1", 1)), 0, TEAMS.size() - 1)]
        form_pick = [clampi(int(cf.get_value("m", "f0", 1)), 0, 2), clampi(int(cf.get_value("m", "f1", 1)), 0, 2)]
        team_size = clampi(int(cf.get_value("m", "size", 5)), 3, 7)
        half_time = float(cf.get_value("m", "half", HALF_TIME))
        offside_on = bool(cf.get_value("m", "offside", true))
        shootout_on = bool(cf.get_value("m", "shootout", true))

func save_settings() -> void:
    var cf := ConfigFile.new()
    cf.set_value("s", "gfx", gfx)
    cf.set_value("s", "sound", sound_on)
    cf.set_value("s", "volume", volume)
    cf.set_value("s", "music", music_on)
    cf.set_value("s", "track", music_track)
    cf.set_value("s", "comm", comm_on)
    cf.set_value("m", "t0", int(pick[0]))
    cf.set_value("m", "t1", int(pick[1]))
    cf.set_value("m", "f0", int(form_pick[0]))
    cf.set_value("m", "f1", int(form_pick[1]))
    cf.set_value("m", "size", team_size)
    cf.set_value("m", "half", half_time)
    cf.set_value("m", "offside", offside_on)
    cf.set_value("m", "shootout", shootout_on)
    cf.save("user://settings.cfg")

func apply_settings() -> void:
    if headless:
        return
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.0001)))
    AudioServer.set_bus_mute(0, not sound_on)
    var vp: Viewport = get_viewport()
    if vp != null:
        if gfx == 2:
            vp.msaa_2d = Viewport.MSAA_4X
        elif gfx == 1:
            vp.msaa_2d = Viewport.MSAA_2X
        else:
            vp.msaa_2d = Viewport.MSAA_DISABLED
    update_music()
    settings_changed.emit()

# ---------------------------------------------------------------- звук, музыка, комментатор
func ambience(on: bool) -> void:
    if headless:
        return
    _duck = on
    if _amb == null or _amb.stream == null:
        return
    if on and not _amb.playing:
        _amb.play()
    elif not on:
        _amb.stop()

func update_music() -> void:
    if headless or _music == null or _music_streams.is_empty():
        return
    var st = _music_streams[clampi(music_track, 0, _music_streams.size() - 1)]
    if not music_on or st == null:
        _music.stop()
        return
    if _music.stream != st:
        _music.stream = st
        _music.play()
    elif not _music.playing:
        _music.play()

func comment(kind: String) -> void:
    if headless or not comm_on:
        return
    var arr: Array = COMM.get(kind, [])
    if arr.is_empty():
        return
    var now: int = Time.get_ticks_msec()
    if now - _comm_last_ms < 1500 and kind != "goal" and kind != "end":
        return
    _comm_last_ms = now
    var s: String = String(arr[randi() % arr.size()])
    comm_text = s
    comm_t = 3.6
    if _tts_ok and sound_on:
        DisplayServer.tts_speak(s, _tts_voice, int(clampf(volume, 0.2, 1.0) * 100.0), 1.0, 1.05, 0, true)

func comment_for_text(text: String) -> void:
    var t: String = text.to_upper()
    if t.begins_with("ВТОРАЯ ЖЁЛТАЯ") or t.begins_with("КРАСНАЯ"):
        comment("red")
    elif t.begins_with("ЖЁЛТАЯ") or t.begins_with("ПРЕДУПРЕЖДЕНИЕ"):
        comment("yellow")
    elif t.begins_with("ОФСАЙД"):
        comment("offside")
    elif t.begins_with("ФОЛ"):
        comment("foul")
    elif t.begins_with("ПЕНАЛЬТИ"):
        comment("penalty")
    elif t.begins_with("УГЛОВОЙ"):
        comment("corner")
    elif t.begins_with("АУТ"):
        comment("throw")
    elif t.begins_with("УДАР ОТ ВОРОТ"):
        comment("goalkick")
    elif t.begins_with("ПЕРЕРЫВ"):
        comment("half")

func cheer(sec: float) -> void:
    cheer_t = maxf(cheer_t, sec)

func sfx(name: String, vol_db: float = 0.0) -> void:
    if headless or not sound_on or not _sfx_streams.has(name) or _sfx_players.is_empty():
        return
    var now: int = Time.get_ticks_msec()
    if now - int(_sfx_last.get(name, -1000)) < 60:
        return
    _sfx_last[name] = now
    var ap: AudioStreamPlayer = _sfx_players[_sfx_next]
    _sfx_next = (_sfx_next + 1) % _sfx_players.size()
    ap.stream = _sfx_streams[name]
    ap.volume_db = vol_db
    ap.pitch_scale = randf_range(0.95, 1.05) if name.begins_with("kick") or name == "block" or name == "tackle" else 1.0
    ap.play()

# ---------------------------------------------------------------- плавная смена сцен
func goto(path: String) -> void:
    if headless or _fade == null or _fading:
        get_tree().change_scene_to_file(path)
        return
    _fading = true
    _fade.mouse_filter = Control.MOUSE_FILTER_STOP
    var tw: Tween = create_tween()
    tw.tween_property(_fade, "color:a", 1.0, 0.22)
    await tw.finished
    get_tree().paused = false
    get_tree().change_scene_to_file(path)
    await get_tree().process_frame
    var tw2: Tween = create_tween()
    tw2.tween_property(_fade, "color:a", 0.0, 0.3)
    await tw2.finished
    _fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _fading = false
