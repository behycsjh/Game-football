extends Node2D

var popups: Array = []
var parts: Array = []
var marks: Array = []
var off_x: float = 0.0
var off_t: float = 0.0

func _ready() -> void:
    z_index = 80

func add_popup(pos: Vector2, text: String, col: Color) -> void:
    if G.headless:
        return
    for p in popups:
        if p["s"] == text and (p["p"] as Vector2).distance_to(pos) < 30.0 and p["t"] < 0.4:
            return
    popups.append({"p": pos, "t": 0.0, "s": text, "c": col})
    if popups.size() > 14:
        popups.pop_front()

func show_offside(x: float) -> void:
    off_x = x
    off_t = 2.6

func burst(pos: Vector2, col: Color, n: int, speed: float, life: float) -> void:
    if G.headless or G.gfx == 0:
        return
    if parts.size() > 260:
        return
    for i in n:
        var a: float = randf() * TAU
        var v: float = speed * randf_range(0.3, 1.0)
        parts.append({"p": pos, "v": Vector2(cos(a), sin(a)) * v, "t": 0.0, "l": life * randf_range(0.6, 1.0), "c": col, "r": randf_range(1.5, 3.5), "g": 0.0})

func confetti(pos: Vector2) -> void:
    if G.headless or G.gfx == 0:
        return
    var cols: Array = [Color(1, 0.3, 0.3), Color(0.3, 0.6, 1), Color(1, 0.9, 0.2), Color(0.4, 1, 0.5), Color(1, 1, 1)]
    for i in 70:
        var a: float = randf() * TAU
        var v: float = randf_range(120.0, 520.0)
        parts.append({"p": pos, "v": Vector2(cos(a), sin(a)) * v, "t": 0.0, "l": randf_range(1.0, 1.9), "c": cols[i % cols.size()], "r": randf_range(2.0, 4.0), "g": 1.0})

func _process(delta: float) -> void:
    if G.headless:
        return
    for p in popups:
        p["t"] += delta
    off_t = maxf(0.0, off_t - delta)
    popups = popups.filter(func(p): return p["t"] < 1.4)
    for q in parts:
        q["t"] += delta
        q["p"] += q["v"] * delta
        q["v"] *= maxf(0.0, 1.0 - 2.2 * delta)
        if q["g"] > 0.0:
            q["v"] += Vector2(0, 260.0) * delta
    parts = parts.filter(func(q): return q["t"] < q["l"])
    queue_redraw()

func _draw() -> void:
    var f: Font = ThemeDB.fallback_font
    var pulse: float = sin(Time.get_ticks_msec() / 120.0)
    if off_t > 0.0:
        var oa: float = clampf(off_t / 0.6, 0.0, 1.0)
        var yy: float = -G.HALF_H
        while yy < G.HALF_H:
            draw_line(Vector2(off_x, yy), Vector2(off_x, yy + 22.0), Color(1.0, 0.85, 0.25, 0.9 * oa), 3.0)
            yy += 38.0
    for m in marks:
        if is_instance_valid(m[0]):
            draw_arc(m[0].global_position, 31.0 + 3.0 * pulse, 0.0, TAU, 40, m[1], 4.0)
    for q in parts:
        var a: float = 1.0 - q["t"] / q["l"]
        var c: Color = q["c"]
        draw_circle(q["p"], q["r"] * (0.5 + 0.5 * a), Color(c.r, c.g, c.b, c.a * a))
    for p in popups:
        var k: float = p["t"] / 1.4
        var pos: Vector2 = p["p"] + Vector2(0, -42.0 * k)
        var c: Color = p["c"]
        var a: float = 1.0 - clampf((k - 0.6) / 0.4, 0.0, 1.0)
        var sz: int = 17 + int(5.0 * clampf(1.0 - k * 4.0, 0.0, 1.0))
        draw_string_outline(f, pos + Vector2(-100, 0), p["s"], HORIZONTAL_ALIGNMENT_CENTER, 200, sz, 5, Color(0, 0, 0, 0.8 * a))
        draw_string(f, pos + Vector2(-100, 0), p["s"], HORIZONTAL_ALIGNMENT_CENTER, 200, sz, Color(c.r, c.g, c.b, a))
