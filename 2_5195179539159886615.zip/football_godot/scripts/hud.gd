extends Control

const STICK_R: float = 80.0

var main = null
var down: Dictionary = {}
var latch: Dictionary = {}
var touches: Dictionary = {}
var stick_touch: int = -1
var stick_default: Vector2 = Vector2(170, 560)
var stick_origin: Vector2 = Vector2(170, 560)
var stick_pos: Vector2 = Vector2(170, 560)
var stick_vec: Vector2 = Vector2.ZERO
var settings_open: bool = false
var _last_ph: String = ""
var _last_msg: String = ""
var _last_ban: String = ""

func _blue() -> Color:
    return G.team_col(0).lerp(Color.WHITE, 0.35)

func _red() -> Color:
    return G.team_col(1).lerp(Color.WHITE, 0.35)

func setup(m) -> void:
    main = m
    process_mode = Node.PROCESS_MODE_ALWAYS

func _set_settings(on: bool) -> void:
    settings_open = on
    if on:
        down.clear()
        touches.clear()
        stick_touch = -1
        stick_vec = Vector2.ZERO
        stick_origin = stick_default
        stick_pos = stick_default
    if G.mode != 2:
        get_tree().paused = on
    if not on:
        G.save_settings()

func _exit_tree() -> void:
    var t: SceneTree = get_tree()
    if t != null:
        t.paused = false

func is_down(id: String) -> bool:
    if settings_open:
        return false
    return down.get(id, false) or latch.get(id, false)

func _process(_d: float) -> void:
    if main != null:
        var so: bool = main.get("so_active") == true
        var ph: String = main.phase
        if ph != _last_ph:
            if ph == "goal":
                G.sfx("goal")
                G.cheer(3.0)
                G.comment("goal")
            elif ph == "var":
                G.comment("var")
            elif ph == "end":
                G.comment("end")
                G.sfx("whistle", -4.0)
            elif not so and (ph == "break" or (ph == "play" and _last_ph == "break")):
                G.sfx("whistle", -4.0)
            _last_ph = ph
        var msg: String = String(main.message)
        if msg != _last_msg:
            _last_msg = msg
            if msg != "":
                G.comment_for_text(msg)
        var bt = main.get("banner_t")
        var ban: String = String(main.get("banner_text")) if main.get("banner_text") != null else ""
        if bt != null and float(bt) > 0.0 and ban != _last_ban:
            _last_ban = ban
            G.comment_for_text(ban)
        elif bt != null and float(bt) <= 0.0:
            _last_ban = ""
    queue_redraw()

func _buttons() -> Array:
    var arr: Array = []
    if settings_open:
        var cx: float = 640.0
        arr.append({"id": "s_resume", "label": "ПРОДОЛЖИТЬ", "pos": Vector2(cx, 170), "size": Vector2(560, 52), "col": Color(0.2, 0.65, 0.3)})
        arr.append({"id": "s_gfx", "label": "ГРАФИКА: " + String(G.GFX_NAMES[G.gfx]), "pos": Vector2(cx, 232), "size": Vector2(560, 52), "col": Color(0.3, 0.5, 0.9)})
        arr.append({"id": "s_snd", "label": "ЗВУК: " + ("ВКЛ" if G.sound_on else "ВЫКЛ"), "pos": Vector2(cx, 294), "size": Vector2(560, 52), "col": Color(0.6, 0.4, 0.85)})
        arr.append({"id": "s_vd", "label": "−", "pos": Vector2(cx - 245, 356), "size": Vector2(70, 52), "col": Color(0.45, 0.45, 0.55)})
        arr.append({"id": "s_vu", "label": "+", "pos": Vector2(cx + 245, 356), "size": Vector2(70, 52), "col": Color(0.45, 0.45, 0.55)})
        arr.append({"id": "s_music", "label": "МУЗЫКА: " + ("ВКЛ" if G.music_on else "ВЫКЛ"), "pos": Vector2(cx - 140, 418), "size": Vector2(270, 52), "col": Color(0.85, 0.5, 0.25)})
        arr.append({"id": "s_track", "label": "ТРЕК: " + String(G.TRACKS[G.music_track]["name"]), "pos": Vector2(cx + 140, 418), "size": Vector2(270, 52), "col": Color(0.85, 0.5, 0.25)})
        arr.append({"id": "s_comm", "label": "КОММЕНТАТОР: " + ("ВКЛ" if G.comm_on else "ВЫКЛ"), "pos": Vector2(cx, 480), "size": Vector2(560, 52), "col": Color(0.25, 0.6, 0.7)})
        arr.append({"id": "s_leave", "label": "ВЫЙТИ ИЗ МАТЧА", "pos": Vector2(cx, 548), "size": Vector2(560, 52), "col": Color(0.75, 0.2, 0.2)})
        return arr
    if main.phase == "end":
        var by: float = 500.0 if main.get("end_lines") != null else 650.0
        var br: float = 70.0 if main.get("end_lines") != null else 52.0
        arr.append({"id": "again", "label": "ЕЩЁ РАЗ", "pos": Vector2(520, by), "r": br, "col": Color(0.2, 0.7, 0.3)})
        arr.append({"id": "menu", "label": "В МЕНЮ", "pos": Vector2(760, by), "r": br, "col": Color(0.85, 0.45, 0.2)})
        return arr
    arr.append({"id": "settings", "label": "МЕНЮ", "pos": Vector2(1235, 40), "r": 30.0, "col": Color(0.35, 0.38, 0.5)})
    if main.phase == "var":
        arr.append({"id": "skipvar", "label": "ПРОПУСТИТЬ", "pos": Vector2(1100, 650), "size": Vector2(220, 52), "col": Color(0.2, 0.45, 0.7)})
        return arr
    arr.append({"id": "stats", "label": "СТАТ", "pos": Vector2(1235, 106), "r": 30.0, "col": Color(0.3, 0.5, 0.45)})
    var rw = main.get("req_win")
    if rw != null and not rw.is_empty() and (main.phase == "play" or main.phase == "goal"):
        arr.append({"id": "reqvar", "label": "VAR", "pos": Vector2(1235, 172), "r": 34.0, "col": Color(0.2, 0.7, 0.95)})
    if main.has_method("take_info"):
        var ti: Dictionary = main.take_info()
        if ti["stage"] == "duel_pick" and (ti["role"] == "shooter" or ti["role"] == "keeper") and not ti["locked"]:
            var rows: int = 2 if ti["role"] == "shooter" else 1
            for r in rows:
                for c in 3:
                    var hi: int = 1 - r if rows == 2 else 0
                    arr.append({"id": "pick:%d:%d" % [c - 1, hi], "label": "", "hidden": true,
                        "pos": Vector2(490.0 + 150.0 * float(c), 520.0 + 80.0 * float(r)), "size": Vector2(146, 76), "col": Color.WHITE})
    var p = main.controlled
    var gk: bool = p != null and p.role == 0
    if gk:
        arr.append({"id": "jl", "label": "ПРЫЖОК\nВЛЕВО", "pos": Vector2(1010, 610), "r": 56.0, "col": Color(0.3, 0.6, 1.0)})
        arr.append({"id": "jr", "label": "ПРЫЖОК\nВПРАВО", "pos": Vector2(1160, 610), "r": 56.0, "col": Color(0.3, 0.6, 1.0)})
        arr.append({"id": "exit", "label": "ВЫХОД /\nВЫБИТЬ", "pos": Vector2(1085, 470), "r": 58.0, "col": Color(1.0, 0.6, 0.1)})
        arr.append({"id": "dash", "label": "РАШ", "pos": Vector2(1085, 335), "r": 52.0, "col": Color(0.65, 0.35, 0.9)})
    else:
        arr.append({"id": "shoot", "label": "УДАР", "pos": Vector2(1130, 560), "r": 86.0, "col": Color(0.9, 0.25, 0.25)})

        if p != null and (p.state == 2 or p.skill_cd > 0.0):
            arr.append({"id": "skill", "label": "ФИНТ", "pos": Vector2(985, 480), "r": 46.0, "col": Color(0.3, 0.75, 0.95)})
    return arr

func _input(event: InputEvent) -> void:
    if main == null:
        return
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
        if main.phase != "end":
            _set_settings(not settings_open)
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            _press(event.index, event.position)
        else:
            _release(event.index)
    elif event is InputEventScreenDrag:
        if event.index == stick_touch:
            _set_stick(event.position)

func _press(idx: int, pos: Vector2) -> void:
    for b in _buttons():
        var bp: Vector2 = b["pos"]
        var hit: bool = false
        if b.has("size"):
            var sz: Vector2 = b["size"]
            hit = absf(pos.x - bp.x) <= sz.x * 0.5 and absf(pos.y - bp.y) <= sz.y * 0.5
        else:
            hit = pos.distance_to(bp) <= float(b["r"]) + 6.0
        if hit:
            var id: String = b["id"]
            if _ui_action(id):
                return
            touches[idx] = id
            down[id] = true
            latch[id] = true
            main.on_hud_button(id)
            return
    if settings_open:
        return
    if main.phase != "end" and pos.x < 600.0 and stick_touch == -1:
        stick_touch = idx
        stick_origin = Vector2(clampf(pos.x, 100.0, 560.0), clampf(pos.y, 200.0, 640.0))
        _set_stick(pos)

func _ui_action(id: String) -> bool:
    match id:
        "settings":
            _set_settings(true)
        "stats":
            main.show_stats = not main.show_stats
        "s_resume":
            _set_settings(false)
        "s_gfx":
            G.gfx = (G.gfx + 1) % 3
            G.apply_settings()
        "s_snd":
            G.sound_on = not G.sound_on
            G.apply_settings()
        "s_vd":
            G.volume = clampf(G.volume - 0.1, 0.0, 1.0)
            G.apply_settings()
        "s_vu":
            G.volume = clampf(G.volume + 0.1, 0.0, 1.0)
            G.sound_on = true
            G.apply_settings()
        "s_music":
            G.music_on = not G.music_on
            G.apply_settings()
        "s_track":
            G.music_track = (G.music_track + 1) % G.TRACKS.size()
            G.music_on = true
            G.apply_settings()
        "s_comm":
            G.comm_on = not G.comm_on
            if not G.comm_on:
                G.comm_t = 0.0
        "s_leave":
            _set_settings(false)
            main.on_hud_button("leave" if G.mode == 2 else "menu")
        _:
            return false
    return true

func _release(idx: int) -> void:
    if touches.has(idx):
        down[touches[idx]] = false
        touches.erase(idx)
    if idx == stick_touch:
        stick_touch = -1
        stick_vec = Vector2.ZERO
        stick_origin = stick_default
        stick_pos = stick_default

func _set_stick(pos: Vector2) -> void:
    var off: Vector2 = pos - stick_origin
    stick_pos = stick_origin + off.limit_length(STICK_R)
    var v: Vector2 = (off / STICK_R).limit_length(1.0)
    if v.length() < 0.15:
        v = Vector2.ZERO
    stick_vec = v

func _tc(f: Font, text: String, pos: Vector2, size: int, col: Color) -> void:
    draw_string(f, Vector2(pos.x - 400.0, pos.y), text, HORIZONTAL_ALIGNMENT_CENTER, 800, size, col)

func _draw() -> void:
    if main == null:
        return
    var f: Font = ThemeDB.fallback_font
    _draw_scoreboard(f)
    _draw_status(f)
    if main.phase != "end" and not settings_open:
        _draw_stick()
    if settings_open:
        _draw_settings_panel(f)
    for b in _buttons():
        _draw_button(f, b)
    if not settings_open:
        _draw_messages(f)
        _draw_shootout(f)
        _draw_comment(f)
        _draw_take(f)
        _draw_req_prompt(f)
        _draw_ball_arrow()
        _draw_banner(f)
        if main.phase == "var":
            _draw_var(f)
        if main.get("show_stats") == true and main.phase != "end":
            _draw_stats_panel(f, Vector2(640, 170), 470.0, 0.88)

func _draw_comment(f: Font) -> void:
    if not G.comm_on or G.comm_t <= 0.0 or G.comm_text == "":
        return
    var a: float = clampf(G.comm_t / 0.6, 0.0, 1.0)
    var txt: String = G.comm_text
    var w: float = clampf(float(txt.length()) * 11.5 + 60.0, 260.0, 900.0)
    draw_rect(Rect2(640.0 - w * 0.5, 676, w, 32), Color(0, 0, 0, 0.6 * a), true)
    draw_rect(Rect2(640.0 - w * 0.5, 676, 5, 32), Color(1, 0.85, 0.3, a), true)
    _tc(f, txt, Vector2(640, 699), 17, Color(1, 1, 1, a))

func _draw_shootout(f: Font) -> void:
    var so = main.get("so_log")
    if so == null:
        return
    var active: bool = main.get("so_active") == true
    var done: bool = int(main.get("so_winner")) >= 0
    if not active and not done:
        return
    if main.phase == "end":
        return
    var y0: float = 78.0
    var n: int = maxi(5, maxi(so[0].size(), so[1].size()))
    var w: float = 150.0 + float(n) * 30.0 + 150.0
    draw_rect(Rect2(640.0 - w * 0.5, y0, w, 74), Color(0, 0, 0, 0.62), true)
    draw_rect(Rect2(640.0 - w * 0.5, y0, w, 74), Color(1, 1, 1, 0.35), false, 2.0)
    for t in 2:
        var y: float = y0 + 22.0 + 30.0 * float(t)
        var col: Color = _blue() if t == 0 else _red()
        draw_string(f, Vector2(640.0 - w * 0.5 + 10.0, y + 6.0), G.team_name(t), HORIZONTAL_ALIGNMENT_LEFT, 140, 16, col)
        for i in n:
            var cx: float = 640.0 - w * 0.5 + 160.0 + float(i) * 30.0
            var c := Vector2(cx, y)
            if i < so[t].size():
                if bool(so[t][i]):
                    draw_circle(c, 10.0, Color(0.3, 0.9, 0.4))
                else:
                    draw_circle(c, 10.0, Color(0.9, 0.3, 0.3))
                    draw_line(c + Vector2(-5, -5), c + Vector2(5, 5), Color.WHITE, 2.5)
                    draw_line(c + Vector2(-5, 5), c + Vector2(5, -5), Color.WHITE, 2.5)
            else:
                draw_arc(c, 10.0, 0.0, TAU, 20, Color(1, 1, 1, 0.5), 2.0)
        draw_string(f, Vector2(640.0 + w * 0.5 - 60.0, y + 8.0), str(main.so_score[t]), HORIZONTAL_ALIGNMENT_RIGHT, 50, 24, Color.WHITE)

func _draw_scoreboard(f: Font) -> void:
    draw_rect(Rect2(400, 6, 480, 66), Color(0, 0, 0, 0.55), true)
    _tc(f, G.team_name(0), Vector2(480, 38), 22, _blue())
    _tc(f, "%d : %d" % [main.score[0], main.score[1]], Vector2(640, 42), 36, Color.WHITE)
    _tc(f, G.team_name(1), Vector2(800, 38), 22, _red())
    var secs: int = int(ceil(main.time_left))
    var m: int = floori(secs / 60.0)
    var s: int = secs - m * 60
    var tl: String = "%d-й тайм   %02d:%02d" % [main.period, m, s]
    if G.train == "solo":
        tl = "ТРЕНИРОВКА — бей по воротам"
    elif G.train == "shootout" or (main.get("so_active") == true):
        tl = "СЕРИЯ ПЕНАЛЬТИ"
    _tc(f, tl, Vector2(640, 64), 16, Color(1, 1, 1, 0.85))

func _draw_status(f: Font) -> void:
    var p = main.controlled
    var txt: String = ""
    if p != null:
        if p.role == 0:
            txt = "Вы: вратарь (ГК)"
        else:
            txt = "Вы: полевой игрок №%d" % p.num
    draw_rect(Rect2(10, 10, 260, 30), Color(0, 0, 0, 0.45), true)
    draw_string(f, Vector2(18, 31), txt, HORIZONTAL_ALIGNMENT_LEFT, 250, 18, Color(1, 0.95, 0.4))

func _draw_stick() -> void:
    var active: bool = stick_touch != -1
    draw_circle(stick_origin, STICK_R, Color(1, 1, 1, 0.12 if not active else 0.2))
    draw_arc(stick_origin, STICK_R, 0.0, TAU, 40, Color(1, 1, 1, 0.5), 3.0)
    draw_circle(stick_pos, 34.0, Color(1, 1, 1, 0.45 if not active else 0.7))

func _button_fraction(id: String) -> float:
    var p = main.controlled
    if p == null:
        return -1.0
    match id:
        "shoot":
            if p.charging:
                return clampf(p.charge, 0.0, 1.0)
        "skill":
            if p.skill_cd > 0.0:
                return 1.0 - p.skill_cd / 2.0
        "tackle":
            if p.recover_t > 0.0:
                return 1.0 - clampf(p.recover_t / 0.6, 0.0, 1.0)
            if p.tackle_cd > 0.0:
                return 1.0 - p.tackle_cd / 1.0
        "jl", "jr":
            if p.dive_cd > 0.0:
                return 1.0 - p.dive_cd / 1.2
        "exit":
            if p.rush_cd > 0.0:
                return 1.0 - p.rush_cd / 2.5
    return -1.0

func _draw_settings_panel(f: Font) -> void:
    draw_rect(Rect2(0, 0, 1280, 720), Color(0, 0, 0, 0.6), true)
    draw_rect(Rect2(330, 80, 620, 540), Color(0.08, 0.1, 0.16, 0.95), true)
    draw_rect(Rect2(330, 80, 620, 540), Color(1, 1, 1, 0.5), false, 3.0)
    _tc(f, "НАСТРОЙКИ", Vector2(640, 126), 32, Color.WHITE)
    _tc(f, "Громкость %d%%" % int(round(G.volume * 100.0)), Vector2(640, 363), 20, Color(1, 1, 1, 0.9))
    _tc(f, "Esc — закрыть меню", Vector2(640, 608), 13, Color(1, 1, 1, 0.5))

func _draw_button(f: Font, b: Dictionary) -> void:
    if b.get("hidden", false):
        return
    var p: Vector2 = b["pos"]
    var col: Color = b["col"]
    var id: String = b["id"]
    var pressed: bool = down.get(id, false)
    if b.has("size"):
        var sz: Vector2 = b["size"]
        var rc := Rect2(p - sz * 0.5, sz)
        draw_rect(rc, Color(col.r, col.g, col.b, 0.95 if pressed else 0.75), true)
        draw_rect(rc, Color(1, 1, 1, 0.8), false, 2.0)
        _tc(f, String(b["label"]), Vector2(p.x, p.y + 8.0), 22, Color.WHITE)
        return
    var r: float = b["r"]
    draw_circle(p, r, Color(col.r, col.g, col.b, 0.9 if pressed else 0.5))
    draw_arc(p, r, 0.0, TAU, 40, Color(1, 1, 1, 0.8), 3.0)
    var frac: float = _button_fraction(id)
    if frac >= 0.0:
        draw_arc(p, r - 5.0, -PI / 2.0, -PI / 2.0 + TAU * frac, 40, Color(1, 1, 0.4, 0.95), 5.0)
    if id == "jl":
        draw_colored_polygon(PackedVector2Array([p + Vector2(0, -r + 8), p + Vector2(-9, -r + 24), p + Vector2(9, -r + 24)]), Color.WHITE)
    elif id == "jr":
        draw_colored_polygon(PackedVector2Array([p + Vector2(0, r - 8), p + Vector2(-9, r - 24), p + Vector2(9, r - 24)]), Color.WHITE)
    var label: String = String(b["label"])
    if id == "shoot" and main.controlled != null and main.controlled.charging:
        label = "ВЕРХОМ" if main.controlled.charge >= 0.35 else "НИЗОМ"
    var lines: PackedStringArray = label.split("\n")
    var fs: int = 15 if r < 50.0 else (24 if r > 70.0 else 18)
    if lines.size() > 1 and r < 50.0:
        fs = 13
    var y0: float = p.y + 5.0 - float(lines.size() - 1) * 9.0
    for i in lines.size():
        draw_string(f, Vector2(p.x - 100.0, y0 + float(i) * 18.0), lines[i], HORIZONTAL_ALIGNMENT_CENTER, 200, fs, Color.WHITE)

func _draw_var(f: Font) -> void:
    var pulse: float = 0.5 + 0.5 * sin(Time.get_ticks_msec() / 160.0)
    var review: bool = main.var_stage == "review"
    var frame_col: Color = Color(0.3, 0.8, 1.0, 0.8)
    if not review:
        frame_col = Color(0.3, 1.0, 0.5, 0.9) if main.var_ok else Color(1.0, 0.4, 0.3, 0.9)
    draw_rect(Rect2(4, 4, 1272, 712), frame_col, false, 6.0)
    draw_rect(Rect2(10, 84, 150, 40), Color(0.05, 0.1, 0.2, 0.9), true)
    draw_rect(Rect2(10, 84, 150, 40), Color(0.3, 0.8, 1.0), false, 2.0)
    draw_string(f, Vector2(22, 112), "VAR", HORIZONTAL_ALIGNMENT_LEFT, 60, 26, Color(0.4, 0.9, 1.0))
    if review:
        draw_circle(Vector2(95, 104), 6.0, Color(1, 0.2, 0.2, 0.5 + 0.5 * pulse))
        draw_string(f, Vector2(106, 110), "ПОВТОР", HORIZONTAL_ALIGNMENT_LEFT, 70, 13, Color.WHITE)
    var y: float = 540.0
    draw_rect(Rect2(240, y, 800, 120), Color(0.02, 0.04, 0.09, 0.88), true)
    draw_rect(Rect2(240, y, 800, 120), frame_col, false, 3.0)
    if review:
        _tc(f, "ВИДЕОАССИСТЕНТ ПРОВЕРЯЕТ", Vector2(640, y + 40.0), 20, Color(0.6, 0.85, 1.0))
        _tc(f, main.var_title, Vector2(640, y + 82.0), 34, Color.WHITE)
    else:
        _tc(f, main.var_text, Vector2(640, y + 58.0), 40, frame_col)
        _tc(f, main.var_sub, Vector2(640, y + 98.0), 20, Color.WHITE)

func _draw_banner(f: Font) -> void:
    var bt = main.get("banner_t")
    if bt == null or bt <= 0.0:
        return
    var a: float = clampf(bt / 0.6, 0.0, 1.0)
    var col: Color = main.banner_col
    var card: Color = main.banner_card
    draw_rect(Rect2(340, 84, 600, 46), Color(0, 0, 0, 0.7 * a), true)
    draw_rect(Rect2(340, 84, 6, 46), Color(col.r, col.g, col.b, a), true)
    var tx: float = 640.0
    if card.a > 0.0:
        draw_rect(Rect2(360, 92, 24, 32), Color(card.r, card.g, card.b, a), true)
        draw_rect(Rect2(360, 92, 24, 32), Color(1, 1, 1, 0.8 * a), false, 2.0)
        tx = 650.0
    _tc(f, main.banner_text, Vector2(tx, 115), 22, Color(col.r, col.g, col.b, a))

func _draw_stats_panel(f: Font, c: Vector2, y0: float, alpha: float) -> void:
    var rows: Array = main.stat_rows()
    var w: float = 520.0
    var h: float = 60.0 + 28.0 * rows.size()
    draw_rect(Rect2(c.x - w * 0.5, y0 - 40.0, w, h), Color(0.03, 0.05, 0.1, alpha), true)
    draw_rect(Rect2(c.x - w * 0.5, y0 - 40.0, w, h), Color(1, 1, 1, 0.5), false, 2.0)
    draw_string(f, Vector2(c.x - w * 0.5 + 20.0, y0 - 12.0), G.team_name(0), HORIZONTAL_ALIGNMENT_LEFT, 150, 20, _blue())
    draw_string(f, Vector2(c.x + w * 0.5 - 170.0, y0 - 12.0), G.team_name(1), HORIZONTAL_ALIGNMENT_RIGHT, 150, 20, _red())
    _tc(f, "СТАТИСТИКА", Vector2(c.x, y0 - 12.0), 18, Color(1, 1, 1, 0.7))
    for i in rows.size():
        var r: Array = rows[i]
        var y: float = y0 + 20.0 + 28.0 * float(i)
        if i % 2 == 0:
            draw_rect(Rect2(c.x - w * 0.5 + 6.0, y - 20.0, w - 12.0, 26.0), Color(1, 1, 1, 0.06), true)
        var a: int = int(r[1])
        var b: int = int(r[2])
        draw_string(f, Vector2(c.x - w * 0.5 + 20.0, y), str(a), HORIZONTAL_ALIGNMENT_LEFT, 100, 20, _blue() if a >= b else Color(1, 1, 1, 0.7))
        draw_string(f, Vector2(c.x + w * 0.5 - 120.0, y), str(b), HORIZONTAL_ALIGNMENT_RIGHT, 100, 20, _red() if b >= a else Color(1, 1, 1, 0.7))
        _tc(f, String(r[0]), Vector2(c.x, y), 19, Color.WHITE)

func _draw_messages(f: Font) -> void:
    var ph: String = main.phase
    if ph == "goal":
        var tcol: Color = _blue() if main.goal_team == 0 else _red()
        var pulse: float = 1.0 + 0.08 * sin(Time.get_ticks_msec() / 80.0)
        draw_rect(Rect2(0, 250, 1280, 170), Color(0, 0, 0, 0.5), true)
        _tc(f, "ГОЛ!", Vector2(640, 350), int(96.0 * pulse), tcol)
        var who: String = "%s забивают!" % G.team_name(main.goal_team).capitalize()
        var sn = main.get("scorer_name")
        if sn != null and sn != "":
            who = "%s — %s" % [sn, who]
        _tc(f, who, Vector2(640, 400), 26, Color.WHITE)
    elif ph == "break" or ph == "set":
        draw_rect(Rect2(0, 290, 1280, 100), Color(0, 0, 0, 0.45), true)
        _tc(f, main.message, Vector2(640, 355), 44 if ph == "break" else 38, Color.WHITE)
    elif ph == "end":
        var el = main.get("end_lines")
        var dy: float = 0.0
        if el == null:
            draw_rect(Rect2(0, 0, 1280, 720), Color(0, 0, 0, 0.72), true)
            _tc(f, "МАТЧ ОКОНЧЕН", Vector2(640, 62), 44, Color.WHITE)
            _tc(f, "%s  %d : %d  %s" % [G.team_name(0), main.score[0], main.score[1], G.team_name(1)], Vector2(640, 112), 34, Color(1, 0.95, 0.5))
            var res0: String = "НИЧЬЯ"
            if main.score[0] > main.score[1]:
                res0 = "ПОБЕДА: " + G.team_name(0)
            elif main.score[1] > main.score[0]:
                res0 = "ПОБЕДА: " + G.team_name(1)
            var sw0 = main.get("so_winner")
            if sw0 != null and int(sw0) >= 0:
                res0 = "ПО ПЕНАЛЬТИ (%d : %d) ПОБЕДА: %s" % [main.so_score[0], main.so_score[1], G.team_name(int(sw0))]
            _tc(f, res0, Vector2(640, 150), 26, Color.WHITE)
            _draw_stats_panel(f, Vector2(640, 250), 232.0, 0.0)
            return
        else:
            dy = -70.0
            draw_rect(Rect2(0, 100, 1280, 360), Color(0, 0, 0, 0.75), true)
        _tc(f, "МАТЧ ОКОНЧЕН", Vector2(640, 240 + dy), 52, Color.WHITE)
        _tc(f, "%s  %d : %d  %s" % [G.team_name(0), main.score[0], main.score[1], G.team_name(1)], Vector2(640, 320 + dy), 40, Color(1, 0.95, 0.5))
        var res: String = "НИЧЬЯ"
        if main.score[0] > main.score[1]:
            res = "ПОБЕДА: " + G.team_name(0)
        elif main.score[1] > main.score[0]:
            res = "ПОБЕДА: " + G.team_name(1)
        _tc(f, res, Vector2(640, 385 + dy), 34, Color.WHITE)
        if el != null:
            for t in 2:
                var col: Color = _blue() if t == 0 else _red()
                var cx: float = 300.0 if t == 0 else 980.0
                var arr: Array = el[t]
                for i in arr.size():
                    _tc(f, arr[i], Vector2(cx, 355.0 + float(i) * 24.0), 18, col)
            var ft = main.get("end_footer")
            if ft != null:
                _tc(f, ft, Vector2(640, 450), 22, Color(1, 1, 0.6))

func _w2s(p: Vector2) -> Vector2:
    var c: Camera2D = main.cam
    return (p - c.get_screen_center_position()) * c.zoom + Vector2(640.0, 360.0)

func _kind_label(k: String) -> String:
    match k:
        "throw":
            return "АУТ"
        "corner":
            return "УГЛОВОЙ"
        "goalkick":
            return "УДАР ОТ ВОРОТ"
        "penalty":
            return "ПЕНАЛЬТИ"
    return "ШТРАФНОЙ"

func _draw_req_prompt(f: Font) -> void:
    var rw = main.get("req_win")
    if rw == null or rw.is_empty():
        return
    if not (main.phase == "play" or main.phase == "goal"):
        return
    var left = main.get("var_req_left")
    var pulse: float = 0.6 + 0.4 * sin(Time.get_ticks_msec() / 140.0)
    draw_rect(Rect2(380, 140, 520, 34), Color(0.02, 0.1, 0.18, 0.85), true)
    draw_rect(Rect2(380, 140, 520, 34), Color(0.3, 0.8, 1.0, pulse), false, 2.0)
    var what: String = "гол" if rw["kind"] == "goal" else "отбор"
    _tc(f, "Запросить проверку VAR (%s): кнопка VAR / клавиша V — осталось %d" % [what, int(left)], Vector2(640, 164), 15, Color(0.7, 0.92, 1.0))

func _draw_take(f: Font) -> void:
    if not main.has_method("take_info"):
        return
    var ti: Dictionary = main.take_info()
    var st: String = ti["stage"]
    if st == "":
        return
    var tn: String = G.team_name(int(ti["team"]))
    var tcol: Color = _blue() if int(ti["team"]) == 0 else _red()
    if st == "take":
        draw_rect(Rect2(400, 84, 480, 40), Color(0, 0, 0, 0.6), true)
        _tc(f, "%s — %s" % [_kind_label(ti["kind"]), tn], Vector2(640, 112), 24, tcol)
        if ti["role"] == "taker":
            var k: String = ti["kind"]
            var tp: Vector2 = _w2s(ti["tpos"])
            var aim: Vector2 = ti["aim"]
            var c: float = float(ti["charge"])
            var tip: Vector2 = tp + aim * (70.0 + 120.0 * c)
            draw_line(tp + aim * 26.0, tip, Color(1.0, 0.9, 0.3, 0.95), 5.0)
            draw_colored_polygon(PackedVector2Array([tip + aim * 16.0, tip + aim.orthogonal() * 9.0, tip - aim.orthogonal() * 9.0]), Color(1.0, 0.9, 0.3))
            draw_rect(Rect2(540, 640, 200, 14), Color(0, 0, 0, 0.7), true)
            draw_rect(Rect2(540, 640, 200.0 * c, 14), Color(0.3, 0.9, 0.4) if c < 0.8 else Color(1.0, 0.5, 0.2), true)
            draw_rect(Rect2(540, 640, 200, 14), Color(1, 1, 1, 0.8), false, 2.0)
            var verb: String = "БРОСИТЬ" if k == "throw" else "УДАРИТЬ"
            var hint: String = "Стик — направление, УДЕРЖИВАЙ кнопку удара — сила, отпусти — %s (%d с)" % [verb.to_lower(), int(ceil(float(ti["t"])))]
            if k == "throw":
                hint = "Вбрасывание руками. " + hint
            _tc(f, hint, Vector2(640, 684), 16, Color(1, 1, 1, 0.92))
    elif st == "duel_pick":
        draw_rect(Rect2(0, 0, 1280, 70), Color(0, 0, 0, 0.55), true)
        draw_rect(Rect2(0, 650, 1280, 70), Color(0, 0, 0, 0.55), true)
        _tc(f, "%s — %s" % [_kind_label(ti["kind"]), tn], Vector2(640, 52), 34, tcol)
        var role: String = ti["role"]
        if role == "shooter" or role == "keeper":
            var rows: int = 2 if role == "shooter" else 1
            var title: String = "КУДА БЬЁМ? (стик + удар, или тап по зоне)" if role == "shooter" else "КУДА ПРЫГАЕТ ВРАТАРЬ? (стик + удар, или тап)"
            _tc(f, title, Vector2(640, 490), 22, Color.WHITE)
            for r in rows:
                for c in 3:
                    var hi: int = 1 - r if rows == 2 else 0
                    var rc := Rect2(417.0 + 150.0 * float(c), 502.0 + 80.0 * float(r), 146, 76)
                    var sel: bool = (c - 1) == int(ti["col"]) and (rows == 1 or hi == int(ti["hi"]))
                    var fill: Color = Color(0.2, 0.25, 0.4, 0.8)
                    if sel:
                        fill = Color(0.2, 0.75, 0.35, 0.9) if not ti["locked"] else Color(1.0, 0.65, 0.1, 0.95)
                    draw_rect(rc, fill, true)
                    draw_rect(rc, Color(1, 1, 1, 0.85), false, 2.0)
                    if rows == 2:
                        _tc(f, "ВЕРХ" if hi == 1 else "НИЗ", Vector2(rc.position.x + 73.0, rc.position.y + 46.0), 20, Color(1, 1, 1, 0.75))
                    else:
                        var jl: String = ["ВЛЕВО", "ЦЕНТР", "ВПРАВО"][c]
                        _tc(f, jl, Vector2(rc.position.x + 73.0, rc.position.y + 46.0), 22, Color(1, 1, 1, 0.85))
            if ti["locked"]:
                _tc(f, "ВЫБОР СДЕЛАН — ждём соперника…", Vector2(640, 690), 20, Color(1.0, 0.85, 0.3))
            else:
                _tc(f, "Осталось %d с%s" % [int(ceil(float(ti["t"]))), ("   (соперник уже выбрал)" if ti["opp_locked"] else "")], Vector2(640, 690), 18, Color(1, 1, 1, 0.85))
        else:
            _tc(f, "Идёт серия…", Vector2(640, 690), 20, Color(1, 1, 1, 0.8))
    elif st == "duel_run":
        draw_rect(Rect2(0, 0, 1280, 70), Color(0, 0, 0, 0.55), true)
        draw_rect(Rect2(0, 650, 1280, 70), Color(0, 0, 0, 0.55), true)
        _tc(f, "%s — %s" % [_kind_label(ti["kind"]), tn], Vector2(640, 52), 34, tcol)

func _draw_ball_arrow() -> void:
    if main.get("ball") == null or main.phase == "end" or main.phase == "var":
        return
    var s: Vector2 = _w2s(main.ball.global_position)
    var rc := Rect2(24, 96, 1232, 580)
    if rc.has_point(s):
        return
    var ctr: Vector2 = Vector2(640, 360)
    var d: Vector2 = s - ctr
    if d.length() < 1.0:
        return
    var kx: float = (rc.size.x * 0.5) / maxf(absf(d.x), 0.001)
    var ky: float = (rc.size.y * 0.5) / maxf(absf(d.y), 0.001)
    var pt: Vector2 = ctr + d * minf(kx, ky)
    var n: Vector2 = d.normalized()
    draw_colored_polygon(PackedVector2Array([pt + n * 16.0, pt + n.orthogonal() * 11.0 - n * 8.0, pt - n.orthogonal() * 11.0 - n * 8.0]), Color(1.0, 0.95, 0.3, 0.9))
    draw_circle(pt - n * 20.0, 7.0, Color(1, 1, 1, 0.9))
