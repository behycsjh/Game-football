extends Node2D

const PlayerScene = preload("res://scenes/Player.tscn")
const BallScene = preload("res://scenes/Ball.tscn")
const RulesScript = preload("res://scripts/rules.gd")
const PH := {"play": 0, "goal": 1, "break": 2, "end": 3, "set": 4, "take": 5, "duel": 6}
const HEAD := 26
const STAGE := {"": 0, "announce": 1, "take": 2, "duel_pick": 3, "duel_run": 4}

const FORMS := {
    1: [[Vector2(-90, 0), 2]],
    2: [[Vector2(-450, 0), 1], [Vector2(165, 0), 3]],
    3: [[Vector2(-450, 0), 1], [Vector2(-135, -190), 2], [Vector2(165, 190), 3]],
    4: [[Vector2(-450, 0), 1], [Vector2(-135, -255), 2], [Vector2(-135, 255), 2], [Vector2(165, 0), 3]],
}

var room_id: int = 0
var n: int = 2
var ball = null
var teams: Array = [[], []]
var ents: Array = []
var members: Dictionary = {}
var presser: Array = [null, null]
var chaser: Array = [null, null]
var score: Array = [0, 0]
var period: int = 1
var time_left: float = 75.0
var phase: String = "break"
var phase_timer: float = 0.0
var goal_team: int = -1
var msg_code: int = 1
var scorer_idx: int = -1
var cur_touch = null
var prev_touch = null
var tick_n: int = 0
var finished: bool = false
var rules = null
var message: String = ""
var sent_peers: Array = []

func init_match(rid: int, size: int, list: Array) -> void:
    room_id = rid
    n = size
    rules = RulesScript.new(self)
    time_left = G.MATCH_HALF
    ball = BallScene.instantiate()
    add_child(ball)
    ball.goal_scored.connect(_on_goal)
    var form: Array = FORMS[n]
    for t in 2:
        var arr: Array = []
        arr.append(_make_player(t, 0, 1, Vector2(-855, 0)))
        for i in n:
            arr.append(_make_player(t, form[i][1], i + 2, form[i][0]))
        teams[t] = arr
        ents.append_array(arr)
    var used: Array = [[], []]
    for e in list:
        var t: int = e["team"]
        var slot = null
        for p in teams[t]:
            if p.role != 0 and not used[t].has(p):
                slot = p
                break
        if slot == null:
            continue
        used[t].append(slot)
        slot.is_human = true
        slot.nick = e["nick"]
        members[e["peer"]] = {"player": slot, "token": e["token"], "nick": e["nick"], "team": t,
            "mv": Vector2.ZERO, "btn": 0, "jp": 0, "jr": 0, "goals": 0, "assists": 0, "left": false}
    _kickoff()
    phase = "break"
    phase_timer = 1.5
    msg_code = 1

func _make_player(t: int, role: int, num: int, home: Vector2):
    var p = PlayerScene.instantiate()
    p.collision_layer = 0
    p.collision_mask = 0
    add_child(p)
    p.setup(self, ball, t, role, num, home)
    return p

func describe(peer: int) -> Dictionary:
    var pl: Array = []
    for p in ents:
        pl.append({"nick": p.nick, "team": p.team, "role": p.role, "num": p.num})
    return {"n": n, "players": pl, "my_idx": ents.find(members[peer]["player"])}

# ---------- интерфейс для rules.gd
func set_message(t: String) -> void:
    if t != message:
        message = t
        _ev(3, t, PackedFloat32Array())

func banner(text: String, col: Color, card: Color) -> void:
    _ev(1, text, PackedFloat32Array([col.r, col.g, col.b, card.r, card.g, card.b, card.a]))

func sound(snd: String, vol: float) -> void:
    _ev(2, snd, PackedFloat32Array([vol]))

func popup(pos: Vector2, text: String, col: Color) -> void:
    _ev(4, text, PackedFloat32Array([pos.x, pos.y, col.r, col.g, col.b]))

func burst(_pos: Vector2, _col: Color, _n: int, _speed: float, _life: float) -> void:
    pass

func call_foul(off, vic) -> bool:
    return rules.call_foul(off, vic)

func on_ball_kick(p) -> void:
    if rules != null:
        rules.on_kick(p)

func on_ball_touch(p) -> void:
    if rules != null:
        rules.on_touch(p)

func human_taker(t: int):
    var best = null
    var bd: float = 1e9
    for peer in members:
        var m: Dictionary = members[peer]
        if m["left"] or m["team"] != t:
            continue
        var p = m["player"]
        if p.sent_off or not teams[t].has(p):
            continue
        var d: float = p.global_position.distance_to(ball.global_position)
        if d < bd:
            bd = d
            best = p
    return best

func human_input(p) -> Dictionary:
    if p == null:
        return {}
    var owner_m: Dictionary = {}
    for peer in members:
        var m: Dictionary = members[peer]
        if m["left"]:
            continue
        var q = m["player"]
        if q == p:
            owner_m = m
            break
        if p.role == 0 and q.team == p.team and not q.sent_off and phase == "duel" and rules.keeper == p and owner_m.is_empty():
            owner_m = m
    if owner_m.is_empty():
        return {}
    return {"mv": owner_m["mv"], "shoot": (int(owner_m["btn"]) & 1) != 0}

func keeper_chooser() -> int:
    if rules.keeper == null:
        return -1
    for peer in members:
        var m: Dictionary = members[peer]
        if m["left"]:
            continue
        var q = m["player"]
        if q.team == rules.keeper.team and not q.sent_off:
            return ents.find(q)
    return -1

func on_set_taken(_p) -> void:
    prev_touch = null
    cur_touch = ball.last_toucher
    sound("whistle", -5.0)

func on_send_off(_p) -> void:
    pass

func _ev(code: int, text: String, nums: PackedFloat32Array) -> void:
    for peer in members:
        var m: Dictionary = members[peer]
        if m["left"]:
            continue
        Net.rpc_id(peer, "c_event", code, text, nums)

func gk_of(t: int):
    return teams[t][0]

func _kickoff() -> void:
    ball.puppet = false
    ball.reset_to(Vector2.ZERO)
    for p in ents:
        if p.sent_off:
            continue
        p.reset_state()
        p.global_position = Vector2(minf(p.home.x, -45.0) * p.dir_x, p.home.y)
    phase = "play"
    msg_code = 0
    cur_touch = null
    prev_touch = null

func set_input(peer: int, mx: int, my: int, btn: int) -> void:
    if not members.has(peer):
        return
    var m: Dictionary = members[peer]
    m["mv"] = (Vector2(mx, my) / 20.0).limit_length(1.0)
    if phase == "play":
        var prev: int = m["btn"]
        m["jp"] = int(m["jp"]) | (btn & ~prev)
        m["jr"] = int(m["jr"]) | (prev & ~btn)
    else:
        m["jp"] = 0
        m["jr"] = 0
    m["btn"] = btn

func player_left(peer: int) -> void:
    if not members.has(peer):
        return
    var m: Dictionary = members[peer]
    m["left"] = true
    var p = m["player"]
    p.is_human = false
    p.charging = false
    p.move_input = Vector2.ZERO
    p.nick = ""

func _update_humans() -> void:
    for peer in members:
        var m: Dictionary = members[peer]
        if m["left"]:
            continue
        var p = m["player"]
        var mv: Vector2 = m["mv"]
        var jp: int = m["jp"]
        var jr: int = m["jr"]
        p.move_input = mv
        if jp & 1:
            p.press_kick()
        if jr & 1:
            p.release_shoot()
        if jp & 2:
            p.do_skill()
        m["jp"] = 0
        m["jr"] = 0

func _separate() -> void:
    for i in ents.size():
        var a = ents[i]
        if a.sent_off:
            continue
        for j in range(i + 1, ents.size()):
            var b = ents[j]
            if b.sent_off:
                continue
            var d: Vector2 = b.global_position - a.global_position
            var l: float = d.length()
            if l < 30.0 and l > 0.01:
                var push: Vector2 = d / l * (30.0 - l) * 0.5
                if a.role != 0:
                    a.global_position -= push
                if b.role != 0:
                    b.global_position += push

func _physics_process(delta: float) -> void:
    if finished:
        return
    if phase == "play":
        time_left -= delta
        if time_left <= 0.0:
            time_left = 0.0
            _end_period()
        if phase == "play":
            rules.check_out()
        if phase == "play":
            var lt = ball.last_toucher
            if lt != cur_touch:
                prev_touch = cur_touch
                cur_touch = lt
            _compute_roles()
            _update_humans()
            _separate()
    elif phase == "set" or phase == "take" or phase == "duel":
        rules.step(delta)
    elif phase == "goal" or phase == "break":
        phase_timer -= delta
        if phase_timer <= 0.0:
            _kickoff()
    if finished:
        return
    tick_n += 1
    if tick_n % 2 == 0:
        _send_snapshots()

func _end_period() -> void:
    if period == 1:
        period = 2
        time_left = G.MATCH_HALF
        phase = "break"
        phase_timer = 2.5
        msg_code = 2
    else:
        _finish()

func _finish() -> void:
    phase = "end"
    finished = true
    var pl: Array = []
    for peer in members:
        var m: Dictionary = members[peer]
        var st: Dictionary = m["player"].stats
        pl.append({"peer": peer, "token": m["token"], "nick": m["nick"], "team": m["team"],
            "goals": m["goals"], "assists": m["assists"], "left": m["left"],
            "fouls": int(st.get("fouls", 0)), "yellows": int(st.get("yellows", 0)), "reds": int(st.get("reds", 0))})
    Net.match_finished(room_id, n, score, pl)

func _member_of(p) -> Dictionary:
    for peer in members:
        var m: Dictionary = members[peer]
        if m["player"] == p:
            return m
    return {}

func _on_goal(team: int) -> void:
    if phase != "play":
        return
    score[team] += 1
    goal_team = team
    phase = "goal"
    phase_timer = G.GOAL_PAUSE
    msg_code = 0
    scorer_idx = -1
    if cur_touch != null and cur_touch.team == team:
        scorer_idx = ents.find(cur_touch)
        var m: Dictionary = _member_of(cur_touch)
        if not m.is_empty():
            m["goals"] = int(m["goals"]) + 1
        if prev_touch != null and prev_touch != cur_touch and prev_touch.team == team:
            var m2: Dictionary = _member_of(prev_touch)
            if not m2.is_empty():
                m2["assists"] = int(m2["assists"]) + 1

func _send_snapshots() -> void:
    var base := PackedFloat32Array()
    var hi: int = -1
    if ball.holder != null:
        hi = ents.find(ball.holder)
    base.append_array(PackedFloat32Array([float(PH[phase]), time_left, float(score[0]), float(score[1]),
        float(period), ball.global_position.x, ball.global_position.y, ball.vel.x, ball.vel.y,
        float(hi), float(goal_team), float(msg_code), float(scorer_idx), ball.z]))
    var tk: int = -1
    var sh: int = -1
    var chooser: int = -1
    if rules.taker != null and rules.active():
        tk = ents.find(rules.taker)
    if rules.stage == "duel_pick" or rules.stage == "duel_run":
        sh = ents.find(rules.shooter)
        chooser = keeper_chooser()
    var tleft: float = 0.0
    if rules.stage == "take":
        tleft = maxf(0.0, RulesScript.TAKE_TIMEOUT - rules.timer)
    elif rules.stage == "duel_pick":
        tleft = maxf(0.0, RulesScript.PICK_TIMEOUT - rules.timer)
    base.append_array(PackedFloat32Array([float(RulesScript.KIND_CODE.get(rules.kind, 0)) if rules.active() else 0.0,
        float(rules.team), float(tk), rules.aim.x, rules.aim.y, rules.charge,
        float(STAGE.get(rules.stage, 0)), 1.0 if rules.s_lock else 0.0, 1.0 if rules.g_lock else 0.0,
        float(sh), float(chooser), tleft]))
    for p in ents:
        var fl: int = 0
        if p.recover_t > 0.0:
            fl |= 1
        if p.skill_t > 0.0:
            fl |= 2
        if p.charging:
            fl |= 4
        if p.shield_t > 0.0:
            fl |= 8
        if p.sent_off:
            fl |= 16
        if p.yellow > 0:
            fl |= 32
        if p.hands_up:
            fl |= 64
        base.append_array(PackedFloat32Array([p.global_position.x, p.global_position.y, p.facing.x, p.facing.y,
            float(p.state), p.charge, float(fl), p.dive_vec.angle(), float(p.kick_kind), p.kick_t]))
    for t in 2:
        var tot: Array = [0, 0, 0, 0, 0, 0, 0, 0]
        var keys: Array = ["shots", "tackles", "feints", "assists", "saves", "fouls", "yellows", "reds"]
        for p in ents:
            if p.team != t:
                continue
            for i in 8:
                tot[i] = int(tot[i]) + int(p.stats.get(keys[i], 0))
        for i in 8:
            base.append(float(tot[i]))
    for peer in members:
        var m: Dictionary = members[peer]
        if m["left"]:
            continue
        var p = m["player"]
        var a: PackedFloat32Array = base.duplicate()
        var pt: int = -1
        if ball.holder == p and phase == "play":
            var t = find_pass_target(p, m["mv"])
            if t != null:
                pt = ents.find(t)
        a.append_array(PackedFloat32Array([p.skill_cd, p.tackle_cd, p.recover_t, float(pt)]))
        Net.rpc_id(peer, "c_snap", a)

func _compute_roles() -> void:
    var bp: Vector2 = ball.global_position
    var h = ball.holder
    for t in 2:
        var best = null
        var bd: float = 1e9
        var human_d: float = 1e9
        for p in teams[t]:
            if p.role == 0:
                continue
            var d: float = p.global_position.distance_to(bp)
            if p.is_human:
                human_d = minf(human_d, d)
                continue
            if d < bd:
                bd = d
                best = p
        if human_d + 40.0 < bd:
            best = null
        presser[t] = null
        chaser[t] = null
        if h == null:
            chaser[t] = best
        elif h.team != t and h.role != 0:
            presser[t] = best
        var threats: Array = []
        for o in teams[1 - t]:
            if o.role != 0 and o != h:
                threats.append(o)
        var own_goal_x: float = -G.HALF_W * (1.0 if t == 0 else -1.0)
        threats.sort_custom(func(a, b): return absf(a.global_position.x - own_goal_x) < absf(b.global_position.x - own_goal_x))
        var i: int = 0
        for p in teams[t]:
            p.mark_target = null
            if p.role == 0 or p.is_human or p == presser[t]:
                continue
            if i < threats.size():
                p.mark_target = threats[i]
            i += 1

func find_pass_target(p, dir: Vector2):
    var best = null
    var best_s: float = -1e9
    var pp: Vector2 = p.global_position
    var dx: float = 1.0 if p.team == 0 else -1.0
    for q in teams[p.team]:
        if q == p or q.role == 0:
            continue
        if rules != null and rules.would_be_offside(p, q.global_position):
            continue
        var to: Vector2 = q.global_position - pp
        var d: float = to.length()
        if d < 70.0:
            continue
        var s: float = 0.0
        if dir.length() > 0.3:
            var c: float = dir.normalized().dot(to / d)
            if c < 0.45:
                continue
            s += c * 3.0
        else:
            s += (to.x * dx) / 400.0
        var open: float = 300.0
        for o in teams[1 - p.team]:
            var od: float = o.global_position.distance_to(q.global_position)
            open = minf(open, od)
            if o.role != 0:
                var cp: Vector2 = Geometry2D.get_closest_point_to_segment(o.global_position, pp, q.global_position)
                if cp.distance_to(o.global_position) < 30.0:
                    s -= 1.5
        s += open / 150.0
        s -= d / 700.0
        if s > best_s:
            best_s = s
            best = q
    return best
