extends RefCounted
# Общие правила матча: фолы, карточки, удаления, ауты/угловые/удары от ворот,
# ручное исполнение стандартов и дуэль «пенальти / близкий штрафной».
# Используется и офлайн-игрой (main.gd), и сервером (match_sim.gd).
#
# Что должен уметь «хозяин» (host):
#   поля: ball, teams, presser, chaser, phase (String)
#   gk_of(t), find_pass_target(p, dir)
#   set_message(text), banner(text, col, card), sound(name, vol), popup(pos, text, col), burst(...)
#   human_input(p) -> {} или {"mv": Vector2, "shoot": bool}
#   human_taker(t) -> игрок или null
#   on_set_taken(p), on_send_off(p)
#   (необязательно) try_var_foul(off, vic, card, kind, spot) -> bool

const ST_IDLE := 0
const ST_DIVE := 8
const KIND_CODE := {"": 0, "throw": 1, "corner": 2, "goalkick": 3, "free": 4, "penalty": 5}
const DUEL_FREE_DIST := 430.0
const TAKE_TIMEOUT := 8.0
const PICK_TIMEOUT := 7.0

var h = null
var kind: String = ""
var team: int = 0
var pos: Vector2 = Vector2.ZERO
var taker = null
var fouled = null
var stage: String = ""
var timer: float = 0.0
var aim: Vector2 = Vector2.RIGHT
var charge: float = 0.0
var charging: bool = false
var was_down: bool = true
var bot_wait: float = 1.0
var wall_pos: Vector2 = Vector2.ZERO
var off_snap: Dictionary = {}
var indirect: bool = false
var forced_taker = null

var shooter = null
var keeper = null
var s_col: int = 0
var s_hi: int = 0
var s_lock: bool = false
var s_was: bool = true
var g_side: int = 0
var g_lock: bool = false
var g_was: bool = true
var s_bot_t: float = 1.5
var g_bot_t: float = 1.8
var run_t: float = 0.0
var outcome: String = ""
var tgt: Vector2 = Vector2.ZERO
var tz: float = 0.0
var ball_from: Vector2 = Vector2.ZERO
var gk_from: Vector2 = Vector2.ZERO
var gk_to: Vector2 = Vector2.ZERO

func _init(host) -> void:
    h = host

func active() -> bool:
    return stage != ""

func team_name(t: int) -> String:
    return G.team_name(t)

func in_box(t: int, p: Vector2) -> bool:
    var dx: float = 1.0 if t == 0 else -1.0
    var gx: float = -G.HALF_W * dx
    var depth: float = (p.x - gx) * dx
    return depth > 0.0 and depth < G.PEN_DEPTH and absf(p.y) < G.PEN_HALF

func keep_in(p: Vector2) -> Vector2:
    return Vector2(clampf(p.x, -G.HALF_W + 24.0, G.HALF_W - 24.0), clampf(p.y, -G.HALF_H + 24.0, G.HALF_H - 24.0))

# ---------------------------------------------------------------- фолы

func call_foul(off, vic) -> bool:
    if h.phase != "play":
        return false
    off.stats["fouls"] = int(off.stats["fouls"]) + 1
    var n: int = int(off.stats["fouls"])
    var r: float = randf()
    var card: int = 0
    if r < 0.04:
        card = 2
    elif r < 0.18 + 0.12 * float(n - 1):
        card = 1
    var k: String = "free"
    var spot: Vector2 = vic.global_position
    if in_box(off.team, spot):
        k = "penalty"
        spot = Vector2((G.HALF_W - 160.0) * (1.0 if vic.team == 0 else -1.0), 0.0)
    if h.has_method("try_var_foul") and h.try_var_foul(off, vic, card, k, spot):
        return true
    apply_foul(off, vic, card, k, spot)
    return true

func apply_foul(off, vic, card: int, k: String, spot: Vector2) -> void:
    var title: String = "ФОЛ №%d — %s" % [off.num, team_name(off.team)]
    var col: Color = Color(1, 1, 1)
    var cardcol: Color = Color(0, 0, 0, 0)
    var snd: String = "foul"
    if card == 0:
        if off.warned < 1:
            off.warned += 1
            title = "ПРЕДУПРЕЖДЕНИЕ №%d — %s" % [off.num, team_name(off.team)]
            col = Color(1.0, 0.8, 0.4)
    elif card == 1:
        off.yellow += 1
        off.stats["yellows"] = int(off.stats.get("yellows", 0)) + 1
        title = "ЖЁЛТАЯ КАРТОЧКА №%d — %s" % [off.num, team_name(off.team)]
        col = Color(1.0, 0.92, 0.2)
        cardcol = Color(1.0, 0.88, 0.05)
        snd = "card"
        if off.yellow >= 2:
            card = 2
            title = "ВТОРАЯ ЖЁЛТАЯ — КРАСНАЯ №%d — %s" % [off.num, team_name(off.team)]
    if card == 2:
        col = Color(1.0, 0.3, 0.3)
        cardcol = Color(0.9, 0.05, 0.05)
        snd = "card"
        if G.train == "" and h.teams[off.team].size() > 3:
            off.stats["reds"] = int(off.stats.get("reds", 0)) + 1
            send_off(off)
        else:
            title = "ЖЁЛТАЯ КАРТОЧКА №%d — %s" % [off.num, team_name(off.team)]
            cardcol = Color(1.0, 0.88, 0.05)
            col = Color(1.0, 0.92, 0.2)
    h.banner(title, col, cardcol)
    h.sound(snd, 0.0)
    h.popup(off.global_position + Vector2(0, -20), "ФОЛ", Color(1, 0.5, 0.3))
    start_set(k, vic.team, spot, vic)

func send_off(p) -> void:
    h.teams[p.team].erase(p)
    if h.ball.holder == p:
        h.ball.holder = null
    for t in 2:
        if h.presser[t] == p:
            h.presser[t] = null
        if h.chaser[t] == p:
            h.chaser[t] = null
        for q in h.teams[t]:
            if q.mark_target == p:
                q.mark_target = null
    p.is_human = false
    p.charging = false
    p.sent_off = true
    p.visible = false
    p.collision_layer = 0
    p.collision_mask = 0
    p.global_position = Vector2(9000, 9000)
    p.process_mode = Node.PROCESS_MODE_DISABLED
    h.on_send_off(p)

# ---------------------------------------------------------------- аут / угловой / от ворот

func check_out() -> void:
    if G.train == "solo" or h.ball.holder != null:
        return
    var ball = h.ball
    var p: Vector2 = ball.global_position
    var hw: float = G.HALF_W
    var hh: float = G.HALF_H
    var lt: int = ball.last_team if ball.last_team >= 0 else 0
    if absf(p.y) > hh + 4.0:
        var spot := Vector2(clampf(p.x, -hw + 40.0, hw - 40.0), signf(p.y) * (hh - 4.0))
        start_set("throw", 1 - lt, spot, null)
    elif absf(p.x) > hw + 4.0 and (absf(p.y) > G.GOAL_HALF or ball.z > 36.0):
        var defending: int = 1 if p.x > 0.0 else 0
        var sx: float = signf(p.x)
        var sy: float = signf(p.y) if absf(p.y) > 1.0 else 1.0
        if lt == defending:
            start_set("corner", 1 - defending, Vector2(sx * (hw - 8.0), sy * (hh - 8.0)), null)
        else:
            start_set("goalkick", defending, Vector2(sx * (hw - 70.0), 0.0), null)

# ---------------------------------------------------------------- офсайд

func _opp_line(t: int) -> float:
    # x (в системе координат атаки команды t) предпоследнего защитника, вратарь учитывается
    var dx: float = 1.0 if t == 0 else -1.0
    var xs: Array = []
    for o in h.teams[1 - t]:
        xs.append(o.global_position.x * dx)
    if xs.size() < 2:
        return 1e9
    xs.sort()
    return float(xs[xs.size() - 2])

func would_be_offside(passer, mate_pos: Vector2) -> bool:
    if not G.offside_on or G.train == "solo" or G.train == "shootout":
        return false
    var dx: float = 1.0 if passer.team == 0 else -1.0
    var mx: float = mate_pos.x * dx
    return mx > 0.0 and mx > passer.global_position.x * dx and mx > _opp_line(passer.team) + 4.0

func on_kick(p) -> void:
    if not G.offside_on or h.phase != "play" or G.train == "solo" or G.train == "shootout" or p == null:
        return
    off_snap = {}
    var t: int = p.team
    var dx: float = 1.0 if t == 0 else -1.0
    var line: float = _opp_line(t)
    if line > 1e8:
        return
    var ball_x: float = maxf(h.ball.global_position.x * dx, p.global_position.x * dx)
    var cands: Array = []
    for q in h.teams[t]:
        if q == p or q.role == 0 or q.sent_off:
            continue
        var qx: float = q.global_position.x * dx
        if qx > 0.0 and qx > ball_x and qx > line + 4.0:
            cands.append(q)
    if cands.is_empty():
        return
    off_snap = {"team": t, "passer": p, "cands": cands, "ms": Time.get_ticks_msec(), "line": line * dx}

func on_touch(p) -> void:
    if off_snap.is_empty() or h.phase != "play" or p == null:
        return
    if Time.get_ticks_msec() - int(off_snap["ms"]) > 7000:
        off_snap = {}
        return
    if p == off_snap["passer"]:
        return
    if p.team != int(off_snap["team"]):
        off_snap = {}
        return
    var cands: Array = off_snap["cands"]
    if cands.has(p):
        call_offside(p)
    else:
        off_snap = {}

func call_offside(p) -> void:
    var line_x: float = float(off_snap.get("line", p.global_position.x))
    off_snap = {}
    if h.phase != "play":
        return
    p.stats["offsides"] = int(p.stats.get("offsides", 0)) + 1
    var spot: Vector2 = keep_in(p.global_position)
    h.banner("ОФСАЙД №%d — %s" % [p.num, team_name(p.team)], Color(1.0, 0.85, 0.3), Color(0, 0, 0, 0))
    h.sound("whistle", -2.0)
    h.popup(p.global_position + Vector2(0, -20), "ОФСАЙД", Color(1.0, 0.85, 0.3))
    var fxn = h.get("fx")
    if fxn != null and fxn.has_method("show_offside"):
        fxn.show_offside(line_x)
    start_set("free", 1 - p.team, spot, null)
    indirect = true
    h.set_message("ОФСАЙД — СВОБОДНЫЙ УДАР — " + team_name(1 - p.team))

# ---------------------------------------------------------------- стандарт: объявление

func start_set(k: String, t: int, p: Vector2, fouled_p) -> void:
    off_snap = {}
    indirect = false
    kind = k
    team = t
    pos = p
    fouled = fouled_p
    stage = "announce"
    h.phase = "set"
    timer = 2.3 if k == "penalty" else 1.6
    var tn: String = team_name(t)
    var label: String = ""
    match k:
        "throw":
            label = "АУТ — " + tn
        "corner":
            label = "УГЛОВОЙ — " + tn
        "goalkick":
            label = "УДАР ОТ ВОРОТ — " + tn
        "penalty":
            label = "ПЕНАЛЬТИ — " + tn
        _:
            var goal: Vector2 = Vector2(G.HALF_W * (1.0 if t == 0 else -1.0), 0.0)
            label = ("ШТРАФНОЙ — " if p.distance_to(goal) < 560.0 else "СВОБОДНЫЙ УДАР — ") + tn
    h.set_message(label)
    if k == "throw" or k == "corner" or k == "goalkick":
        h.sound("whistle", -3.0)
    var ball = h.ball
    ball.holder = null
    ball.puppet = false
    ball.vel = Vector2.ZERO
    ball.spin = 0.0
    ball.z = 0.0
    ball.vz = 0.0
    ball.shooter = null
    ball.global_position = p
    taker = _pick_taker()
    shooter = null
    keeper = null
    _arrange()

func _pick_taker():
    if kind == "goalkick":
        return h.gk_of(team)
    if forced_taker != null and is_instance_valid(forced_taker) and h.teams[team].has(forced_taker):
        return forced_taker
    var ht = h.human_taker(team)
    if ht != null and ht.role != 0 and h.teams[team].has(ht):
        return ht
    if kind == "penalty" and fouled != null and is_instance_valid(fouled) and h.teams[team].has(fouled) and fouled.role != 0:
        return fouled
    var best = null
    var bd: float = 1e9
    for p in h.teams[team]:
        if p.role == 0:
            continue
        var d: float = p.global_position.distance_to(pos)
        if d < bd:
            bd = d
            best = p
    if best == null:
        best = h.gk_of(team)
    return best

func _arrange() -> void:
    var t: int = team
    var dx: float = 1.0 if t == 0 else -1.0
    var face: Vector2 = Vector2(dx, 0.0)
    if kind == "throw":
        face = Vector2(0.0, -signf(pos.y))
    elif kind == "corner":
        face = (Vector2(G.HALF_W * dx * 0.7, 0.0) - pos).normalized()
    if taker != null:
        taker.reset_state()
        taker.hands_up = false
        taker.facing = face
        taker.global_position = keep_in(pos - face * 21.0)
        if kind == "throw" or kind == "corner":
            taker.global_position = pos - face * 21.0
    var goal: Vector2 = Vector2(G.HALF_W * dx, 0.0)
    for o in h.teams[1 - t]:
        if o.role == 0 or kind == "penalty":
            continue
        var v: Vector2 = o.global_position - pos
        var l: float = v.length()
        if l < 150.0:
            if l < 1.0:
                v = Vector2(-dx, 0.0)
                l = 1.0
            o.global_position = keep_in(pos + v / l * 150.0)
    wall_pos = pos
    if kind == "free" and pos.distance_to(goal) < 560.0:
        var wall: Array = []
        for o in h.teams[1 - t]:
            if o.role != 0:
                wall.append(o)
        wall.sort_custom(func(a, b): return a.global_position.distance_to(goal) < b.global_position.distance_to(goal))
        var gd: Vector2 = (goal - pos).normalized()
        var base: Vector2 = pos + gd * 140.0
        wall_pos = base
        for i in mini(2, wall.size()):
            wall[i].global_position = keep_in(base + gd.orthogonal() * (float(i) - 0.5) * 36.0)
    if kind == "corner":
        var k: int = 0
        for q in h.teams[t]:
            if q == taker or q.role == 0:
                continue
            if k < 2:
                q.global_position = Vector2((G.HALF_W - 130.0) * dx, (-50.0 if k == 0 else 50.0))
            k += 1
        k = 0
        for o in h.teams[1 - t]:
            if o.role == 0:
                continue
            if k < 2:
                o.global_position = Vector2((G.HALF_W - 95.0) * dx, (-70.0 if k == 0 else 70.0))
            k += 1
    if kind == "penalty":
        var gk = h.gk_of(1 - t)
        gk.reset_state()
        gk.global_position = Vector2(G.HALF_W * dx - dx * 22.0, 0.0)
        var line_x: float = (G.HALF_W - G.PEN_DEPTH - 50.0)
        for q in h.teams[0] + h.teams[1]:
            if q == taker or q == gk or q.role == 0:
                continue
            var px: float = q.global_position.x * dx
            if px > line_x:
                q.global_position = Vector2((line_x - randf_range(0.0, 90.0)) * dx, q.global_position.y)
    if kind == "goalkick" and taker != null:
        taker.global_position = Vector2(pos.x, 0.0)
    h.ball.global_position = pos

# ---------------------------------------------------------------- шаг

func step(delta: float) -> void:
    match stage:
        "announce":
            timer -= delta
            if timer <= 0.0:
                _after_announce()
        "take":
            _step_take(delta)
        "duel_pick":
            _step_pick(delta)
        "duel_run":
            _step_run(delta)

func _after_announce() -> void:
    var dx: float = 1.0 if team == 0 else -1.0
    var goal: Vector2 = Vector2(G.HALF_W * dx, 0.0)
    var duel: bool = false
    if taker != null and taker.role != 0 and h.gk_of(1 - team) != null:
        if kind == "penalty":
            duel = true
        elif kind == "free" and not indirect and pos.distance_to(goal) < DUEL_FREE_DIST:
            duel = true
    if duel:
        _begin_duel()
    else:
        _begin_take()

# ---------------------------------------------------------------- ручное исполнение (аут руками, угловой ногой, ...)

func _default_aim() -> Vector2:
    var dx: float = 1.0 if team == 0 else -1.0
    match kind:
        "throw":
            return Vector2(0.0, -signf(pos.y))
        "corner":
            return (Vector2((G.HALF_W - 150.0) * dx, 0.0) - pos).normalized()
        "goalkick":
            return Vector2(dx, 0.0)
    return (Vector2(G.HALF_W * dx, 0.0) - pos).normalized()

func _begin_take() -> void:
    stage = "take"
    h.phase = "take"
    timer = 0.0
    charge = 0.0
    charging = false
    was_down = true
    aim = _default_aim()
    bot_wait = randf_range(0.9, 1.5)
    var ball = h.ball
    ball.holder = null
    ball.puppet = true
    ball.net_vel = Vector2.ZERO
    ball.vel = Vector2.ZERO
    if taker != null:
        taker.hands_up = (kind == "throw")
    h.set_message("")
    _hold_ball()

func _hold_ball() -> void:
    if taker == null:
        return
    taker.facing = aim
    var ball = h.ball
    if kind == "throw":
        ball.net_pos = taker.global_position + aim * 4.0
        ball.net_z = 46.0
    else:
        ball.net_pos = taker.global_position + aim * 21.0
        ball.net_z = 0.0
    ball.global_position = ball.net_pos
    ball.z = ball.net_z

func _step_take(delta: float) -> void:
    timer += delta
    if taker == null or not is_instance_valid(taker):
        _end_set()
        return
    var inp: Dictionary = h.human_input(taker)
    if not inp.is_empty():
        var mv: Vector2 = inp["mv"]
        if mv.length() > 0.3:
            aim = mv.normalized()
        var down: bool = bool(inp["shoot"])
        if down and not was_down:
            charging = true
            charge = 0.0
        if charging and down:
            charge = minf(charge + delta, 1.0)
        if charging and not down:
            _launch(maxf(charge, 0.2))
            return
        was_down = down
        if timer > TAKE_TIMEOUT:
            _bot_aim()
            _launch(maxf(charge, 0.5))
            return
    elif timer >= bot_wait:
        var c: float = _bot_aim()
        _launch(c)
        return
    _hold_ball()

func _bot_aim() -> float:
    var dx: float = 1.0 if team == 0 else -1.0
    var c: float = 0.7
    match kind:
        "throw":
            var mate = h.find_pass_target(taker, Vector2.ZERO)
            if mate != null:
                var to: Vector2 = mate.global_position - taker.global_position
                aim = to.normalized()
                c = clampf(to.length() / 560.0, 0.25, 1.0)
            else:
                aim = _default_aim()
        "corner":
            var tp: Vector2 = Vector2((G.HALF_W - 150.0) * dx, randf_range(-70.0, 70.0))
            aim = (tp - pos).normalized()
            c = 0.72
        "goalkick":
            aim = Vector2(dx, randf_range(-0.35, 0.35)).normalized()
            c = 0.8
        _:
            aim = (Vector2(G.HALF_W * dx, randf_range(-80.0, 80.0)) - pos).normalized()
            c = 0.65
    return c

func _launch(c: float) -> void:
    var t = taker
    var ball = h.ball
    var d: Vector2 = aim
    if d.length() < 0.2:
        d = _default_aim()
    d = d.normalized()
    ball.puppet = false
    ball.vel = Vector2.ZERO
    ball.z = 0.0
    ball.vz = 0.0
    ball.global_position = t.global_position + d * 21.0
    t.facing = d
    t.hands_up = false
    t.charging = false
    match kind:
        "throw":
            ball.z = 46.0
            ball.kick(d, lerpf(380.0, 760.0, c), 0.0, null, lerpf(140.0, 250.0, c))
            ball.touch(t)
            ball.last_team = t.team
            t.kick_lock = 0.5
            h.sound("kick_low", -7.0)
        "corner":
            ball.kick(d.rotated(randf_range(-0.05, 0.05)), lerpf(520.0, 900.0, c), randf_range(-0.35, 0.35), t, lerpf(250.0, 430.0, c))
            _count_shot(t, d)
        "goalkick":
            ball.kick(d.rotated(randf_range(-0.08, 0.08)), lerpf(600.0, 900.0, c), randf_range(-0.2, 0.2), t, lerpf(280.0, 430.0, c))
        _:
            ball.give_to(t)
            t.charging = true
            t.charge = clampf(c, 0.0, 1.0)
            t.move_input = d
            t.release_shoot()
    t.pass_cd = 0.4
    _end_set()
    h.on_set_taken(t)

func _count_shot(t, d: Vector2) -> void:
    var goal: Vector2 = Vector2(G.HALF_W * t.dir_x, 0.0)
    if t.global_position.distance_to(goal) < 760.0 and absf(d.angle_to(goal - t.global_position)) < 0.65:
        t.stats["shots"] = int(t.stats["shots"]) + 1

func _end_set() -> void:
    stage = ""
    h.phase = "play"
    h.set_message("")
    h.ball.puppet = false
    if taker != null and is_instance_valid(taker):
        taker.hands_up = false

# ---------------------------------------------------------------- дуэль: пенальти / близкий штрафной

func _begin_duel() -> void:
    shooter = taker
    keeper = h.gk_of(1 - team)
    stage = "duel_pick"
    h.phase = "duel"
    timer = 0.0
    s_col = 0
    s_hi = 0
    s_lock = false
    s_was = true
    g_side = 0
    g_lock = false
    g_was = true
    s_bot_t = randf_range(1.2, 2.0)
    g_bot_t = randf_range(1.5, 2.4)
    var dx: float = 1.0 if team == 0 else -1.0
    keeper.reset_state()
    keeper.global_position = Vector2(G.HALF_W * dx - dx * 22.0, 0.0)
    var ball = h.ball
    ball.puppet = true
    ball.net_pos = pos
    ball.net_vel = Vector2.ZERO
    ball.net_z = 0.0
    ball.global_position = pos
    ball.z = 0.0
    shooter.facing = (Vector2(G.HALF_W * dx, 0.0) - pos).normalized()
    h.set_message("")

func hud_pick(p, ui_col: int, hi: int) -> void:
    if stage != "duel_pick":
        return
    if p == shooter and not s_lock:
        s_col = ui_col * int(shooter.dir_x)
        s_hi = hi
        s_lock = true
    elif p == keeper and not g_lock:
        g_side = ui_col * int(keeper.dir_x)
        g_lock = true

func _ui_col(x: float) -> int:
    if absf(x) < 0.35:
        return 0
    return 1 if x > 0.0 else -1

func _step_pick(delta: float) -> void:
    timer += delta
    var si: Dictionary = h.human_input(shooter)
    if not s_lock:
        if not si.is_empty():
            var mv: Vector2 = si["mv"]
            s_col = _ui_col(mv.x) * int(shooter.dir_x)
            s_hi = 1 if mv.y < -0.35 else 0
            var dn: bool = bool(si["shoot"])
            if dn and not s_was:
                s_lock = true
            s_was = dn
            if timer > PICK_TIMEOUT:
                s_lock = true
        elif timer >= s_bot_t:
            var r: float = randf()
            s_col = -1 if r < 0.4 else (0 if r < 0.6 else 1)
            s_hi = 1 if randf() < 0.4 else 0
            s_lock = true
    var gi: Dictionary = h.human_input(keeper)
    if not g_lock:
        if not gi.is_empty():
            var gmv: Vector2 = gi["mv"]
            g_side = _ui_col(gmv.x) * int(keeper.dir_x)
            var gd: bool = bool(gi["shoot"])
            if gd and not g_was:
                g_lock = true
            g_was = gd
            if timer > PICK_TIMEOUT:
                g_lock = true
        elif timer >= g_bot_t:
            var r2: float = randf()
            g_side = -1 if r2 < 0.38 else (0 if r2 < 0.62 else 1)
            g_lock = true
    if s_lock and g_lock:
        _start_run()

func _roll_outcome(s: int, hi: int, g: int) -> String:
    var is_free: bool = kind == "free"
    if is_free and hi == 0 and s == 0 and randf() < 0.55:
        return "wall"
    var miss: float = 0.06 + (0.07 if s != 0 else 0.0) + (0.08 if hi == 1 else 0.0) + (0.06 if is_free else 0.0)
    if randf() < miss:
        if randf() < 0.35:
            return "post"
        if hi == 1 and randf() < 0.6:
            return "over"
        return "wide"
    var save_p: float = 0.0
    if g == s:
        save_p = 0.82 if hi == 0 else 0.62
        if s == 0:
            save_p += 0.08
    elif g == 0 and s != 0:
        save_p = 0.10
    elif s == 0 and g != 0:
        save_p = 0.12
    if randf() < save_p:
        return "save"
    return "goal"

func _start_run() -> void:
    stage = "duel_run"
    run_t = 0.0
    var dx: float = 1.0 if team == 0 else -1.0
    var gx: float = G.HALF_W * dx
    var s: int = s_col
    outcome = _roll_outcome(s, s_hi, g_side)
    ball_from = pos
    var rs: float = float(s) if s != 0 else (1.0 if randf() < 0.5 else -1.0)
    match outcome:
        "goal", "save":
            tgt = Vector2(gx - dx * 6.0, float(s) * G.GOAL_HALF * 0.78 + (randf_range(-8.0, 8.0) if s == 0 else 0.0))
            tz = 28.0 if s_hi == 1 else 8.0
        "post":
            tgt = Vector2(gx - dx * 4.0, rs * G.GOAL_HALF)
            tz = 14.0
        "wide":
            tgt = Vector2(gx - dx * 4.0, rs * (G.GOAL_HALF + 70.0))
            tz = 6.0
        "over":
            tgt = Vector2(gx - dx * 12.0, float(s) * G.GOAL_HALF * 0.7)
            tz = 70.0
        _:
            tgt = wall_pos
            tz = 10.0
    shooter.kick_kind = 2 if s_hi == 1 else 1
    shooter.kick_t = 0.32
    shooter.stats["shots"] = int(shooter.stats["shots"]) + 1
    h.sound("kick_high" if s_hi == 1 else "kick_low", 0.0)
    gk_from = keeper.global_position
    gk_to = Vector2(gk_from.x, float(g_side) * 82.0)
    if g_side != 0:
        keeper.dive_vec = Vector2(0.0, float(g_side))
        keeper.state = ST_DIVE
    else:
        gk_to = gk_from + Vector2(-dx * 10.0, 0.0)

func _step_run(delta: float) -> void:
    run_t += delta
    var ball = h.ball
    if run_t >= 0.14:
        var k: float = clampf((run_t - 0.14) / 0.34, 0.0, 1.0)
        var bp: Vector2 = ball_from.lerp(tgt, k)
        var arc: float = sin(k * PI) * (14.0 if s_hi == 1 else 4.0)
        ball.net_pos = bp
        ball.net_z = lerpf(0.0, tz, k) + arc
        ball.global_position = bp
        ball.z = ball.net_z
        ball.net_vel = (tgt - ball_from).normalized() * 900.0
    var gk_k: float = clampf((run_t - 0.1) / 0.35, 0.0, 1.0)
    keeper.global_position = gk_from.lerp(gk_to, gk_k)
    if run_t >= 0.5:
        _finish_run()

func _finish_run() -> void:
    var dx: float = 1.0 if team == 0 else -1.0
    var gx: float = G.HALF_W * dx
    var ball = h.ball
    stage = ""
    h.phase = "play"
    h.set_message("")
    ball.puppet = false
    ball.vel = Vector2.ZERO
    ball.spin = 0.0
    ball.vz = 0.0
    ball.z = 0.0
    ball.holder = null
    match outcome:
        "goal":
            ball.global_position = Vector2(gx + dx * 18.0, tgt.y)
            ball.z = 10.0
            ball.vel = Vector2(dx * 120.0, 0.0)
            ball._goal_emitted = false
        "save":
            keeper.stats["saves"] = int(keeper.stats["saves"]) + 1
            h.popup(keeper.global_position + Vector2(0, -40), "СЕЙВ!", Color(0.4, 0.9, 1.0))
            h.sound("save", 0.0)
            ball.global_position = keeper.global_position + Vector2(-dx * 14.0, 0.0)
            if randf() < 0.6:
                ball.give_to(keeper)
            else:
                ball.vel = Vector2(-dx * 320.0, float(s_col) * 140.0 + randf_range(-120.0, 120.0))
        "post":
            ball.global_position = tgt - Vector2(dx * 14.0, 0.0)
            ball.vel = Vector2(-dx * 280.0, -signf(tgt.y) * 90.0 + randf_range(-60.0, 60.0))
            h.sound("post", 0.0)
        "wide":
            ball.global_position = tgt
            ball.vel = Vector2(dx * 320.0, signf(tgt.y) * 90.0)
            ball.z = tz
        "over":
            ball.global_position = tgt
            ball.vel = Vector2(dx * 320.0, signf(tgt.y) * 40.0)
            ball.z = tz
        _:
            ball.global_position = tgt
            ball.vel = Vector2(-dx * 260.0, randf_range(-220.0, 220.0))
            h.sound("block", 0.0)
    if outcome != "goal":
        ball.last_team = shooter.team
    ball.touch(shooter)
    ball.last_team = shooter.team
    if outcome == "save" and ball.holder == keeper:
        ball.touch(keeper)
        ball.last_team = keeper.team
    if g_side != 0:
        keeper.getup_t = 0.6
        keeper.dive_cd = 0.8
    shooter.kick_lock = 0.4
    if outcome == "goal":
        ball.shooter = null
    h.on_set_taken(shooter)

# ---------------------------------------------------------------- информация для HUD

func info_for(p) -> Dictionary:
    var d: Dictionary = {"stage": stage, "kind": kind, "team": team, "role": "", "aim": aim, "charge": charge,
        "col": 0, "hi": 0, "locked": false, "opp_locked": false, "t": 0.0, "tpos": Vector2.ZERO}
    if taker != null and is_instance_valid(taker):
        d["tpos"] = taker.global_position
    if stage == "take":
        d["role"] = "taker" if p == taker else ""
        d["t"] = maxf(0.0, TAKE_TIMEOUT - timer)
    elif stage == "duel_pick":
        d["t"] = maxf(0.0, PICK_TIMEOUT - timer)
        if p == shooter:
            d["role"] = "shooter"
            d["col"] = s_col * int(shooter.dir_x)
            d["hi"] = s_hi
            d["locked"] = s_lock
            d["opp_locked"] = g_lock
        elif p == keeper:
            d["role"] = "keeper"
            d["col"] = g_side * int(keeper.dir_x)
            d["locked"] = g_lock
            d["opp_locked"] = s_lock
    return d
