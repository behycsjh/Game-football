extends CharacterBody2D

signal goal_scored(team: int)

const RADIUS: float = 9.0
const DRAG: float = 1.3
const ROLL_FRICTION: float = 55.0
const WALL_BOUNCE: float = 0.72
const POST_BOUNCE: float = 0.78
const GRAVITY: float = 950.0
const BAR_H: float = 36.0

var vel: Vector2 = Vector2.ZERO
var spin: float = 0.0
var holder = null
var last_toucher = null
var last_team: int = -1
var roll: float = 0.0
var trail: Array = []
var z: float = 0.0
var vz: float = 0.0
var _goal_emitted: bool = false
var bounds_open: bool = false
var shooter = null
var assist_from = null
var assist_ms: int = 0
var touch_ms: int = 0

var puppet: bool = false
var net_pos: Vector2 = Vector2.ZERO
var net_vel: Vector2 = Vector2.ZERO
var net_z: float = 0.0

func _physics_process(delta: float) -> void:
    if puppet:
        if global_position.distance_to(net_pos) > 250.0:
            global_position = net_pos
        else:
            global_position = global_position.lerp(net_pos, clampf(22.0 * delta, 0.0, 1.0))
        vel = net_vel
        z = lerpf(z, net_z, clampf(22.0 * delta, 0.0, 1.0))
        roll += vel.length() * delta / RADIUS * (1.0 if vel.x >= 0.0 else -1.0)
        return
    if holder != null:
        var target: Vector2 = holder.global_position + holder.facing * 21.0
        global_position = global_position.lerp(target, clampf(30.0 * delta, 0.0, 1.0))
        vel = holder.velocity
        z = 0.0
        vz = 0.0
        spin = 0.0
        roll += holder.velocity.length() * delta / RADIUS * 0.8
        return
    var steps: int = 3
    var h: float = delta / float(steps)
    for i in steps:
        _step(h)
    roll += vel.length() * delta / RADIUS * (1.0 if vel.x >= 0.0 else -1.0)

func _step(h: float) -> void:

    if z > 0.0 or vz > 0.0:
        vz -= GRAVITY * h
        z += vz * h
        if z <= 0.0:
            z = 0.0
            if vz < -120.0:
                vz = -vz * 0.45
                vel *= 0.9
            else:
                vz = 0.0
    var air: bool = z > 2.0
    if spin != 0.0 and vel.length() > 40.0:
        vel += vel.orthogonal().normalized() * spin * vel.length() * 0.9 * h
        spin = move_toward(spin, 0.0, 0.6 * h)
    vel -= vel * (0.35 if air else DRAG) * h
    if not air:
        vel = vel.move_toward(Vector2.ZERO, ROLL_FRICTION * h)
    global_position += vel * h
    _collide()
    _check_goal()

func _collide() -> void:
    var p: Vector2 = global_position
    var hw: float = G.HALF_W
    var hh: float = G.HALF_H
    var gh: float = G.GOAL_HALF

    for post in G.POSTS:
        var d: Vector2 = p - post
        var md: float = RADIUS + G.POST_R
        var dl: float = d.length()
        if dl < md:
            var n: Vector2 = Vector2.RIGHT
            if dl > 0.001:
                n = d / dl
            p = post + n * md
            if vel.dot(n) < 0.0:
                vel = vel.bounce(n) * POST_BOUNCE
                spin *= 0.5
                if bounds_open:
                    G.sfx("post")

    if absf(p.x) > hw and z > BAR_H and absf(p.x) > hw + G.GOAL_DEPTH - RADIUS:
        p.x = signf(p.x) * (hw + G.GOAL_DEPTH - RADIUS)
        vel.x = -vel.x * 0.4
    elif absf(p.x) > hw and (absf(p.y) < gh or not bounds_open):
        if absf(p.y) > gh - RADIUS:
            var sy: float = signf(p.y)
            p.y = sy * (gh - RADIUS)
            if signf(vel.y) == sy:
                vel.y = -vel.y * 0.3
        var back: float = hw + G.GOAL_DEPTH - RADIUS
        if absf(p.x) > back:
            var sx: float = signf(p.x)
            p.x = sx * back
            if signf(vel.x) == sx:
                vel.x = -vel.x * 0.2
            vel.y *= 0.5
    elif not bounds_open:
        if p.y < -hh + RADIUS:
            p.y = -hh + RADIUS
            if vel.y < 0.0:
                vel.y = -vel.y * WALL_BOUNCE
            vel.x *= 0.93
        elif p.y > hh - RADIUS:
            p.y = hh - RADIUS
            if vel.y > 0.0:
                vel.y = -vel.y * WALL_BOUNCE
            vel.x *= 0.93
        if absf(p.y) > gh and absf(p.x) > hw - RADIUS:
            var sx2: float = signf(p.x)
            p.x = sx2 * (hw - RADIUS)
            if signf(vel.x) == sx2:
                vel.x = -vel.x * WALL_BOUNCE
            vel.y *= 0.93
    global_position = p

func _check_goal() -> void:
    if _goal_emitted:
        return
    if z > BAR_H:
        return
    var p: Vector2 = global_position

    if absf(p.y) < G.GOAL_HALF and absf(p.x) > G.HALF_W + RADIUS:
        _goal_emitted = true
        goal_scored.emit(0 if p.x > 0.0 else 1)

func kick(dir: Vector2, power: float, curve: float, by, lift: float = 0.0) -> void:
    holder = null
    vel = dir.normalized() * power
    spin = curve
    vz = lift
    if lift > 0.0:
        z = maxf(z, 1.0)
    shooter = null
    if by != null and by.has_method("on_kick"):
        by.on_kick(lift > 0.0)
    touch(by)
    if by != null:
        last_team = by.team
        by.kick_lock = 0.35
        var hm = by.get("main")
        if hm != null and hm.has_method("on_ball_kick"):
            hm.on_ball_kick(by)

func touch(p) -> void:
    if p == null:
        last_toucher = null
        return
    var now: int = Time.get_ticks_msec()
    if p != last_toucher:
        if last_toucher != null and is_instance_valid(last_toucher) and last_toucher.team == p.team:
            assist_from = last_toucher
            assist_ms = touch_ms
        else:
            assist_from = null
        shooter = null
    last_toucher = p
    touch_ms = now
    last_team = p.team
    var hm = p.get("main")
    if hm != null and hm.has_method("on_ball_touch"):
        hm.on_ball_touch(p)

func give_to(p) -> void:
    holder = p
    touch(p)
    last_team = p.team
    spin = 0.0

func reset_to(pos: Vector2) -> void:
    holder = null
    vel = Vector2.ZERO
    spin = 0.0
    z = 0.0
    vz = 0.0
    global_position = pos
    trail.clear()
    last_toucher = null
    shooter = null
    assist_from = null
    _goal_emitted = false

func _process(_delta: float) -> void:
    if G.headless:
        return
    if G.gfx >= 1 and holder == null and vel.length() > 520.0:
        trail.push_front(global_position)
        if trail.size() > 14:
            trail.pop_back()
    elif trail.size() > 0:
        trail.pop_back()
    queue_redraw()

func _draw() -> void:
    var lift: Vector2 = Vector2(0.0, -z * 0.7)
    var sc: float = 1.0 + z / 140.0

    for i in trail.size():
        var a: float = 1.0 - float(i) / float(trail.size())
        draw_circle(to_local(trail[i]) + lift, RADIUS * (0.3 + 0.7 * a), Color(1.0, 0.85 - 0.3 * (1.0 - a), 0.35, 0.5 * a))

    var sh: float = clampf(1.0 - z / 220.0, 0.35, 1.0)
    if G.gfx >= 1:
        draw_set_transform(Vector2(4.0 + z * 0.35, 5.0 + z * 0.15), 0.6, Vector2(1.5, 0.8))
        draw_circle(Vector2.ZERO, RADIUS * sh, Color(0, 0, 0, 0.12 * sh))
    draw_set_transform(Vector2(2.0 + z * 0.25, 3.0), 0.0, Vector2(1.0, 0.8))
    draw_circle(Vector2.ZERO, RADIUS * sh, Color(0, 0, 0, 0.32 * sh))
    draw_set_transform(lift, 0.0, Vector2(sc, sc))
    var R: float = RADIUS
    draw_circle(Vector2.ZERO, R, Color(0.96, 0.96, 0.96))

    for k in 5:
        var ang: float = roll + float(k) * TAU / 5.0
        var c: Vector2 = Vector2(cos(ang), sin(ang)) * R * 0.58
        var pts := PackedVector2Array()
        for j in 5:
            var a2: float = ang + float(j) * TAU / 5.0
            pts.append(c + Vector2(cos(a2), sin(a2)) * R * 0.27)
        draw_colored_polygon(pts, Color(0.1, 0.1, 0.12))
    var mid := PackedVector2Array()
    for j in 5:
        var a3: float = roll * 1.0 + PI / 5.0 + float(j) * TAU / 5.0
        mid.append(Vector2(cos(a3), sin(a3)) * R * 0.28)
    draw_colored_polygon(mid, Color(0.1, 0.1, 0.12))

    draw_arc(Vector2.ZERO, R * 0.82, 0.15, PI - 0.15, 16, Color(0, 0, 0, 0.12), R * 0.35)
    draw_circle(Vector2(-R * 0.35, -R * 0.38), R * 0.22, Color(1, 1, 1, 0.55))
    draw_arc(Vector2.ZERO, R, 0.0, TAU, 24, Color(0.12, 0.12, 0.14), 1.5)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
