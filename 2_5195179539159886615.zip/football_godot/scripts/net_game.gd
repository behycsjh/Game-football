extends Node2D

const PlayerScene = preload("res://scenes/Player.tscn")
const FxScript = preload("res://scripts/fx.gd")
const HEAD := 26
const STRIDE := 10
const PHASES := ["play", "goal", "break", "end", "set", "take", "duel"]
const KINDS := ["", "throw", "corner", "goalkick", "free", "penalty"]
const STAGES := ["", "announce", "take", "duel_pick", "duel_run"]
const STAT_KEYS := ["Удары", "Отборы", "Финты", "Ассисты", "Сейвы", "Фолы", "Жёлтые", "Красные"]

@onready var ball = $Ball
@onready var players_root: Node2D = $Players
@onready var cam: Camera2D = $Camera2D
@onready var hud = $CanvasLayer/HUD

var ents: Array = []
var tpos: Array = []
var controlled = null
var my_idx: int = -1
var score: Array = [0, 0]
var period: int = 1
var time_left: float = 0.0
var phase: String = "break"
var goal_team: int = -1
var message: String = "СТАРТ!"
var scorer_name: String = ""
var end_lines = null
var end_footer: String = ""
var got_snap: bool = false
var cur: Dictionary = {}
var _sent_t: float = 0.0
var _last_mv: Vector2i = Vector2i.ZERO
var _last_btn: int = 0
var fx = null
var show_stats: bool = false
var t_was: bool = false
var banner_text: String = ""
var banner_t: float = 0.0
var banner_col: Color = Color.WHITE
var banner_card: Color = Color(0, 0, 0, 0)
var team_stats: Array = [[], []]
var kind_code: int = 0
var sp_team: int = 0
var taker_idx: int = -1
var aim: Vector2 = Vector2.RIGHT
var charge: float = 0.0
var stage_code: int = 0
var s_lock: bool = false
var g_lock: bool = false
var shooter_idx: int = -1
var chooser_idx: int = -1
var tleft: float = 0.0
var pick_col: int = 0
var pick_hi: int = 0
var ov_t: float = 0.0
var ov_col: int = 0
var ov_hi: int = 0
var _zoomed: bool = false

func _ready() -> void:
    G.mode = 2
    G.train = ""
    var info: Dictionary = Net.match_info
    ball.puppet = true
    cam.zoom = Vector2(1.0, 1.0)
    cam.limit_left = -1000
    cam.limit_right = 1000
    cam.limit_top = -625
    cam.limit_bottom = 625
    for d in info["players"]:
        var p = PlayerScene.instantiate()
        players_root.add_child(p)
        p.collision_layer = 0
        p.collision_mask = 0
        p.team = d["team"]
        p.role = d["role"]
        p.num = d["num"]
        p.nick = d["nick"]
        p.dir_x = 1.0 if p.team == 0 else -1.0
        p.facing = Vector2(p.dir_x, 0.0)
        ents.append(p)
        tpos.append(Vector2.ZERO)
    fx = Node2D.new()
    fx.set_script(FxScript)
    add_child(fx)
    team_stats = [[0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0]]
    my_idx = info["my_idx"]
    controlled = ents[my_idx]
    controlled.is_human = true
    players_root.visible = false
    hud.setup(self)
    Net.snapshot.connect(_on_snap)
    Net.match_event.connect(_on_event)
    Net.ended.connect(_on_end)
    Net.disconnected.connect(_on_disc)

func _on_snap(a: PackedFloat32Array) -> void:
    if a.size() < HEAD + ents.size() * STRIDE + 16 + 4:
        return
    if end_lines != null:
        return
    var prev_phase: String = phase
    phase = PHASES[clampi(int(a[0]), 0, PHASES.size() - 1)]
    time_left = a[1]
    score = [int(a[2]), int(a[3])]
    period = int(a[4])
    ball.net_pos = Vector2(a[5], a[6])
    ball.net_vel = Vector2(a[7], a[8])
    ball.net_z = a[13]
    goal_team = int(a[10])
    var mc: int = int(a[11])
    if phase == "break":
        message = "СТАРТ!" if mc == 1 else ("ПЕРЕРЫВ — 2-й тайм" if mc == 2 else "")
    elif phase == "play" or phase == "goal":
        message = ""
    var si: int = int(a[12])
    scorer_name = ""
    if si >= 0 and si < ents.size():
        scorer_name = ents[si].nick
    kind_code = clampi(int(a[14]), 0, KINDS.size() - 1)
    sp_team = int(a[15])
    taker_idx = int(a[16])
    aim = Vector2(a[17], a[18])
    charge = a[19]
    stage_code = clampi(int(a[20]), 0, STAGES.size() - 1)
    s_lock = a[21] > 0.5
    g_lock = a[22] > 0.5
    shooter_idx = int(a[23])
    chooser_idx = int(a[24])
    tleft = a[25]
    for i in ents.size():
        var o: int = HEAD + i * STRIDE
        var p = ents[i]
        tpos[i] = Vector2(a[o], a[o + 1])
        p.facing = Vector2(a[o + 2], a[o + 3])
        p.state = int(a[o + 4])
        p.charge = a[o + 5]
        var fl: int = int(a[o + 6])
        p.recover_t = 0.1 if (fl & 1) != 0 else 0.0
        p.skill_t = 0.1 if (fl & 2) != 0 else 0.0
        p.shield_t = 0.1 if (fl & 8) != 0 else 0.0
        p.charging = (fl & 4) != 0
        p.sent_off = (fl & 16) != 0
        p.yellow = 1 if (fl & 32) != 0 else 0
        p.hands_up = (fl & 64) != 0
        p.visible = not p.sent_off
        p.dive_vec = Vector2.from_angle(a[o + 7])
        p.kick_kind = int(a[o + 8])
        p.kick_t = a[o + 9]
        p.is_pass_target = false
        if not got_snap:
            p.global_position = tpos[i]
    var ts: int = HEAD + ents.size() * STRIDE
    for t in 2:
        for k in 8:
            team_stats[t][k] = int(a[ts + t * 8 + k])
    var e: int = ts + 16
    controlled.skill_cd = a[e]
    controlled.tackle_cd = a[e + 1]
    controlled.recover_t = a[e + 2]
    var pt: int = int(a[e + 3])
    if pt >= 0 and pt < ents.size():
        ents[pt].is_pass_target = true
    if phase == "goal" and prev_phase != "goal" and got_snap:
        fx.confetti(ball.net_pos)
    if not got_snap:
        ball.global_position = ball.net_pos
        cam.global_position = ball.net_pos
        players_root.visible = true
        got_snap = true

func _on_event(code: int, text: String, nums: PackedFloat32Array) -> void:
    match code:
        1:
            banner_text = text
            banner_col = Color(nums[0], nums[1], nums[2])
            banner_card = Color(nums[3], nums[4], nums[5], nums[6])
            banner_t = 3.2
        2:
            G.sfx(text, nums[0] if nums.size() > 0 else 0.0)
        3:
            message = text
        4:
            if nums.size() >= 5:
                popup(Vector2(nums[0], nums[1]), text, Color(nums[2], nums[3], nums[4]))

func popup(pos: Vector2, text: String, col: Color) -> void:
    if fx != null:
        fx.add_popup(pos, text, col)

func burst(pos: Vector2, col: Color, n: int, speed: float, life: float) -> void:
    if fx != null:
        fx.burst(pos, col, n, speed, life)

func stat_rows() -> Array:
    var rows: Array = [["Голы", score[0], score[1]]]
    for k in 8:
        rows.append([STAT_KEYS[k], team_stats[0][k], team_stats[1][k]])
    return rows

func take_info() -> Dictionary:
    var st: String = STAGES[stage_code]
    var d: Dictionary = {"stage": "", "kind": KINDS[kind_code], "team": sp_team, "role": "", "aim": aim, "charge": charge,
        "col": 0, "hi": 0, "locked": false, "opp_locked": false, "t": tleft, "tpos": Vector2.ZERO}
    if st != "take" and st != "duel_pick" and st != "duel_run":
        return d
    d["stage"] = st
    if taker_idx >= 0 and taker_idx < ents.size():
        d["tpos"] = ents[taker_idx].global_position
    if st == "take" and taker_idx == my_idx:
        d["role"] = "taker"
    elif st == "duel_pick":
        if shooter_idx == my_idx:
            d["role"] = "shooter"
            d["col"] = pick_col
            d["hi"] = pick_hi
            d["locked"] = s_lock
            d["opp_locked"] = g_lock
        elif chooser_idx == my_idx:
            d["role"] = "keeper"
            d["col"] = pick_col
            d["locked"] = g_lock
            d["opp_locked"] = s_lock
    return d

func _on_end(res: Dictionary) -> void:
    phase = "end"
    score = [int(res["score"][0]), int(res["score"][1])]
    var cols: Array = [[], []]
    for e in res["players"]:
        cols[int(e["team"])].append("%s — голы %d, пасы %d, фолы %d, ЖК %d, КК %d" % [e["nick"], int(e["goals"]), int(e["assists"]), int(e.get("fouls", 0)), int(e.get("yellows", 0)), int(e.get("reds", 0))])
    end_lines = cols
    var d: int = int(res["delta"])
    end_footer = "Рейтинг: %d (%s%d)" % [int(res["rating"]), "+" if d >= 0 else "", d]
    players_root.visible = true

func _on_disc(_reason: String) -> void:
    G.goto("res://scenes/Menu.tscn")

func on_hud_button(id: String) -> void:
    if id.begins_with("pick:"):
        var pr: PackedStringArray = id.split(":")
        ov_col = int(pr[1])
        ov_hi = int(pr[2])
        ov_t = 0.4
        return
    if id == "leave":
        Net.leave_match()
        G.goto("res://scenes/Menu.tscn")
    elif id == "menu":
        G.goto("res://scenes/Menu.tscn")
    elif id == "again":
        if not Net.last_private:
            Net.quick_match(Net.last_n)
        G.goto("res://scenes/Menu.tscn")

func _physics_process(delta: float) -> void:
    _send_input(delta)
    banner_t = maxf(0.0, banner_t - delta)
    ov_t = maxf(0.0, ov_t - delta)
    var tk: bool = _kb(KEY_T)
    if tk and not t_was:
        show_stats = not show_stats
    t_was = tk
    if got_snap:
        for i in ents.size():
            var p = ents[i]
            if p.global_position.distance_to(tpos[i]) > 220.0:
                p.global_position = tpos[i]
            else:
                var k: float = clampf((26.0 if i == my_idx else 18.0) * delta, 0.0, 1.0)
                p.global_position = p.global_position.lerp(tpos[i], k)
    var look: Vector2 = (ball.vel * 0.22).limit_length(160.0)
    var target: Vector2 = ball.global_position + look
    if phase == "duel":
        var dxx: float = 1.0 if sp_team == 0 else -1.0
        target = Vector2(dxx * (G.HALF_W - 120.0), 0.0)
        _zoomed = true
        cam.zoom = cam.zoom.lerp(Vector2(1.55, 1.55), clampf(4.0 * delta, 0.0, 1.0))
    elif _zoomed:
        cam.zoom = cam.zoom.lerp(Vector2.ONE, clampf(5.0 * delta, 0.0, 1.0))
        if absf(cam.zoom.x - 1.0) < 0.02:
            cam.zoom = Vector2.ONE
            _zoomed = false
    cam.global_position = cam.global_position.lerp(target, clampf(5.0 * delta, 0.0, 1.0))

func _kb(k: int) -> bool:
    return Input.is_physical_key_pressed(k)

func _move_vector() -> Vector2:
    var v: Vector2 = Vector2.ZERO
    if _kb(KEY_A) or _kb(KEY_LEFT):
        v.x -= 1.0
    if _kb(KEY_D) or _kb(KEY_RIGHT):
        v.x += 1.0
    if _kb(KEY_W) or _kb(KEY_UP):
        v.y -= 1.0
    if _kb(KEY_S) or _kb(KEY_DOWN):
        v.y += 1.0
    if v == Vector2.ZERO:
        v = hud.stick_vec
    return v.limit_length(1.0)

func _send_input(delta: float) -> void:
    _sent_t += delta
    var btn: int = 0
    var keys: Array = [KEY_SPACE, KEY_R]
    var ids: Array = ["shoot", "skill"]
    for i in 2:
        if _kb(keys[i]) or hud.is_down(ids[i]):
            btn |= (1 << i)
    hud.latch.clear()
    if phase == "end" or not got_snap:
        return
    if hud.settings_open:
        btn = 0
    var mv: Vector2 = _move_vector()
    if hud.settings_open:
        mv = Vector2.ZERO
    if ov_t > 0.0:
        mv = Vector2(float(ov_col), -1.0 if ov_hi == 1 else 0.5)
        if ov_t < 0.2:
            btn |= 1
    if stage_code == 3 and not (s_lock if shooter_idx == my_idx else g_lock):
        pick_col = 0 if absf(mv.x) < 0.35 else (1 if mv.x > 0.0 else -1)
        pick_hi = 1 if mv.y < -0.35 else 0
    var q: Vector2i = Vector2i(roundi(mv.x * 20.0), roundi(mv.y * 20.0))
    if btn != _last_btn or (q != _last_mv and _sent_t > 0.033) or _sent_t > 0.25:
        _sent_t = 0.0
        _last_btn = btn
        _last_mv = q
        Net.send_input(q.x, q.y, btn)
