extends Node2D

const PlayerScene = preload("res://scenes/Player.tscn")
const FxScript = preload("res://scripts/fx.gd")

@onready var ball = $Ball
@onready var players_root: Node2D = $Players
@onready var cam: Camera2D = $Camera2D
@onready var hud = $CanvasLayer/HUD

var teams: Array = [[], []]
var presser: Array = [null, null]
var chaser: Array = [null, null]
var controlled = null
var score: Array = [0, 0]
var period: int = 1
var time_left: float = 60.0
var phase: String = "break"
var phase_timer: float = 0.0
var goal_team: int = -1
var message: String = ""
var all_players: Array = []
var fx = null
var scorer_name: String = ""
var show_stats: bool = false
var banner_text: String = ""
var banner_t: float = 0.0
var banner_col: Color = Color.WHITE
var banner_card: Color = Color(0, 0, 0, 0)
const RulesScript = preload("res://scripts/rules.gd")
var rules = null
var var_req_left: int = 2
var req_win: Dictionary = {}
var last_goal: Dictionary = {}
var _zoomed: bool = false
const REC_MAX := 300
const REPLAY_FRAMES := 190
var rec: Array = []
var var_cd: float = 0.0
var var_kind: String = ""
var var_ctx: Dictionary = {}
var var_stage: String = ""
var var_t: float = 0.0
var var_idx: float = 0.0
var var_title: String = ""
var var_text: String = ""
var var_sub: String = ""
var var_ok: bool = true
var var_result: Dictionary = {}
var var_saved: Dictionary = {}
var var_total: Array = [0, 0]
var var_changed: Array = [0, 0]

var cur: Dictionary = {}
var jp: Dictionary = {}
var jr: Dictionary = {}

var so_active: bool = false
var so_stage: String = ""
var so_t: float = 0.0
var so_turn: int = 0
var so_first: int = 0
var so_taken: Array = [0, 0]
var so_score: Array = [0, 0]
var so_log: Array = [[], []]
var so_round: int = 0
var so_winner: int = -1
var so_shot_team: int = -1
var so_total_shots: int = 0

func _exit_tree() -> void:
    G.ambience(false)

func _ready() -> void:
    randomize()
    rules = RulesScript.new(self)
    fx = Node2D.new()
    fx.set_script(FxScript)
    add_child(fx)
    ball.bounds_open = G.train != "solo"
    G.ambience(true)
    time_left = G.half_time
    ball.goal_scored.connect(_on_goal)
    _spawn_teams()
    cam.zoom = Vector2(1.0, 1.0)
    cam.limit_left = -1000
    cam.limit_right = 1000
    cam.limit_top = -625
    cam.limit_bottom = 625
    _kickoff()
    phase = "break"
    phase_timer = 1.5
    message = "СТАРТ!"
    hud.setup(self)
    if G.mode == 1:
        _set_controlled(gk_of(0))
    else:
        _set_controlled(teams[0][teams[0].size() - 1])
    cam.global_position = Vector2.ZERO
    G.comment("start")
    if G.train == "shootout":
        _begin_shootout(false)

func _spawn_teams() -> void:
    for t in 2:
        var arr: Array = []
        var slots: Array = G.formation_slots(G.team_size, int(G.form_pick[t]))
        if G.train == "solo":
            slots = [[Vector2(-855, 0), 0], [Vector2(165, 0), 3]] if t == 0 else [[Vector2(-855, 0), 0]]
        elif G.train == "1v1":
            slots = [[Vector2(-855, 0), 0], [Vector2(165, 0), 3]]
        elif G.train == "shootout":
            slots = G.formation_slots(G.team_size, int(G.form_pick[t]))
        for i in slots.size():
            var p = PlayerScene.instantiate()
            players_root.add_child(p)
            p.setup(self, ball, t, int(slots[i][1]), i + 1, slots[i][0])
            p.bot_k = 0.78 if t == 1 else 0.92
            arr.append(p)
            all_players.append(p)
        teams[t] = arr

func gk_of(t: int):
    return teams[t][0]

func _kickoff() -> void:
    ball.reset_to(Vector2.ZERO)
    for t in 2:
        for p in teams[t]:
            p.reset_state()
            p.global_position = Vector2(minf(p.home.x, -45.0) * p.dir_x, p.home.y)
    rec.clear()
    ball.assist_from = null
    ball.shooter = null
    if G.train == "solo":
        var f = teams[0][1]
        f.global_position = Vector2(-G.HALF_W * 0.45, 0.0)
        ball.global_position = f.global_position + Vector2(21.0, 0.0)
        ball.give_to(f)
    phase = "play"
    message = ""

func _set_controlled(p) -> void:
    if controlled != null:
        controlled.is_human = false
        controlled.charging = false
        controlled.move_input = Vector2.ZERO
    controlled = p
    if p != null:
        p.is_human = true

func nearest_field(t: int, exclude):
    var best = null
    var bd: float = 1e9
    for p in teams[t]:
        if p.role == 0 or p == exclude:
            continue
        var d: float = p.global_position.distance_to(ball.global_position)
        if d < bd:
            bd = d
            best = p
    return best

func _physics_process(delta: float) -> void:
    _poll_input()
    banner_t = maxf(0.0, banner_t - delta)
    if so_active:
        _so_step(delta)
        _update_camera(delta)
        return
    if not req_win.is_empty():
        req_win["t"] = float(req_win["t"]) - delta
        if float(req_win["t"]) <= 0.0 or (req_win["kind"] == "tackle" and phase != "play") or (req_win["kind"] == "goal" and phase != "goal"):
            req_win = {}
    if phase == "play":
        var_cd = maxf(0.0, var_cd - delta)
        _record()
        rules.check_out()
        if phase != "play":
            _update_camera(delta)
            return
        if G.train != "solo":
            time_left -= delta
            if time_left <= 0.0:
                time_left = 0.0
                _end_period()
        _compute_roles()
        _update_human()
        _auto_switch()
    elif phase == "var":
        _var_step(delta)
    elif phase == "set" or phase == "take" or phase == "duel":
        rules.step(delta)
    elif phase == "goal" or phase == "break":
        phase_timer -= delta
        if phase_timer <= 0.0:
            _kickoff()
    _update_camera(delta)

func _end_period() -> void:
    if period == 1:
        period = 2
        time_left = G.half_time
        phase = "break"
        phase_timer = 2.5
        message = "ПЕРЕРЫВ — 2-й тайм"
    else:
        if score[0] == score[1] and G.shootout_on and G.train != "solo":
            _begin_shootout(true)
        else:
            phase = "end"

func _on_goal(team: int) -> void:
    if so_active:
        return
    if phase != "play":
        return
    var sc = ball.last_toucher
    var asst = null
    if sc != null and is_instance_valid(sc) and sc.team == team:
        var a = ball.assist_from
        if a != null and is_instance_valid(a) and a != sc and a.team == team and Time.get_ticks_msec() - ball.assist_ms < 7000:
            asst = a
    if G.train == "" and var_cd <= 0.0 and randf() < 0.35:
        _begin_var("goal", {"team": team, "scorer": sc, "assist": asst}, "ПРОВЕРКА ГОЛА")
        return
    _award_goal(team, sc, asst)

func _award_goal(team: int, sc, asst, from_var: bool = false) -> void:
    score[team] += 1
    last_goal = {"team": team, "scorer": sc, "asst": asst}
    if G.train == "" and not from_var and var_req_left > 0:
        req_win = {"kind": "goal", "t": 3.4}
    goal_team = team
    phase = "goal"
    phase_timer = G.GOAL_PAUSE
    message = "ГОЛ!"
    if G.train == "" and not from_var and var_req_left > 0:
        phase_timer = 3.4
    scorer_name = ""
    if sc != null and is_instance_valid(sc):
        if sc.team == team:
            sc.stats["goals"] = int(sc.stats["goals"]) + 1
            scorer_name = "№%d" % sc.num
            if asst != null:
                asst.stats["assists"] = int(asst.stats["assists"]) + 1
                scorer_name += " (ассист №%d)" % asst.num
        else:
            scorer_name = "АВТОГОЛ №%d" % sc.num
    G.sfx("net")
    fx.confetti(ball.global_position)
    fx.burst(ball.global_position, Color(1, 1, 1, 0.9), 24, 380.0, 0.7)

func _update_camera(delta: float) -> void:
    var look: Vector2 = (ball.vel * 0.22).limit_length(160.0)
    var target: Vector2 = ball.global_position + look
    if phase == "duel":
        var dxx: float = 1.0 if rules.team == 0 else -1.0
        target = Vector2(dxx * (G.HALF_W - 120.0), 0.0)
        _zoomed = true
        cam.zoom = cam.zoom.lerp(Vector2(1.55, 1.55), clampf(4.0 * delta, 0.0, 1.0))
    elif _zoomed and phase != "var":
        cam.zoom = cam.zoom.lerp(Vector2.ONE, clampf(5.0 * delta, 0.0, 1.0))
        if absf(cam.zoom.x - 1.0) < 0.02:
            cam.zoom = Vector2.ONE
            _zoomed = false
    cam.global_position = cam.global_position.lerp(target, clampf(5.0 * delta, 0.0, 1.0))

func _compute_roles() -> void:
    var bp: Vector2 = ball.global_position
    var h = ball.holder
    for t in 2:
        var best = null
        var bd: float = 1e9
        var human_d: float = 1e9
        for p in teams[t]:
            if p.role == 0:
                continue
            var d: float = p.global_position.distance_to(bp)
            if p.is_human:
                human_d = d
                continue
            if d < bd:
                bd = d
                best = p
        if human_d + 40.0 < bd:
            best = null
        presser[t] = null
        chaser[t] = null
        if h == null:
            chaser[t] = best
        elif h.team != t and h.role != 0:
            presser[t] = best

        var threats: Array = []
        for o in teams[1 - t]:
            if o.role != 0 and o != h:
                threats.append(o)
        var own_goal_x: float = -G.HALF_W * (1.0 if t == 0 else -1.0)
        threats.sort_custom(func(a, b): return absf(a.global_position.x - own_goal_x) < absf(b.global_position.x - own_goal_x))
        var i: int = 0
        for p in teams[t]:
            p.mark_target = null
            if p.role == 0 or p.is_human or p == presser[t]:
                continue
            if i < threats.size():
                p.mark_target = threats[i]
            i += 1

func find_pass_target(p, dir: Vector2):
    var best = null
    var best_s: float = -1e9
    var pp: Vector2 = p.global_position
    var dx: float = 1.0 if p.team == 0 else -1.0
    for q in teams[p.team]:
        if q == p or q.role == 0:
            continue
        if rules != null and rules.would_be_offside(p, q.global_position):
            continue
        var to: Vector2 = q.global_position - pp
        var d: float = to.length()
        if d < 70.0:
            continue
        var s: float = 0.0
        if dir.length() > 0.3:
            var c: float = dir.normalized().dot(to / d)
            if c < 0.45:
                continue
            s += c * 3.0
        else:
            s += (to.x * dx) / 400.0
        var open: float = 300.0
        for o in teams[1 - p.team]:
            var od: float = o.global_position.distance_to(q.global_position)
            open = minf(open, od)
            if o.role != 0:
                var cp: Vector2 = Geometry2D.get_closest_point_to_segment(o.global_position, pp, q.global_position)
                if cp.distance_to(o.global_position) < 30.0:
                    s -= 1.5
        s += open / 150.0
        s -= d / 700.0
        if s > best_s:
            best_s = s
            best = q
    return best

func _kb(k: int) -> bool:
    return Input.is_physical_key_pressed(k)

func _poll_input() -> void:
    var kb: Dictionary = {
        "shoot": _kb(KEY_SPACE),
        "pass": _kb(KEY_F),
        "tackle": _kb(KEY_G),
        "skill": _kb(KEY_R),
        "switch": _kb(KEY_TAB),
        "gk": _kb(KEY_C),
        "jl": _kb(KEY_Q),
        "jr": _kb(KEY_E),
        "exit": _kb(KEY_X),
        "dash": _kb(KEY_Z),
        "stats": _kb(KEY_T),
        "skip": _kb(KEY_ENTER),
        "reqvar": _kb(KEY_V),
    }
    for a in kb:
        var now: bool = kb[a] or hud.is_down(a)
        var was: bool = cur.get(a, false)
        jp[a] = now and not was
        jr[a] = (not now) and was
        cur[a] = now
    hud.latch.clear()
    if jp.get("stats", false):
        show_stats = not show_stats
    if jp.get("skip", false):
        var_skip()
    if jp.get("reqvar", false):
        request_var()

func _move_vector() -> Vector2:
    var v: Vector2 = Vector2.ZERO
    if _kb(KEY_A) or _kb(KEY_LEFT):
        v.x -= 1.0
    if _kb(KEY_D) or _kb(KEY_RIGHT):
        v.x += 1.0
    if _kb(KEY_W) or _kb(KEY_UP):
        v.y -= 1.0
    if _kb(KEY_S) or _kb(KEY_DOWN):
        v.y += 1.0
    if v == Vector2.ZERO:
        v = hud.stick_vec
    return v.limit_length(1.0)

func _update_human() -> void:
    var mv: Vector2 = _move_vector()
    if G.mode == 0 and G.train == "" and controlled != null:
        if jp.get("switch", false):
            _set_controlled(nearest_field(0, controlled))
        elif jp.get("gk", false):
            if controlled.role == 0:
                _set_controlled(nearest_field(0, null))
            else:
                _set_controlled(gk_of(0))
    var p = controlled
    for q in teams[0]:
        q.is_pass_target = false
    if p == null:
        return
    p.move_input = mv
    if p.role == 0:
        if jp.get("jl", false):
            p.gk_jump(-1)
        if jp.get("jr", false):
            p.gk_jump(1)
        if jp.get("dash", false):
            p.gk_dash()
        if jp.get("exit", false) or jp.get("shoot", false):
            p.gk_exit()
    else:
        if jp.get("shoot", false):
            p.press_kick()
        if jr.get("shoot", false):
            p.release_shoot()
        if jp.get("skill", false):
            p.do_skill()

        if ball.holder == p:
            var t = find_pass_target(p, mv)
            if t != null:
                t.is_pass_target = true

var sw_cd: float = 0.0

func _auto_switch() -> void:
    if G.mode != 0 or controlled == null or controlled.role == 0:
        return
    sw_cd = maxf(0.0, sw_cd - get_physics_process_delta_time())
    var h = ball.holder
    if h != null and h.team == 0 and h != controlled and h.role != 0:
        _set_controlled(h)
        sw_cd = 0.5
        return

    if sw_cd <= 0.0 and G.train == "" and (h == null or h.team == 1):
        var nb = nearest_field(0, null)
        if nb != null and nb != controlled:
            var dn: float = nb.global_position.distance_to(ball.global_position)
            var dc: float = controlled.global_position.distance_to(ball.global_position)
            if dn + 45.0 < dc:
                _set_controlled(nb)
                sw_cd = 0.6

func on_hud_button(id: String) -> void:
    if id.begins_with("pick:"):
        var pr: PackedStringArray = id.split(":")
        var who = null
        if rules.shooter != null and rules.shooter.team == 0:
            who = rules.shooter
        elif rules.keeper != null and rules.keeper.team == 0:
            who = rules.keeper
        if who != null:
            rules.hud_pick(who, int(pr[1]), int(pr[2]))
        return
    if id == "reqvar":
        request_var()
    elif id == "skipvar":
        var_skip()
    elif id == "again":
        G.goto("res://scenes/Main.tscn")
    elif id == "menu":
        G.goto("res://scenes/Menu.tscn")

func set_message(t: String) -> void:
    message = t

func banner(text: String, col: Color, card: Color) -> void:
    _banner(text, col, card)

func sound(n: String, vol: float) -> void:
    G.sfx(n, vol)

func human_taker(t: int):
    if t == 0 and G.mode == 0 and controlled != null and controlled.role != 0 and teams[0].has(controlled):
        return controlled
    return null

func human_input(p) -> Dictionary:
    if p == null or p.team != 0 or G.train == "solo":
        return {}
    var ok: bool = p == controlled
    if not ok and p.role == 0 and phase == "duel" and rules.keeper == p:
        ok = true
    if not ok:
        return {}
    return {"mv": _move_vector(), "shoot": bool(cur.get("shoot", false)) or bool(cur.get("exit", false))}

func on_set_taken(p) -> void:
    rec.clear()
    p.think_t = 0.8
    if p.team == 0 and G.mode == 0 and G.train != "solo" and p.role != 0:
        _set_controlled(p)
    G.sfx("whistle", -5.0)

func on_send_off(p) -> void:
    if controlled == p:
        controlled = null
        var nf = nearest_field(0, null)
        _set_controlled(nf if nf != null else gk_of(0))

func take_info() -> Dictionary:
    var d: Dictionary = rules.info_for(controlled)
    if d["role"] == "" and phase == "duel" and rules.keeper != null and rules.keeper.team == 0 and G.train != "solo":
        d = rules.info_for(rules.keeper)
    return d

func call_foul(off, vic) -> bool:
    return rules.call_foul(off, vic)

func try_var_foul(off, vic, card: int, kind: String, spot: Vector2) -> bool:
    var eligible: bool = G.train == "" and var_cd <= 0.0 and (kind == "penalty" or card == 2 or (card == 1 and off.yellow >= 1))
    if eligible and randf() < 0.7:
        var what: String = "ПРОВЕРКА ПЕНАЛЬТИ" if kind == "penalty" else "ПРОВЕРКА КАРТОЧКИ"
        _begin_var("foul", {"off": off, "vic": vic, "card": card, "kind": kind, "spot": spot}, what)
        return true
    return false

func note_tackle(tackler, victim) -> void:
    if G.train != "" or var_req_left <= 0 or phase != "play":
        return
    if victim.team == 0 and tackler.team == 1:
        req_win = {"kind": "tackle", "t": 4.0, "off": tackler, "vic": victim}

func request_var() -> void:
    if req_win.is_empty() or var_req_left <= 0:
        return
    var k: String = req_win["kind"]
    if k == "goal" and phase == "goal":
        var_req_left -= 1
        var g: Dictionary = last_goal
        _begin_var("goal", {"team": g["team"], "scorer": g["scorer"], "assist": g["asst"], "requested": true}, "ПРОВЕРКА ГОЛА — ЗАПРОС")
    elif k == "tackle" and phase == "play":
        var_req_left -= 1
        _begin_var("tackle", {"off": req_win["off"], "vic": req_win["vic"], "holder": ball.holder, "requested": true}, "ПРОВЕРКА ОТБОРА — ЗАПРОС")
    req_win = {}

func team_name(t: int) -> String:
    return G.team_name(t)

func popup(pos: Vector2, text: String, col: Color) -> void:
    if fx != null:
        fx.add_popup(pos, text, col)

func burst(pos: Vector2, col: Color, n: int, speed: float, life: float) -> void:
    if fx != null:
        fx.burst(pos, col, n, speed, life)

func _banner(text: String, col: Color, card: Color) -> void:
    banner_text = text
    banner_col = col
    banner_card = card
    banner_t = 3.2

func _keep_in(p: Vector2) -> Vector2:
    return Vector2(clampf(p.x, -G.HALF_W + 24.0, G.HALF_W - 24.0), clampf(p.y, -G.HALF_H + 24.0, G.HALF_H - 24.0))

func team_total(t: int, key: String) -> int:
    var n: int = 0
    for p in all_players:
        if p.team == t:
            n += int(p.stats.get(key, 0))
    return n

func stat_rows() -> Array:
    return [
        ["Голы", score[0], score[1]],
        ["Удары", team_total(0, "shots"), team_total(1, "shots")],
        ["Отборы", team_total(0, "tackles"), team_total(1, "tackles")],
        ["Финты", team_total(0, "feints"), team_total(1, "feints")],
        ["Ассисты", team_total(0, "assists"), team_total(1, "assists")],
        ["Сейвы", team_total(0, "saves"), team_total(1, "saves")],
        ["Фолы", team_total(0, "fouls"), team_total(1, "fouls")],
        ["Офсайды", team_total(0, "offsides"), team_total(1, "offsides")],
        ["Жёлтые", team_total(0, "yellows"), team_total(1, "yellows")],
        ["Красные", team_total(0, "reds"), team_total(1, "reds")],
        ["VAR проверки", var_total[0], var_total[1]],
        ["VAR изменено", var_changed[0], var_changed[1]],
    ]


func _record() -> void:
    rec.append(_frame())
    if rec.size() > REC_MAX:
        rec.pop_front()

func _frame() -> Dictionary:
    var arr: Array = []
    for p in all_players:
        if p.visible:
            arr.append([p, p.global_position, p.facing, p.state, p.kick_t, p.kick_kind, p.shield_t, p.hop, p.dive_vec, p.dash_t, p.recover_t])
    return {"b": ball.global_position, "bz": ball.z, "bv": ball.vel, "p": arr}

func _show_frame(fr: Dictionary) -> void:
    ball.global_position = fr["b"]
    ball.net_pos = fr["b"]
    ball.net_vel = fr["bv"]
    ball.net_z = fr["bz"]
    ball.z = fr["bz"]
    ball.vel = fr["bv"]
    for e in fr["p"]:
        var p = e[0]
        if not is_instance_valid(p):
            continue
        p.global_position = e[1]
        p.facing = e[2]
        p.state = e[3]
        p.kick_t = e[4]
        p.kick_kind = e[5]
        p.shield_t = e[6]
        p.hop = e[7]
        p.dive_vec = e[8]
        p.dash_t = e[9]
        p.recover_t = e[10]

func _begin_var(kind: String, ctx: Dictionary, title: String) -> void:
    var_saved = _frame()
    var_kind = kind
    var_ctx = ctx
    var_title = title
    var_stage = "review"
    var_t = 0.0
    var_text = ""
    var_sub = ""
    var_idx = float(maxi(0, rec.size() - REPLAY_FRAMES))
    phase = "var"
    message = ""
    ball.holder = null
    ball.puppet = true
    cam.zoom = Vector2(1.2, 1.2)
    G.sfx("var")
    var who = ctx.get("scorer", ctx.get("off", null))
    if who != null and is_instance_valid(who):
        var_total[who.team] += 1
    fx.marks.clear()
    if kind == "goal":
        if ctx["scorer"] != null and is_instance_valid(ctx["scorer"]):
            fx.marks.append([ctx["scorer"], Color(1, 0.95, 0.2, 0.95)])
    else:
        fx.marks.append([ctx["off"], Color(1, 0.3, 0.3, 0.95)])
        fx.marks.append([ctx["vic"], Color(0.4, 0.9, 1, 0.95)])
    if rec.is_empty():
        var_idx = 0.0

func _var_step(delta: float) -> void:
    var_t += delta
    if var_stage == "review":
        var_idx += 0.6
        if not rec.is_empty():
            _show_frame(rec[clampi(int(var_idx), 0, rec.size() - 1)])
        if var_idx >= float(rec.size()) + 30.0 or rec.is_empty():
            _var_decide()
    elif var_t > 3.0:
        _var_finish()

func var_skip() -> void:
    if phase != "var":
        return
    if var_stage == "review":
        _var_decide()
    else:
        _var_finish()

func _var_decide() -> void:
    var_stage = "decision"
    var_t = 0.0
    var_result = {}
    var notes: Array = []
    if var_kind == "tackle":
        var_ok = randf() < 0.5
        if var_ok:
            var_text = "ФОЛ ПОДТВЕРЖДЁН"
            var_sub = "Нарушение правил при отборе"
        else:
            var_text = "ФОЛА НЕТ"
            var_sub = "Игра продолжается"
    elif var_kind == "goal":
        if var_ctx.get("requested", false):
            var_ok = randf() >= (0.38 if int(var_ctx["team"]) == 1 else 0.12)
        else:
            var_ok = randf() < 0.72
        if var_ok:
            var_text = "ГОЛ ЗАСЧИТАН"
            var_sub = "Нарушений не обнаружено"
        else:
            var_text = "ГОЛ ОТМЕНЁН"
            var_sub = ["Нарушение правил в атаке", "Игра рукой перед голом"][randi() % 2]
    else:
        var card: int = var_ctx["card"]
        var kind: String = var_ctx["kind"]
        var spot: Vector2 = var_ctx["spot"]
        var off = var_ctx["off"]
        if kind == "penalty" and randf() > 0.75:
            kind = "free"
            spot = Vector2(-G.HALF_W * off.dir_x + off.dir_x * (G.PEN_DEPTH + 15.0), clampf(var_ctx["vic"].global_position.y, -200.0, 200.0))
            notes.append("Пенальти отменён — свободный удар")
        if card == 2 and randf() > 0.75:
            card = 1
            notes.append("Красная заменена на жёлтую")
        var_ok = notes.is_empty()
        var_result = {"card": card, "kind": kind, "spot": spot}
        if var_ok:
            var_text = "РЕШЕНИЕ ПОДТВЕРЖДЕНО"
            var_sub = "Судья остаётся при своём мнении"
        else:
            var_text = "РЕШЕНИЕ ИЗМЕНЕНО"
            var_sub = " • ".join(notes)
    G.sfx("var")

func _var_finish() -> void:
    ball.puppet = false
    cam.zoom = Vector2(1.0, 1.0)
    fx.marks.clear()
    var_cd = 25.0
    var fr: Dictionary = var_saved
    _show_frame(fr)
    ball.vel = fr["bv"]
    for p in all_players:
        p.velocity = Vector2.ZERO
    var ctx: Dictionary = var_ctx
    if var_kind == "tackle":
        var off = ctx["off"]
        var vic = ctx["vic"]
        if var_ok and is_instance_valid(off) and is_instance_valid(vic):
            var_changed[off.team] += 1
            off.stats["fouls"] = int(off.stats["fouls"]) + 1
            var kd: String = "free"
            var sp: Vector2 = vic.global_position
            if rules.in_box(off.team, sp):
                kd = "penalty"
                sp = Vector2((G.HALF_W - 160.0) * (1.0 if vic.team == 0 else -1.0), 0.0)
            rules.apply_foul(off, vic, 1 if randf() < 0.3 else 0, kd, sp)
        else:
            phase = "play"
            var hd = ctx.get("holder", null)
            if hd != null and is_instance_valid(hd) and teams[hd.team].has(hd):
                ball.give_to(hd)
    elif var_kind == "goal":
        var team: int = ctx["team"]
        var sc = ctx["scorer"]
        if var_ok and ctx.get("requested", false):
            phase = "goal"
            phase_timer = 1.3
            message = "ГОЛ!"
        elif var_ok:
            _award_goal(team, sc, ctx["assist"], true)
        else:
            if ctx.get("requested", false):
                score[team] = maxi(0, score[team] - 1)
                if sc != null and is_instance_valid(sc) and sc.team == team:
                    sc.stats["goals"] = maxi(0, int(sc.stats["goals"]) - 1)
                var asx = ctx.get("assist", null)
                if asx != null and is_instance_valid(asx):
                    asx.stats["assists"] = maxi(0, int(asx.stats["assists"]) - 1)
            if sc != null and is_instance_valid(sc):
                var_changed[sc.team] += 1
            ball._goal_emitted = false
            var spot: Vector2 = ball.global_position
            if sc != null and is_instance_valid(sc):
                spot = sc.global_position
            spot = _keep_in(Vector2(clampf(spot.x, -G.HALF_W + 200.0, G.HALF_W - 200.0), spot.y))
            rules.start_set("free", 1 - team, spot, null)
    else:
        if not var_ok:
            var_changed[ctx["off"].team] += 1
        rules.apply_foul(ctx["off"], ctx["vic"], int(var_result["card"]), String(var_result["kind"]), var_result["spot"])
    var_ctx = {}


# ---------------------------------------------------------------- офсайд (хуки мяча)
func on_ball_kick(p) -> void:
    if rules != null:
        rules.on_kick(p)

func on_ball_touch(p) -> void:
    if rules != null:
        rules.on_touch(p)

# ---------------------------------------------------------------- серия пенальти
func _so_field(t: int) -> Array:
    var arr: Array = []
    for p in teams[t]:
        if p.role != 0:
            arr.append(p)
    return arr

func _begin_shootout(after_match: bool) -> void:
    so_active = true
    so_stage = "intro"
    so_t = 2.6 if after_match else 1.4
    so_taken = [0, 0]
    so_score = [0, 0]
    so_log = [[], []]
    so_round = 0
    so_winner = -1
    so_total_shots = 0
    so_first = randi() % 2
    so_turn = so_first
    rules.forced_taker = null
    ball.puppet = true
    ball.holder = null
    ball.vel = Vector2.ZERO
    for t in 2:
        for p in teams[t]:
            p.reset_state()
    _so_park(null)
    phase = "break"
    message = "СЕРИЯ ПЕНАЛЬТИ"
    banner("СЕРИЯ ПЕНАЛЬТИ — первыми бьют " + team_name(so_first), Color(1, 0.9, 0.4), Color(0, 0, 0, 0))
    G.comment("shootout")

func _so_park(keep) -> void:
    for t in 2:
        var k: int = 0
        for p in teams[t]:
            if p == keep or p.role == 0:
                continue
            var sx: float = -90.0 if t == 0 else 90.0
            p.global_position = Vector2(sx, -230.0 + 70.0 * float(k))
            p.facing = Vector2(p.dir_x, 0.0)
            p.velocity = Vector2.ZERO
            k += 1

func _so_next_kick() -> void:
    var t: int = so_turn
    var fl: Array = _so_field(t)
    if fl.is_empty():
        fl = [gk_of(t)]
    var kicker = fl[int(so_taken[t]) % fl.size()]
    so_shot_team = t
    so_stage = "kick"
    rules.forced_taker = kicker
    _so_park(kicker)
    ball.puppet = false
    var spot := Vector2((G.HALF_W - 160.0) * (1.0 if t == 0 else -1.0), 0.0)
    if t == 0 and G.mode == 0:
        _set_controlled(kicker)
    message = ""
    rules.start_set("penalty", t, spot, null)

func _so_result() -> void:
    var t: int = so_shot_team
    var scored: bool = rules.outcome == "goal"
    phase = "break"
    ball.puppet = true
    ball.holder = null
    ball.vel = Vector2.ZERO
    so_taken[t] = int(so_taken[t]) + 1
    so_total_shots += 1
    so_log[t].append(scored)
    if scored:
        so_score[t] = int(so_score[t]) + 1
        G.sfx("net")
        G.sfx("goal", -4.0)
        G.cheer(2.4)
        G.comment("so_goal")
        fx.confetti(ball.global_position)
        banner("ГОЛ! — %s  %d : %d" % [team_name(t), so_score[0], so_score[1]], Color(0.5, 1, 0.6), Color(0, 0, 0, 0))
    else:
        G.comment("so_miss")
        var what: String = "МИМО"
        match rules.outcome:
            "save":
                what = "СЕЙВ"
            "post":
                what = "ШТАНГА"
            "over":
                what = "НАД ВОРОТАМИ"
        banner("%s — %s не забивает  %d : %d" % [what, team_name(t), so_score[0], so_score[1]], Color(1, 0.55, 0.45), Color(0, 0, 0, 0))
    so_stage = "result"
    so_t = 2.2

func _so_decided() -> int:
    var a: int = int(so_taken[0])
    var b: int = int(so_taken[1])
    var s0: int = int(so_score[0])
    var s1: int = int(so_score[1])
    if a <= 5 and b <= 5:
        if s0 > s1 + (5 - b):
            return 0
        if s1 > s0 + (5 - a):
            return 1
        return -1
    if a == b and s0 != s1:
        return 0 if s0 > s1 else 1
    return -1

func _so_advance() -> void:
    var w: int = _so_decided()
    if w >= 0:
        so_winner = w
        so_stage = "done"
        so_active = false
        rules.forced_taker = null
        phase = "end"
        banner("ПО ПЕНАЛЬТИ ПОБЕЖДАЮТ " + team_name(w), Color(1, 0.9, 0.4), Color(0, 0, 0, 0))
        return
    so_turn = 1 - so_turn
    so_stage = "intro"
    so_t = 0.5
    phase = "break"

func _so_step(delta: float) -> void:
    if so_stage == "intro":
        so_t -= delta
        if so_t <= 0.0:
            _so_next_kick()
    elif so_stage == "kick":
        if phase == "set" or phase == "take" or phase == "duel":
            rules.step(delta)
        elif phase == "play":
            _so_result()
    elif so_stage == "result":
        so_t -= delta
        if so_t <= 0.0:
            _so_advance()
